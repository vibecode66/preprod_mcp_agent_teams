# Cosmic Case SLA Prediction using Machine Learning

## Overview

The Cosmic Case SLA Prediction project builds supervised machine learning models to predict two things at the point of case creation for license ticket requests:

1. **Case Closure Duration & Date** — How long a case will take to resolve (in minutes) and the predicted resolution date.
2. **Hold Time Classification** — Whether a case will be placed on hold during its lifecycle (Hold vs No Hold).

Each case is represented using structured categorical features including region, business function, line of business, program, case type, case reason, priority, complexity, and country submitter/processed. The modeling dataset comprises approximately 500,000 historical records.

## Project Folder Structure

```
├── function_app.py
├── host.json
├── requirements.txt
├── README.md
├── src/
│   ├── config/
│   │   ├── __init__.py
│   │   ├── config.yaml
│   │   └── project_config.py
│   ├── handlers/
│   │   ├── regressor_http_handlers.py
│   │   ├── classifier_http_handlers.py
│   │   ├── infer_all_http_handlers.py
│   │   └── train_all_http_handlers.py
│   ├── regressor/
│   │   ├── regressor_train.py
│   │   ├── regressor_infer.py
│   │   └── regressor_process_data.py
│   ├── classifier/
│   │   ├── classifier_train.py
│   │   ├── classifier_infer.py
│   │   └── classifier_process_data.py
│   └── shared/
│       └── blob_io.py
```

## Models

### CatBoost Regressor — Case Closure Duration

The regression model predicts case closure time in minutes. It uses CatBoost gradient-boosted decision trees, selected for native handling of high-cardinality categorical features without requiring manual encoding. The target variable is log-transformed resolution time. Feature selection is performed automatically using a preliminary CatBoost model to rank candidate features by importance, and the top features are carried forward into final training.

Training data consists all the business ROC, LOB country of orgin etc, ensuring the model learns clean resolution patterns. Derived features include rolling backlog counts (4h and 24h windows), daily case volume, hour of day, day of week, and median resolution speed per case reason.

### CatBoost Classifier — Hold Time Prediction

The classifier predicts whether a case will be placed on hold (binary: Hold / No Hold) based on the `HoldTimeInMinutes` field. It uses CatBoost with balanced class weights to handle the imbalanced nature of hold cases.

Feature engineering includes derived categorical combinations (CaseHierarchy, ReasonGroup, LOBProgram), temporal features (hour, day of week, weekend flag, month), a same-country indicator, and Bayesian-smoothed target-encoded hold rates per reason group, case subtype, and program. Target encoding is fit strictly on the training split to prevent data leakage.

The optimal decision threshold is determined by maximizing F1 score

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `STORAGE_ACCOUNT_URL` | Yes | Azure Blob Storage account URL (e.g. `https://<account>.blob.core.windows.net`) |
| `BLOB_CONTAINER_NAME` | Yes | Primary blob container for models and training data |
| `OUTPUT_CONTAINER_NAME` | No | Container for prediction outputs (defaults to `BLOB_CONTAINER_NAME`) |
| `OUTPUT_FOLDER` | No | Folder prefix for prediction CSVs (default: `predictions`) |
| `AZURE_CLIENT_ID` | No | Managed identity client ID for authentication |
| `MANAGED_IDENTITY_CLIENT_ID` | No | Alternate managed identity client ID |

## config.yaml Reference

All values in `config.yaml` override inline fallback defaults in `project_config.py`. If `config.yaml` is missing, the app runs entirely from inline defaults and environment variables.

| Section | Key | Default | Description |
|---|---|---|---|
| `storage` | `account_url` | env var | Blob storage account URL |
| `storage` | `container_name` | env var | Primary blob container |
| `regressor.blobs` | `model_blob_name` | `model/catboost_regressor_model.cbm` | Regressor model blob path |
| `regressor.training.paths` | `raw_data_blob` | `data/training_raw_dataset_catboost.xlsx` | Regressor training dataset |
| `regressor.training` | `model_hyperparameters` | iterations, lr, depth, etc. | Final model hyperparameters |
| `classifier.blobs` | `model_blob_name` | `model/catboost_classifier_model.cbm` | Classifier model blob path |
| `classifier.training` | `raw_data_blob_default` | `data/catboost_classifier_train_dataset_raw.xlsx` | Classifier training dataset |
| `classifier.training` | `model_hyperparameters` | iterations, lr, depth, etc. | Classifier hyperparameters |

## Blob Storage Folder Structure

```
<container>/
├── data/
│   ├── training_raw_dataset_catboost.xlsx          # Regressor training data
│   └── catboost_classifier_train_dataset_raw.xlsx  # Classifier training data
├── model/
│   ├── catboost_regressor_model.cbm                # Trained regressor model
│   ├── median_map.json                             # Regressor metadata (features, median map)
│   ├── catboost_classifier_model.cbm               # Trained classifier model
│   ├── feature_metadata.json                       # Classifier feature metadata & target encodings
│   └── classifier_metrics.json                     # Classifier evaluation metrics
```

## Endpoints

The project is deployed as an Azure Functions app (Python v2).

**Base URL:** `https://func-sla-catboost-train-uat-eastus.azurewebsites.net`

| Endpoint | Method | Full URL | Purpose |
|---|---|---|---|
| `/catboost_regressor_train` | POST | `https://func-sla-catboost-train-uat-eastus.azurewebsites.net/catboost_regressor_train` | Trains the regression model from raw data in blob storage |
| `/catboost_regressor_infer` | POST | `https://func-sla-catboost-train-uat-eastus.azurewebsites.net/catboost_regressor_infer` | Predicts case closure duration and resolution date |
| `/catboost_classifier_train` | POST | `https://func-sla-catboost-train-uat-eastus.azurewebsites.net/catboost_classifier_train` | Trains the hold/no-hold classifier from raw data in blob storage |
| `/catboost_classifier_infer` | POST | `https://func-sla-catboost-train-uat-eastus.azurewebsites.net/catboost_classifier_infer` | Predicts whether a case will be placed on hold |
| `/train_all` | POST | `https://func-sla-catboost-train-uat-eastus.azurewebsites.net/train_all` | Trains both regressor and classifier models sequentially |
| `/infer_all` | POST | `https://func-sla-catboost-train-uat-eastus.azurewebsites.net/infer_all` | Runs both regressor and classifier inference on the same payload |

Training endpoints load raw data from Azure Blob Storage, run the full pipeline (cleaning, feature engineering, model fitting, evaluation), and save trained model artifacts back to blob. Inference endpoints load cached models and return predictions as JSON, with optional persistence of results to blob storage as CSV.

## Usage
### Inference Request Payload
Both inference endpoints accept the same case record structure:

```json
{
  "TicketNumber": "5-0000012717662",
  "msdyn_receiveddate": "3/24/2025 7:35",
  "msdyn_caserocname": "APOC",
  "msdyn_businessfunctionidname": "Signature to Invoice (S2I)",
  "msdyn_lineofbusinessidname": "VL",
  "msdyn_programidname": "Select Plus",
  "msdyn_casetypeidname": "Transaction",
  "msdyn_casesubtypeidname": "Order",
  "msdyn_casereasonidname": "Order Transaction Request",
  "msdyn_casesubreasonidname": "Additional Product Order",
  "prioritycodename": "3 - Normal",
  "msdyn_complexityname": "Low",
  "msdyn_countrysubmitteridname": "Korea",
  "msdyn_countryprocessedidname": "Singapore",
  "statuscodename": "Completed"
}
```
### Regressor Response
Predicted Resolution Date : 03/24/2025 09:59:00
Predicted Duration (Mins) : 144

### Classifier Response
prediction_label : Hold / No Hold

## Tech Stack
- **Algorithm**: CatBoost (gradient-boosted decision trees)
- **Runtime**: Azure Functions (Python v2 programming model)
- **Storage**: Azure Blob Storage (model artifacts, training data, predictions)
- **Auth**: Azure Managed Identity via DefaultAzureCredential
- **Libraries**: catboost, scikit-learn, pandas, numpy, matplotlib, seaborn