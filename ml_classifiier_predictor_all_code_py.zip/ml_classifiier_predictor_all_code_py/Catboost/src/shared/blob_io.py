import io
import json
import logging
import os
from datetime import datetime
from io import BytesIO, StringIO
from typing import Any, Dict

import pandas as pd
import yaml
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient

# ------------------------------------------------------------------------------
# IMPORTANT: Azure env var names preserved exactly
# ------------------------------------------------------------------------------
STORAGE_ACCOUNT_URL = os.getenv("STORAGE_ACCOUNT_URL")
BLOB_CONTAINER_NAME = os.getenv("BLOB_CONTAINER_NAME")

OUTPUT_CONTAINER_NAME = os.getenv("OUTPUT_CONTAINER_NAME", BLOB_CONTAINER_NAME)


# ------------------------------------------------------------------------------
# Identity / Storage helpers (same as function_app_git.py)
# ------------------------------------------------------------------------------
def get_credential() -> DefaultAzureCredential:
    client_id = os.getenv("AZURE_CLIENT_ID") or os.getenv("MANAGED_IDENTITY_CLIENT_ID")
    return DefaultAzureCredential(managed_identity_client_id=client_id)


def get_blob_service_client() -> BlobServiceClient:
    try:
        credential = get_credential()
        return BlobServiceClient(account_url=STORAGE_ACCOUNT_URL, credential=credential)
    except Exception as e:
        logging.error(
            "Failed to create BlobServiceClient (account_url='%s'): %s",
            STORAGE_ACCOUNT_URL,
            e,
        )
        raise


def get_container_client(container_name: str):
    try:
        svc = get_blob_service_client()
        return svc.get_container_client(container_name)
    except Exception as e:
        logging.error(
            "Failed to create container client (container='%s'): %s", container_name, e
        )
        raise


def get_blob_client(container: str, blob: str):
    try:
        svc = get_blob_service_client()
        return svc.get_blob_client(container=container, blob=blob)
    except ValueError as e:
        logging.error(
            "Invalid blob configuration (container='%s', blob='%s'): %s",
            container,
            blob,
            e,
        )
        raise
    except Exception as e:
        logging.error(
            "Failed to create blob client (container='%s', blob='%s'): %s",
            container,
            blob,
            e,
        )
        raise


# ------------------------------------------------------------------------------
# Generic blob I/O helpers (same behavior)
# ------------------------------------------------------------------------------
def load_blob_to_obj(blob_name: str):
    container_client = get_container_client(BLOB_CONTAINER_NAME)
    blob_client = container_client.get_blob_client(blob_name)
    stream = blob_client.download_blob().readall()

    if blob_name.endswith(".xlsx"):
        return pd.read_excel(io.BytesIO(stream), engine="openpyxl")
    if blob_name.endswith(".csv"):
        return pd.read_csv(io.BytesIO(stream))
    if blob_name.endswith((".yaml", ".yml")):
        return yaml.safe_load(stream)
    if blob_name.endswith(".json"):
        return json.loads(stream.decode("utf-8"))
    return stream


def load_blob_bytes(blob_name: str, container_name: str | None = None) -> bytes:
    container = container_name or BLOB_CONTAINER_NAME
    container_client = get_container_client(container)
    blob_client = container_client.get_blob_client(blob_name)
    return blob_client.download_blob().readall()


def save_bytes_to_blob(blob_name: str, data: bytes, container_name: str | None = None):
    container = container_name or BLOB_CONTAINER_NAME
    container_client = get_container_client(container)
    container_client.upload_blob(name=blob_name, data=data, overwrite=True)


def save_json_to_blob(blob_name: str, obj: Any, container_name: str | None = None):
    data = json.dumps(obj, indent=2).encode("utf-8")
    save_bytes_to_blob(blob_name, data, container_name=container_name)


# ------------------------------------------------------------------------------
# Prediction CSV helpers (same behavior as deployed)
# ------------------------------------------------------------------------------
def save_results_to_blob(
    df_to_save: pd.DataFrame,
    blob_path: str,
    deduplicate_column: str = "TicketNumber",
) -> Dict[str, Any]:
    try:
        blob_client = get_blob_client(OUTPUT_CONTAINER_NAME, blob_path)

        existing_df = pd.DataFrame()
        operation = "created"
        try:
            if hasattr(blob_client, "exists") and blob_client.exists():
                existing_data = blob_client.download_blob().readall()
                existing_df = pd.read_csv(BytesIO(existing_data))
                operation = "appended"
        except Exception:
            existing_df = pd.DataFrame()

        if not existing_df.empty:
            if (
                deduplicate_column in existing_df.columns
                and deduplicate_column in df_to_save.columns
            ):
                existing_keys = set(existing_df[deduplicate_column])
                new_only = df_to_save[~df_to_save[deduplicate_column].isin(existing_keys)]
                duplicates_removed = len(df_to_save) - len(new_only)
                final_df = pd.concat([existing_df, new_only], ignore_index=True)
            else:
                new_only = df_to_save
                final_df = pd.concat([existing_df, df_to_save], ignore_index=True)
                duplicates_removed = 0
        else:
            new_only = df_to_save
            final_df = df_to_save
            duplicates_removed = 0

        final_df["Last Updated"] = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        csv_data = final_df.to_csv(index=False)
        blob_client.upload_blob(csv_data, overwrite=True)

        return {
            "success": True,
            "blob_url": blob_client.url,
            "blob_path": blob_path,
            "operation": operation,
            "new_records": len(new_only),
            "total_records": len(final_df),
            "duplicates_removed": duplicates_removed,
        }
    except Exception as e:
        logging.exception("Failed to save predictions to blob")
        return {"success": False, "error": str(e)}