import json
import logging
import tempfile
from pathlib import Path
from typing import Any, Dict

import numpy as np
import pandas as pd
from catboost import CatBoostClassifier, Pool
from azure.core.exceptions import ResourceNotFoundError

from src.shared import blob_io
from src.classifier.classifier_process_data import classifier_prepare_inference

CLASSIFIER_MODEL: CatBoostClassifier | None = None
CLASSIFIER_META: dict | None = None
CLASSIFIER_METRICS: dict | None = None
CLASSIFIER_THRESHOLD: float | None = None


def _load_classifier_from_path(p: Path) -> CatBoostClassifier:
    m = CatBoostClassifier()
    m.load_model(str(p))
    return m


def _load_json_file(p: Path) -> dict:
    with open(p, "r") as f:
        return json.load(f)


def load_classifier_model_if_needed(
    storage_account_url: str | None,
    blob_container_name: str | None,
    blob_classifier_model_name: str,
    blob_classifier_feature_meta: str,
    blob_classifier_metrics: str,
    local_classifier_model_path: Path,
    local_classifier_meta_path: Path,
    local_classifier_metrics_path: Path,
) -> None:
    global CLASSIFIER_MODEL, CLASSIFIER_META, CLASSIFIER_METRICS, CLASSIFIER_THRESHOLD

    if CLASSIFIER_MODEL is not None and CLASSIFIER_META is not None:
        logging.info("Classifier MODEL already loaded; skipping reload.")
        return

    blob_ok = bool(storage_account_url and blob_container_name)

    model_loaded = False
    if blob_ok:
        try:
            temp_path = Path(tempfile.gettempdir()) / Path(blob_classifier_model_name).name
            logging.info(
                "Loading classifier model from Blob: container='%s', blob='%s'",
                blob_container_name,
                blob_classifier_model_name,
            )
            blob_client = blob_io.get_blob_client(blob_container_name, blob_classifier_model_name)
            if hasattr(blob_client, "exists") and not blob_client.exists():
                raise ResourceNotFoundError("Classifier model blob not found")
            with open(temp_path, "wb") as f:
                blob_client.download_blob().readinto(f)
            CLASSIFIER_MODEL = _load_classifier_from_path(temp_path)
            model_loaded = True
            logging.info("Classifier model loaded from Blob.")
            try:
                temp_path.unlink()
            except Exception:
                pass
        except Exception as e:
            logging.warning("Blob classifier model load failed (%s). Trying local.", e)

    if not model_loaded:
        CLASSIFIER_MODEL = _load_classifier_from_path(local_classifier_model_path)

    meta_loaded = False
    if blob_ok:
        try:
            raw = blob_io.load_blob_bytes(blob_classifier_feature_meta)
            CLASSIFIER_META = json.loads(raw.decode("utf-8"))
            meta_loaded = True
            logging.info("Classifier feature metadata loaded from Blob.")
        except Exception as e:
            logging.warning("Blob classifier meta load failed (%s). Trying local.", e)

    if not meta_loaded:
        CLASSIFIER_META = _load_json_file(local_classifier_meta_path)

    if blob_ok:
        try:
            raw = blob_io.load_blob_bytes(blob_classifier_metrics)
            CLASSIFIER_METRICS = json.loads(raw.decode("utf-8"))
            logging.info("Classifier metrics loaded from Blob.")
        except Exception:
            CLASSIFIER_METRICS = {}
    else:
        try:
            CLASSIFIER_METRICS = _load_json_file(local_classifier_metrics_path)
        except Exception:
            CLASSIFIER_METRICS = {}

    if CLASSIFIER_METRICS:
        CLASSIFIER_THRESHOLD = float(CLASSIFIER_METRICS.get("recommended_threshold", 0.5))
    else:
        CLASSIFIER_THRESHOLD = 0.5


def infer_classifier(
    payload: Dict[str, Any],
    output_folder: str,
    default_classifier_file: str,
    output_container_name: str | None,
    storage_account_url: str | None,
    blob_container_name: str | None,
    blob_classifier_model_name: str,
    blob_classifier_feature_meta: str,
    blob_classifier_metrics: str,
    local_classifier_model_path: Path,
    local_classifier_meta_path: Path,
    local_classifier_metrics_path: Path,
) -> Dict[str, Any]:
    load_classifier_model_if_needed(
        storage_account_url=storage_account_url,
        blob_container_name=blob_container_name,
        blob_classifier_model_name=blob_classifier_model_name,
        blob_classifier_feature_meta=blob_classifier_feature_meta,
        blob_classifier_metrics=blob_classifier_metrics,
        local_classifier_model_path=local_classifier_model_path,
        local_classifier_meta_path=local_classifier_meta_path,
        local_classifier_metrics_path=local_classifier_metrics_path,
    )

    save_to_blob = payload.get("save_to_blob", True)
    custom_filename = payload.get("filename", default_classifier_file)
    deduplicate_column = payload.get("deduplicate_column", "TicketNumber")
    include_input = payload.get("include_input", False)
    threshold_override = payload.get("threshold", None)

    threshold = float(threshold_override) if threshold_override is not None else CLASSIFIER_THRESHOLD

    if "data" in payload:
        records = payload["data"]
    else:
        control_params = {"save_to_blob", "filename", "deduplicate_column", "include_input", "threshold"}
        records = {k: v for k, v in payload.items() if k not in control_params}

    if not isinstance(records, list):
        records = [records]

    df = pd.DataFrame(records)

    X = classifier_prepare_inference(df, CLASSIFIER_META)

    cat_cols = CLASSIFIER_META["categorical_columns"]
    pool = Pool(X, cat_features=cat_cols)
    probas = CLASSIFIER_MODEL.predict_proba(pool)[:, 1]
    preds = (probas >= threshold).astype(int)
    labels = np.where(preds == 1, "Hold", "No Hold")

    result = pd.DataFrame(
        {
            "hold_probability": np.round(probas, 6),
            "prediction": preds,
            "prediction_label": labels,
        }
    )

    if "TicketNumber" in df.columns:
        result.insert(0, "TicketNumber", df["TicketNumber"].values)

    if include_input:
        result = pd.concat([df.reset_index(drop=True), result], axis=1)

    response_data: Dict[str, Any] = {
        "success": True,
        "records_processed": len(df),
        "threshold_used": threshold,
        "hold_count": int(preds.sum()),
        "no_hold_count": int((preds == 0).sum()),
        "results": result.to_dict(orient="records"),
    }

    if save_to_blob:
        if not custom_filename.endswith(".csv"):
            custom_filename = f"{custom_filename}.csv"
        blob_path = f"{output_folder}/{custom_filename}"

        save_info = blob_io.save_results_to_blob(result, blob_path, deduplicate_column)

        if save_info.get("success"):
            response_data.update(
                {
                    "blob_saved": True,
                    "blob_url": save_info["blob_url"],
                    "blob_path": save_info["blob_path"],
                    "operation": save_info["operation"],
                    "new_records": save_info["new_records"],
                    "total_records": save_info["total_records"],
                    "duplicates_removed": save_info.get("duplicates_removed", 0),
                }
            )
        else:
            response_data["blob_saved"] = False
            response_data["blob_error"] = save_info.get("error", "Unknown error")

    return response_data