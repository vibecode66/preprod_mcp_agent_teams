import json
import os
import logging
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

import pandas as pd
from catboost import CatBoostClassifier, Pool
from sklearn.model_selection import train_test_split

from src.shared import blob_io
from src.config import project_config
from src.classifier.classifier_process_data import (
    ALL_CATEGORICAL_COLUMNS,
    CLASSIFIER_FEATURE_COLUMNS,
    CLASSIFIER_TARGET_COLUMN,
    LEAKAGE_COLUMNS,
    SMOOTHING_MIN_COUNT,
    SMOOTHING_STRENGTH,
    classifier_apply_target_encoders,
    classifier_build_base_features,
    classifier_evaluate,
    classifier_fit_target_encoders,
    classifier_make_target,
)


def train_classifier_model(
    storage_account_url: str | None,
    blob_container_name: str | None,
    blob_classifier_model_name: str,
    blob_classifier_feature_meta: str,
    blob_classifier_metrics: str,
) -> Dict[str, Any]:
    logging.info("Classifier training pipeline execution started.")

    if not storage_account_url or not blob_container_name:
        raise ValueError("Missing STORAGE_ACCOUNT_URL or BLOB_CONTAINER_NAME app setting.")

    clf_cfg = project_config.classifier_training_config()

    raw_default = clf_cfg.get("raw_data_blob_default", "data/catboost_classifier_train_dataset_raw.xlsx")
    raw_data_blob = raw_default

    logging.info("Loading classifier training data from blob: %s", raw_data_blob)
    df = blob_io.load_blob_to_obj(raw_data_blob)
    logging.info("Raw shape: %s", df.shape)

    df["createdon"] = pd.to_datetime(df["createdon"], errors="coerce")
    df["msdyn_resolveddate"] = pd.to_datetime(df["msdyn_resolveddate"], errors="coerce")
    before = len(df)
    df = df.dropna(subset=["createdon"]).reset_index(drop=True)
    logging.info("Dropped %d rows with missing 'createdon'. Shape: %s", before - len(df), df.shape)

    df = classifier_make_target(df)

    df = classifier_build_base_features(df)

    split = clf_cfg.get("split", {}) or {}
    test_size_stage1 = float(split.get("test_size_stage1", 0.30))
    test_size_stage2 = float(split.get("test_size_stage2", 0.50))
    random_state = int(split.get("random_state", 42))
    stratify = bool(split.get("stratify", True))

    y = df[CLASSIFIER_TARGET_COLUMN]
    train_df, temp_df = train_test_split(
        df, test_size=test_size_stage1, random_state=random_state, stratify=y if stratify else None
    )
    y_temp = temp_df[CLASSIFIER_TARGET_COLUMN]
    val_df, test_df = train_test_split(
        temp_df,
        test_size=test_size_stage2,
        random_state=random_state,
        stratify=y_temp if stratify else None,
    )

    train_df = train_df.reset_index(drop=True)
    val_df = val_df.reset_index(drop=True)
    test_df = test_df.reset_index(drop=True)

    y_train = train_df[CLASSIFIER_TARGET_COLUMN]
    mappings, global_rate = classifier_fit_target_encoders(train_df, y_train)

    train_df = classifier_apply_target_encoders(train_df, mappings, global_rate)
    val_df = classifier_apply_target_encoders(val_df, mappings, global_rate)
    test_df = classifier_apply_target_encoders(test_df, mappings, global_rate)

    for col in LEAKAGE_COLUMNS:
        assert col not in CLASSIFIER_FEATURE_COLUMNS, f"LEAKAGE DETECTED: {col} in feature list!"

    X_train = train_df[CLASSIFIER_FEATURE_COLUMNS].copy()
    y_train = train_df[CLASSIFIER_TARGET_COLUMN].copy()
    X_val = val_df[CLASSIFIER_FEATURE_COLUMNS].copy()
    y_val = val_df[CLASSIFIER_TARGET_COLUMN].copy()
    X_test = test_df[CLASSIFIER_FEATURE_COLUMNS].copy()
    y_test = test_df[CLASSIFIER_TARGET_COLUMN].copy()

    cat_cols_in_features = [c for c in ALL_CATEGORICAL_COLUMNS if c in CLASSIFIER_FEATURE_COLUMNS]

    for col in cat_cols_in_features:
        X_train[col] = X_train[col].astype(str)
        X_val[col] = X_val[col].astype(str)

    train_pool = Pool(X_train, label=y_train, cat_features=cat_cols_in_features)
    val_pool = Pool(X_val, label=y_val, cat_features=cat_cols_in_features)

    hp = clf_cfg.get("model_hyperparameters", {}) or {}

    model = CatBoostClassifier(
        iterations=int(hp.get("iterations", 500)),
        learning_rate=float(hp.get("learning_rate", 0.05)),
        depth=int(hp.get("depth", 8)),
        l2_leaf_reg=float(hp.get("l2_leaf_reg", 5)),
        auto_class_weights=hp.get("auto_class_weights", "Balanced"),
        eval_metric=hp.get("eval_metric", "AUC"),
        random_seed=int(hp.get("random_seed", 42)),
        early_stopping_rounds=int(hp.get("early_stopping_rounds", 100)),
        verbose=int(hp.get("verbose", 200)),
        use_best_model=bool(hp.get("use_best_model", True)),
        train_dir=os.path.join(tempfile.gettempdir(), str(hp.get("train_dir", "catboost_clf_final"))),
    )

    model.fit(train_pool, eval_set=val_pool)
    best_iteration = model.get_best_iteration()

    eval_threshold = float(clf_cfg.get("evaluation_threshold", 0.5))

    all_metrics = {}
    val_metrics = classifier_evaluate(model, X_val.copy(), y_val, cat_cols_in_features, eval_threshold, "val")
    all_metrics.update(val_metrics)
    test_metrics = classifier_evaluate(model, X_test.copy(), y_test, cat_cols_in_features, eval_threshold, "test")
    all_metrics.update(test_metrics)
    train_metrics = classifier_evaluate(model, X_train.copy(), y_train, cat_cols_in_features, eval_threshold, "train")
    all_metrics.update(train_metrics)

    all_metrics["default_threshold"] = eval_threshold
    all_metrics["recommended_threshold"] = val_metrics.get("val_best_f1_threshold", eval_threshold)

    temp_model_path = Path(tempfile.gettempdir()) / "catboost_classifier_model.cbm"
    model.save_model(str(temp_model_path))

    with open(temp_model_path, "rb") as f:
        blob_io.save_bytes_to_blob(blob_classifier_model_name, f.read())
    logging.info("Classifier model saved to blob: %s", blob_classifier_model_name)

    serializable_mappings = {}
    for feat_name, mapping in mappings.items():
        serializable_mappings[feat_name] = {str(k): float(v) for k, v in mapping.items()}

    feature_meta = {
        "feature_columns": CLASSIFIER_FEATURE_COLUMNS,
        "categorical_columns": cat_cols_in_features,
        "leakage_columns": LEAKAGE_COLUMNS,
        "global_hold_rate_train": round(global_rate, 6),
        "target_encoding_mappings": serializable_mappings,
        "smoothing_min_count": SMOOTHING_MIN_COUNT,
        "smoothing_strength": SMOOTHING_STRENGTH,
        "hyperparameters": {
            "iterations": int(hp.get("iterations", 500)),
            "learning_rate": float(hp.get("learning_rate", 0.05)),
            "depth": int(hp.get("depth", 8)),
            "l2_leaf_reg": float(hp.get("l2_leaf_reg", 5)),
            "auto_class_weights": hp.get("auto_class_weights", "Balanced"),
            "eval_metric": hp.get("eval_metric", "AUC"),
            "random_seed": int(hp.get("random_seed", 42)),
            "early_stopping_rounds": int(hp.get("early_stopping_rounds", 100)),
            "best_iteration": best_iteration,
        },
        "created_at": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
    }
    blob_io.save_json_to_blob(blob_classifier_feature_meta, feature_meta)
    blob_io.save_json_to_blob(blob_classifier_metrics, all_metrics)

    return {
        "success": True,
        "message": "Classifier training complete.",
        "model_blob": blob_classifier_model_name,
        "feature_meta_blob": blob_classifier_feature_meta,
        "metrics_blob": blob_classifier_metrics,
        "best_iteration": best_iteration,
        "recommended_threshold": all_metrics["recommended_threshold"],
        "val_roc_auc": all_metrics.get("val_roc_auc"),
        "val_best_f1": all_metrics.get("val_best_f1"),
        "test_roc_auc": all_metrics.get("test_roc_auc"),
        "test_best_f1": all_metrics.get("test_best_f1"),
        "train_samples": len(train_df),
        "val_samples": len(val_df),
        "test_samples": len(test_df),
    }