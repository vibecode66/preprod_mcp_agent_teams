import numpy as np
import pandas as pd
from catboost import CatBoostClassifier, Pool
from sklearn.metrics import (
    roc_auc_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    average_precision_score,
    precision_recall_curve,
)

# Classifier constants (must match training exactly) — preserved
LEAKAGE_COLUMNS = [
    "HoldTimeInMinutes",
    "ActualCaseTimeinMinutes",
    "CaseTotalDurationinMinutes",
    "msdyn_resolveddate",
]

RAW_CATEGORICAL_COLUMNS = [
    "msdyn_caserocname",
    "msdyn_businessfunctionidname",
    "msdyn_lineofbusinessidname",
    "msdyn_programidname",
    "msdyn_casetypeidname",
    "msdyn_casesubtypeidname",
    "msdyn_casereasonidname",
    "msdyn_casesubreasonidname",
    "prioritycodename",
    "msdyn_complexityname",
    "msdyn_countrysubmitteridname",
    "msdyn_countryprocessedidname",
    "statuscodename",
]

DERIVED_CATEGORICAL_COLUMNS = ["CaseHierarchy", "ReasonGroup", "LOBProgram"]

ALL_CATEGORICAL_COLUMNS = RAW_CATEGORICAL_COLUMNS + DERIVED_CATEGORICAL_COLUMNS

DERIVED_NUMERIC_COLUMNS = [
    "ReasonHoldRate",
    "SubTypeHoldRate",
    "ProgramHoldRate",
    "IsSameCountry",
    "created_hour",
    "created_dayofweek",
    "created_is_weekend",
    "created_month",
]

CLASSIFIER_FEATURE_COLUMNS = (
    RAW_CATEGORICAL_COLUMNS + DERIVED_CATEGORICAL_COLUMNS + DERIVED_NUMERIC_COLUMNS
)

CLASSIFIER_TARGET_COLUMN = "IsHold"

SMOOTHING_MIN_COUNT = 30
SMOOTHING_STRENGTH = 10


def classifier_make_target(df: pd.DataFrame) -> pd.DataFrame:
    df["HoldTimeInMinutes"] = pd.to_numeric(df["HoldTimeInMinutes"], errors="coerce").fillna(0)
    df[CLASSIFIER_TARGET_COLUMN] = (df["HoldTimeInMinutes"] > 0).astype(int)
    return df


def classifier_build_base_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["createdon"] = pd.to_datetime(df["createdon"], errors="coerce")

    for col in RAW_CATEGORICAL_COLUMNS:
        df[col] = df[col].fillna("__MISSING__").astype(str)

    df["created_hour"] = df["createdon"].dt.hour
    df["created_dayofweek"] = df["createdon"].dt.dayofweek
    df["created_is_weekend"] = (df["created_dayofweek"] >= 5).astype(int)
    df["created_month"] = df["createdon"].dt.month

    df["IsSameCountry"] = (df["msdyn_countrysubmitteridname"] == df["msdyn_countryprocessedidname"]).astype(int)

    df["CaseHierarchy"] = df["msdyn_casetypeidname"].astype(str) + "_" + df["msdyn_casesubtypeidname"].astype(str)
    df["ReasonGroup"] = df["msdyn_casereasonidname"].astype(str) + "_" + df["msdyn_casesubreasonidname"].astype(str)
    df["LOBProgram"] = df["msdyn_lineofbusinessidname"].astype(str) + "_" + df["msdyn_programidname"].astype(str)

    for col in DERIVED_CATEGORICAL_COLUMNS:
        df[col] = df[col].astype(str)

    return df


def _compute_smoothed_rate(group_series: pd.Series, target_series: pd.Series, global_rate: float) -> dict:
    stats = pd.DataFrame({"group": group_series, "target": target_series})
    agg = stats.groupby("group")["target"].agg(["mean", "count"])
    agg["smoothed"] = (agg["count"] * agg["mean"] + SMOOTHING_STRENGTH * global_rate) / (
        agg["count"] + SMOOTHING_STRENGTH
    )
    agg.loc[agg["count"] < SMOOTHING_MIN_COUNT, "smoothed"] = global_rate
    return agg["smoothed"].to_dict()


def classifier_fit_target_encoders(train_df: pd.DataFrame, y_train: pd.Series) -> tuple:
    global_rate = float(y_train.mean())
    mappings = {}
    mappings["ReasonHoldRate"] = _compute_smoothed_rate(train_df["ReasonGroup"], y_train, global_rate)
    mappings["SubTypeHoldRate"] = _compute_smoothed_rate(train_df["msdyn_casesubtypeidname"], y_train, global_rate)
    mappings["ProgramHoldRate"] = _compute_smoothed_rate(train_df["msdyn_programidname"], y_train, global_rate)
    return mappings, global_rate


def classifier_apply_target_encoders(df: pd.DataFrame, mappings: dict, global_rate: float) -> pd.DataFrame:
    df["ReasonHoldRate"] = df["ReasonGroup"].map(mappings["ReasonHoldRate"]).fillna(global_rate).astype(float)
    df["SubTypeHoldRate"] = (
        df["msdyn_casesubtypeidname"].map(mappings["SubTypeHoldRate"]).fillna(global_rate).astype(float)
    )
    df["ProgramHoldRate"] = df["msdyn_programidname"].map(mappings["ProgramHoldRate"]).fillna(global_rate).astype(float)
    return df


def classifier_evaluate(
    model: CatBoostClassifier,
    X: pd.DataFrame,
    y: pd.Series,
    cat_cols: list,
    threshold: float = 0.5,
    set_name: str = "val",
) -> dict:
    for col in cat_cols:
        X[col] = X[col].astype(str)

    pool = Pool(X, cat_features=cat_cols)
    y_prob = model.predict_proba(pool)[:, 1]
    y_pred = (y_prob >= threshold).astype(int)

    roc_auc = roc_auc_score(y, y_prob)
    pr_auc = average_precision_score(y, y_prob)
    precision = precision_score(y, y_pred, zero_division=0)
    recall = recall_score(y, y_pred, zero_division=0)
    f1 = f1_score(y, y_pred, zero_division=0)
    cm = confusion_matrix(y, y_pred).tolist()

    precisions, recalls, thresholds = precision_recall_curve(y, y_prob)
    f1_scores = np.where((precisions + recalls) > 0, 2 * precisions * recalls / (precisions + recalls), 0)
    best_idx = np.argmax(f1_scores)
    best_threshold = float(thresholds[best_idx]) if best_idx < len(thresholds) else 0.5
    best_f1 = float(f1_scores[best_idx])

    y_pred_best = (y_prob >= best_threshold).astype(int)
    precision_best = precision_score(y, y_pred_best, zero_division=0)
    recall_best = recall_score(y, y_pred_best, zero_division=0)
    f1_best = f1_score(y, y_pred_best, zero_division=0)
    cm_best = confusion_matrix(y, y_pred_best).tolist()

    metrics = {
        f"{set_name}_roc_auc": round(roc_auc, 5),
        f"{set_name}_pr_auc": round(pr_auc, 5),
        f"{set_name}_precision_at_0.5": round(precision, 5),
        f"{set_name}_recall_at_0.5": round(recall, 5),
        f"{set_name}_f1_at_0.5": round(f1, 5),
        f"{set_name}_confusion_matrix_at_0.5": cm,
        f"{set_name}_best_f1_threshold": round(best_threshold, 5),
        f"{set_name}_best_f1": round(best_f1, 5),
        f"{set_name}_precision_at_best_threshold": round(precision_best, 5),
        f"{set_name}_recall_at_best_threshold": round(recall_best, 5),
        f"{set_name}_f1_at_best_threshold": round(f1_best, 5),
        f"{set_name}_confusion_matrix_at_best_threshold": cm_best,
    }

    return metrics


def classifier_prepare_inference(df: pd.DataFrame, classifier_meta: dict) -> pd.DataFrame:
    leak = [c for c in LEAKAGE_COLUMNS if c in df.columns]
    if leak:
        df = df.drop(columns=leak)

    df = classifier_build_base_features(df)

    global_rate = classifier_meta["global_hold_rate_train"]
    te_mappings = classifier_meta["target_encoding_mappings"]

    df["ReasonHoldRate"] = df["ReasonGroup"].map(te_mappings["ReasonHoldRate"]).fillna(global_rate).astype(float)
    df["SubTypeHoldRate"] = (
        df["msdyn_casesubtypeidname"].map(te_mappings["SubTypeHoldRate"]).fillna(global_rate).astype(float)
    )
    df["ProgramHoldRate"] = (
        df["msdyn_programidname"].map(te_mappings["ProgramHoldRate"]).fillna(global_rate).astype(float)
    )

    feature_columns = classifier_meta["feature_columns"]
    categorical_columns = classifier_meta["categorical_columns"]

    missing = [c for c in feature_columns if c not in df.columns]
    if missing:
        raise ValueError(f"Required feature columns missing from input: {missing}")

    X = df[feature_columns].copy()
    for col in categorical_columns:
        if col in X.columns:
            X[col] = X[col].astype(str)
    return X