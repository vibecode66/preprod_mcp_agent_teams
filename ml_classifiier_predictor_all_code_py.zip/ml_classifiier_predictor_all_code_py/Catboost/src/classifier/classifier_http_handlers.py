import json
import os
import logging
from pathlib import Path

import azure.functions as func
from src.config import project_config as project_config

from src.classifier.classifier_infer import infer_classifier
from src.classifier.classifier_train import train_classifier_model


def register_classifier_routes(app: func.FunctionApp) -> None:
    # -----------------------------------------------------------------------------
    # Shared Configuration — YAML-first, fallback to project defaults
    # -----------------------------------------------------------------------------
    STORAGE_ACCOUNT_URL = project_config.storage_account_url()
    BLOB_CONTAINER_NAME = project_config.blob_container_name()

    # Classifier model blob paths (YAML-first; fallback to project defaults)
    try:
        BLOB_CLASSIFIER_MODEL_NAME = project_config.classifier_blob_name()
    except Exception:
        BLOB_CLASSIFIER_MODEL_NAME = "model/catboost_classifier_model.cbm"
    BLOB_CLASSIFIER_FEATURE_META = project_config.classifier_feature_metadata_blob_name()
    BLOB_CLASSIFIER_METRICS = project_config.classifier_metrics_blob_name()

    # Inference output
    OUTPUT_CONTAINER_NAME = project_config.output_container_name() or BLOB_CONTAINER_NAME

    # Keep EXACT deployed reference behavior
    OUTPUT_FOLDER = project_config.output_folder_default()

    DEFAULT_CLASSIFIER_FILE = project_config.default_classifier_filename()

    # Local fallback (mainly for local dev; preserved)
    LOCAL_CLASSIFIER_MODEL_PATH = Path(project_config.local_classifier_model_path())
    LOCAL_CLASSIFIER_META_PATH = Path(project_config.local_classifier_meta_path())
    LOCAL_CLASSIFIER_METRICS_PATH = Path(project_config.local_classifier_metrics_path())

    # =============================================================================
    # HTTP Function: Classifier Training
    # =============================================================================
    @app.function_name(name="catboost_classifier_train")
    @app.route(route="catboost_classifier_train", methods=["POST"])
    def catboost_classifier_train(req: func.HttpRequest) -> func.HttpResponse:
        logging.info("Classifier training pipeline execution started.")

        try:
            response_data = train_classifier_model(
                storage_account_url=STORAGE_ACCOUNT_URL,
                blob_container_name=BLOB_CONTAINER_NAME,
                blob_classifier_model_name=BLOB_CLASSIFIER_MODEL_NAME,
                blob_classifier_feature_meta=BLOB_CLASSIFIER_FEATURE_META,
                blob_classifier_metrics=BLOB_CLASSIFIER_METRICS,
            )

            return func.HttpResponse(
                json.dumps(response_data, indent=2),
                status_code=200,
                mimetype="application/json",
            )

        except Exception as e:
            logging.exception("Error during classifier training execution")
            return func.HttpResponse(
                json.dumps({"success": False, "error": str(e)}, indent=2),
                status_code=500,
                mimetype="application/json",
            )

    # =============================================================================
    # HTTP Function: Classifier Inference
    # =============================================================================
    @app.function_name(name="catboost_classifier_infer")
    @app.route(route="catboost_classifier_infer", methods=["POST"])
    def catboost_classifier_infer(req: func.HttpRequest) -> func.HttpResponse:
        try:
            try:
                payload = req.get_json()
            except ValueError:
                return func.HttpResponse(
                    json.dumps({"success": False, "error": "Invalid JSON"}),
                    status_code=400,
                    mimetype="application/json",
                )

            response_data = infer_classifier(
                payload=payload,
                output_folder=OUTPUT_FOLDER,
                default_classifier_file=DEFAULT_CLASSIFIER_FILE,
                output_container_name=OUTPUT_CONTAINER_NAME,
                storage_account_url=STORAGE_ACCOUNT_URL,
                blob_container_name=BLOB_CONTAINER_NAME,
                blob_classifier_model_name=BLOB_CLASSIFIER_MODEL_NAME,
                blob_classifier_feature_meta=BLOB_CLASSIFIER_FEATURE_META,
                blob_classifier_metrics=BLOB_CLASSIFIER_METRICS,
                local_classifier_model_path=LOCAL_CLASSIFIER_MODEL_PATH,
                local_classifier_meta_path=LOCAL_CLASSIFIER_META_PATH,
                local_classifier_metrics_path=LOCAL_CLASSIFIER_METRICS_PATH,
            )

            return func.HttpResponse(
                json.dumps(response_data, indent=2, default=str),
                status_code=200,
                mimetype="application/json",
            )

        except Exception as e:
            logging.exception("Unhandled error in classifier_infer.")
            return func.HttpResponse(
                json.dumps({"success": False, "error": str(e)}),
                status_code=500,
                mimetype="application/json",
            )