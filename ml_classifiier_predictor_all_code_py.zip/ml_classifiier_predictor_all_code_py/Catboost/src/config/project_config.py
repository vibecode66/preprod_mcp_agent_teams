from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict

import yaml

_CONFIG_PATH = Path(__file__).resolve().parent / "config.yaml"


def _safe_load_yaml() -> Dict[str, Any]:
    """
    Azure-only safe behavior:
    - If config.yaml is missing/not packaged, return {}
    - Never block function startup due to YAML problems
    """
    try:
        if _CONFIG_PATH.exists():
            with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
                return data if isinstance(data, dict) else {}
    except Exception:
        return {}
    return {}


_YAML_CFG: Dict[str, Any] = _safe_load_yaml()


def _get(cfg: Dict[str, Any], path: str, default: Any = None) -> Any:
    node: Any = cfg
    for part in path.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node


def _deep_merge(base: Any, override: Any) -> Any:
    """
    Deep-merge override onto base:
    - dict: merge keys recursively
    - list/scalar: override if override is not None, else keep base
    """
    if override is None:
        return base

    if isinstance(base, dict) and isinstance(override, dict):
        out = dict(base)
        for k, v in override.items():
            out[k] = _deep_merge(out.get(k), v)
        return out

    # For lists and scalars, YAML wins as long as it is not None.
    return override


# -----------------------------------------------------------------------------
# Inline fallback configs (copied from function_app_git.py)
# -----------------------------------------------------------------------------
def regressor_training_fallback_inline() -> Dict[str, Any]:
    return {
        "paths": {
            "raw_data_blob": "data/training_raw_dataset_catboost.xlsx",
            "processed_data_blob": "data/processed/cleaned_data.csv",
            "plot_folder_blob_prefix": "visualization/figures/",
            "model_path_unused": "models/catboost_model_feb2026.cbm",
            "demo_results_blob": "data/processed/predictions_feb2026.csv",
        },
        "params": {
            "target_col": "target_minutes",
            "test_size": 0.3,
            "random_state": 40,
            "outlier_quantile": 0.75,
            "min_target_minutes": 30,
            "max_target_minutes": 43200,
            "candidate_features": [
                "msdyn_caserocname",
                "msdyn_casereasonidname",
                "msdyn_casesubreasonidname",
                "msdyn_casesubtypeidname",
                "msdyn_casetypeidname",
                "msdyn_countrysubmitteridname",
                "hour_of_day",
                "day_of_week",
                "daily_volume",
                "reason_median_speed",
                "msdyn_businessfunctionidname",
                "msdyn_lineofbusinessidname",
                "msdyn_programidname",
                "backlog_4h",
                "backlog_24h",
            ],
            "categorical_cols": [
                "msdyn_caserocname",
                "msdyn_casereasonidname",
                "msdyn_casesubreasonidname",
                "msdyn_casesubtypeidname",
                "msdyn_casetypeidname",
                "msdyn_countrysubmitteridname",
                "hour_of_day",
                "day_of_week",
                "msdyn_businessfunctionidname",
                "msdyn_lineofbusinessidname",
                "msdyn_programidname",
            ],
        },
        "model_hyperparameters": {
            "iterations": 3000,
            "learning_rate": 0.015,
            "depth": 10,
            "loss_function": "MAE",
            "verbose": 100,
            "train_dir": "catboost_info",
        },
    }


def classifier_training_fallback_inline() -> Dict[str, Any]:
    return {
        "raw_data_blob_default": "data/catboost_classifier_train_dataset_raw.xlsx",
        "split": {
            "test_size_stage1": 0.30,
            "test_size_stage2": 0.50,
            "random_state": 42,
            "stratify": True,
        },
        "model_hyperparameters": {
            "iterations": 500,
            "learning_rate": 0.05,
            "depth": 8,
            "l2_leaf_reg": 5,
            "auto_class_weights": "Balanced",
            "eval_metric": "AUC",
            "random_seed": 42,
            "early_stopping_rounds": 100,
            "verbose": 200,
            "use_best_model": True,
            "train_dir": "catboost_clf_final",
        },
        "evaluation_threshold": 0.5,
    }


# -----------------------------------------------------------------------------
# Public accessors: YAML-first (per-key), fallback inline for missing keys
# -----------------------------------------------------------------------------
def regressor_training_config() -> Dict[str, Any]:
    base = regressor_training_fallback_inline()
    y = _get(_YAML_CFG, "regressor.training", {}) or {}
    if not isinstance(y, dict):
        y = {}
    return _deep_merge(base, y)


def classifier_training_config() -> Dict[str, Any]:
    base = classifier_training_fallback_inline()
    y = _get(_YAML_CFG, "classifier.training", {}) or {}
    if not isinstance(y, dict):
        y = {}
    return _deep_merge(base, y)


def output_folder_default() -> str:
    v = _get(_YAML_CFG, "outputs.folder", None)
    if isinstance(v, str) and v:
        return v
    return os.getenv("OUTPUT_FOLDER", "predictions")


# -----------------------------------------------------------------------------
# Storage / blob accessors — YAML-first, fallback to env vars
# -----------------------------------------------------------------------------
def storage_account_url() -> str | None:
    v = _get(_YAML_CFG, "storage.account_url", None)
    if isinstance(v, str) and v:
        return v
    return os.getenv("STORAGE_ACCOUNT_URL")


def blob_container_name() -> str | None:
    v = _get(_YAML_CFG, "storage.container_name", None)
    if isinstance(v, str) and v:
        return v
    return os.getenv("BLOB_CONTAINER_NAME")


def output_container_name() -> str | None:
    v = _get(_YAML_CFG, "outputs.container_name", None)
    if isinstance(v, str) and v:
        return v
    return os.getenv("OUTPUT_CONTAINER_NAME")


# -----------------------------------------------------------------------------
# Regressor blob name
# -----------------------------------------------------------------------------
DEFAULT_REGRESSOR_BLOB_NAME = "model/catboost_regressor_model.cbm"


def regressor_blob_name() -> str:
    v = _get(_YAML_CFG, "regressor.blobs.model_blob_name", None)
    return v if isinstance(v, str) and v else DEFAULT_REGRESSOR_BLOB_NAME


# -----------------------------------------------------------------------------
# Classifier blob names
# -----------------------------------------------------------------------------
DEFAULT_CLASSIFIER_BLOB_NAME = "model/catboost_classifier_model.cbm"


def classifier_blob_name() -> str:
    v = _get(_YAML_CFG, "classifier.blobs.model_blob_name", None)
    return v if isinstance(v, str) and v else DEFAULT_CLASSIFIER_BLOB_NAME


def classifier_feature_metadata_blob_name() -> str:
    v = _get(_YAML_CFG, "classifier.blobs.feature_metadata_blob_name", None)
    return v if isinstance(v, str) and v else "model/feature_metadata.json"


def classifier_metrics_blob_name() -> str:
    v = _get(_YAML_CFG, "classifier.blobs.metrics_blob_name", None)
    return v if isinstance(v, str) and v else "model/classifier_metrics.json"


# -----------------------------------------------------------------------------
# Output defaults
# -----------------------------------------------------------------------------
def default_regressor_filename() -> str:
    v = _get(_YAML_CFG, "outputs.defaults.regressor_filename", None)
    return v if isinstance(v, str) and v else "sla_output_results.csv"


def default_classifier_filename() -> str:
    v = _get(_YAML_CFG, "outputs.defaults.classifier_filename", None)
    return v if isinstance(v, str) and v else "hold_predictions.csv"


def default_deduplicate_column() -> str:
    v = _get(_YAML_CFG, "outputs.defaults.deduplicate_column", None)
    return v if isinstance(v, str) and v else "TicketNumber"


# -----------------------------------------------------------------------------
# Local fallback paths
# -----------------------------------------------------------------------------
def local_regressor_model_path() -> str:
    v = _get(_YAML_CFG, "local_fallback.regressor_model_path", None)
    return v if isinstance(v, str) and v else r"C:\temp\Model\catboost_regressor_model.cbm"


def local_classifier_model_path() -> str:
    v = _get(_YAML_CFG, "local_fallback.classifier_model_path", None)
    return v if isinstance(v, str) and v else r"C:\temp\Model\catboost_hold_classifier.cbm"


def local_classifier_meta_path() -> str:
    v = _get(_YAML_CFG, "local_fallback.classifier_meta_path", None)
    return v if isinstance(v, str) and v else r"C:\temp\Model\feature_metadata.json"


def local_classifier_metrics_path() -> str:
    v = _get(_YAML_CFG, "local_fallback.classifier_metrics_path", None)
    return v if isinstance(v, str) and v else r"C:\temp\Model\classifier_metrics.json"