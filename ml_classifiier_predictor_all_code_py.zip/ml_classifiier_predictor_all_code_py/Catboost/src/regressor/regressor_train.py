import io
import json
import logging
import os
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from catboost import CatBoostRegressor
from sklearn.model_selection import train_test_split

from src.shared import blob_io
from src.config import project_config
from src.regressor.regressor_process_data import (
    clean_and_engineer,
    clean_categorical_strings,
    select_top_features,
)


def train_regressor_model(
    storage_account_url: str | None,
    blob_container_name: str | None,
    blob_model_name: str,
) -> Dict[str, Any]:
    logging.info("Regression ML Pipeline execution started.")

    if not storage_account_url or not blob_container_name:
        raise ValueError("Missing STORAGE_ACCOUNT_URL or BLOB_CONTAINER_NAME app setting.")

    train_cfg = project_config.regressor_training_config()
    paths = train_cfg.get("paths", {}) or {}
    params = train_cfg.get("params", {}) or {}

    raw_blob = paths.get("raw_data_blob", "data/training_raw_dataset_catboost.xlsx")
    plot_folder = (paths.get("plot_folder_blob_prefix", "visualization/figures/") or "").strip("/")

    df_raw_loaded = blob_io.load_blob_to_obj(raw_blob)
    df_raw = df_raw_loaded.rename(columns={"createdon": "msdyn_receiveddate"})
    df_raw["msdyn_receiveddate"] = pd.to_datetime(df_raw["msdyn_receiveddate"], errors="coerce")

    df_raw = df_raw[df_raw["msdyn_receiveddate"].dt.year >= 2025].copy()
    df_raw = df_raw[
        (df_raw["msdyn_resolveddate"].notna())
        & (df_raw["msdyn_caserocname"].notna())
        & (((df_raw.get("onholdtime", 0) == 0)) | (df_raw.get("onholdtime").isna()))
    ].copy()

    outlier_q = float(params.get("outlier_quantile", 0.75))
    min_t = float(params.get("min_target_minutes", 0))
    max_t = float(params.get("max_target_minutes", 43200))

    df_clean, median_map = clean_and_engineer(
        df_raw,
        quantile_limit=outlier_q,
        min_target_minutes=min_t,
        max_target_minutes=max_t,
    )

    categorical_cols = params.get("categorical_cols", [])
    df_clean = clean_categorical_strings(df_clean, categorical_cols)

    target_col = params.get("target_col", "target_minutes")

    plt.figure(figsize=(12, 6))
    sns.histplot(df_clean[target_col], bins=40, kde=True, color="purple")
    img_buf = io.BytesIO()
    plt.savefig(img_buf, format="png", bbox_inches="tight")
    plt.close()
    img_buf.seek(0)

    blob_io.save_bytes_to_blob(f"{plot_folder}/target_distribution_y.png", img_buf.getvalue())

    candidate_features = params.get("candidate_features", [])
    top_features = select_top_features(df_clean, candidate_features, categorical_cols, target_col)

    final_cat_features = [f for f in top_features if f in categorical_cols]

    X = df_clean[top_features]
    y = np.log1p(df_clean[target_col])

    test_size = float(params.get("test_size", 0.3))
    random_state = int(params.get("random_state", 40))

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    hp = train_cfg.get("model_hyperparameters", {}) or {}

    regressor_kwargs = dict(
        iterations=int(hp.get("iterations", 3000)),
        learning_rate=float(hp.get("learning_rate", 0.015)),
        depth=int(hp.get("depth", 10)),
        loss_function=hp.get("loss_function", "MAE"),
        cat_features=final_cat_features,
        verbose=int(hp.get("verbose", 100)),
        train_dir=os.path.join(tempfile.gettempdir(), str(hp.get("train_dir", "catboost_info"))),
    )

    # Optional: only include if present in YAML/fallback config
    if "l2_leaf_reg" in hp and hp.get("l2_leaf_reg") is not None:
        regressor_kwargs["l2_leaf_reg"] = float(hp["l2_leaf_reg"])

    final_model = CatBoostRegressor(**regressor_kwargs)
    final_model.fit(X_train, y_train, eval_set=(X_test, y_test))

    temp_model_path = Path(tempfile.gettempdir()) / "catboost_regressor_model.cbm"
    final_model.save_model(str(temp_model_path))

    container_client = blob_io.get_container_client(blob_container_name)
    with open(temp_model_path, "rb") as f:
        container_client.upload_blob(name=blob_model_name, data=f, overwrite=True)

    global_median = df_clean[target_col].median()
    metadata = {
        "global_median": float(global_median),
        "median_map": median_map.to_dict(),
        "features": top_features,
        "trained_at": datetime.utcnow().isoformat(),
        "model_blob": blob_model_name,
    }
    metadata_blob_path = f"{os.path.dirname(blob_model_name)}/median_map.json"
    blob_io.save_json_to_blob(metadata_blob_path, metadata)

    return {
        "success": True,
        "message": f"Regression model saved to {blob_model_name}",
        "features_used": top_features,
        "metadata_saved_to": metadata_blob_path,
    }