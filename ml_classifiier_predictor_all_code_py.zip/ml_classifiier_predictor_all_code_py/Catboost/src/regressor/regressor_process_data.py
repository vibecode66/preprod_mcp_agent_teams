import tempfile
import os
from pathlib import Path
from typing import List, Tuple

import numpy as np
import pandas as pd
from catboost import CatBoostRegressor


def adjust_for_weekend(dt: pd.Timestamp) -> pd.Timestamp:
    if pd.isna(dt) or not hasattr(dt, "weekday"):
        return dt
    wd = dt.weekday()
    if wd == 5:
        return dt + pd.Timedelta(days=2)
    if wd == 6:
        return dt + pd.Timedelta(days=1)
    return dt


def ensure_features(df: pd.DataFrame, required_features: List[str], cat_indices: List[int]) -> pd.DataFrame:
    cat_set = {required_features[i] for i in cat_indices if 0 <= i < len(required_features)}
    for col in required_features:
        if col not in df.columns:
            df[col] = "Unknown" if col in cat_set else 0
        if col in cat_set:
            df[col] = df[col].astype(str).fillna("Unknown")
        else:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    return df[required_features]


def prepare_final_output(
    df: pd.DataFrame,
    predictions_minutes: np.ndarray,
    predicted_dates: pd.Series,
) -> pd.DataFrame:
    results = pd.DataFrame()

    results["TicketNumber"] = df["TicketNumber"] if "TicketNumber" in df.columns else range(1, len(df) + 1)

    if "msdyn_receiveddate" in df.columns:
        received_dt = pd.to_datetime(df["msdyn_receiveddate"], errors="coerce")
        results["Received Date"] = received_dt.dt.strftime("%m/%d/%Y %H:%M:%S")
    else:
        results["Received Date"] = None

    pred_dt = pd.to_datetime(predicted_dates, errors="coerce")
    results["Predicted Resolution Date"] = pred_dt.dt.strftime("%m/%d/%Y %H:%M:%S")

    actual_res_date_col = None
    for col_name in ["msdyn_resolveddate", "resolved_date", "actual_resolved_date", "modifiedon"]:
        if col_name in df.columns:
            actual_res_date_col = col_name
            break

    has_actual_date = False
    if actual_res_date_col:
        actual_dt = pd.to_datetime(df[actual_res_date_col], errors="coerce")
        if actual_dt.notna().any():
            has_actual_date = True
            results["Actual Resolution Date"] = actual_dt.dt.strftime("%m/%d/%Y %H:%M:%S")
        else:
            results["Actual Resolution Date"] = None
    else:
        results["Actual Resolution Date"] = None

    results["Predicted Duration (Mins)"] = predictions_minutes.round(0).astype(int)

    if actual_res_date_col and "msdyn_receiveddate" in df.columns:
        received_dt = pd.to_datetime(df["msdyn_receiveddate"], errors="coerce")
        resolved_dt = pd.to_datetime(df[actual_res_date_col], errors="coerce")
        actual_duration = (resolved_dt - received_dt).dt.total_seconds() / 60
        results["Actual Duration (Mins)"] = actual_duration.round(0).astype("Int64")
    elif "actual_duration" in df.columns:
        results["Actual Duration (Mins)"] = (
            pd.to_numeric(df["actual_duration"], errors="coerce").round(0).astype("Int64")
        )
    else:
        results["Actual Duration (Mins)"] = None

    if results["Actual Duration (Mins)"].notna().any():
        results["Delta (Mins)"] = (
            results["Actual Duration (Mins)"] - results["Predicted Duration (Mins)"]
        ).round(0)
    else:
        results["Delta (Mins)"] = None

    if has_actual_date and "Actual Resolution Date" in results.columns:
        delta_seconds = (actual_dt - pred_dt).dt.total_seconds()
        delta_minutes = delta_seconds / 60
        results["SLA Status"] = delta_minutes.apply(
            lambda x: "Delay" if x > 0 else ("Early" if x < 0 else "On Time")
        )
    else:
        results["SLA Status"] = "Pending"

    additional_columns = [
        "msdyn_caserocname",
        "msdyn_businessfunctionidname",
        "msdyn_lineofbusinessidname",
        "msdyn_programidname",
        "msdyn_casetypeidname",
        "msdyn_casesubtypeidname",
        "msdyn_casereasonidname",
        "msdyn_casesubreasonidname",
        "prioritycodename",
        "msdyn_countrysubmitteridname",
        "msdyn_countryprocessedidname",
    ]
    for col in additional_columns:
        results[col] = df[col].values if col in df.columns else None

    return results


# Regression training helpers
def clean_and_engineer(
    df,
    quantile_limit=0.75,
    min_target_minutes: float = 30,
    max_target_minutes: float = 43200,
):
    df["received_dt"] = pd.to_datetime(df["msdyn_receiveddate"], errors="coerce")
    df["resolved_dt"] = pd.to_datetime(df["msdyn_resolveddate"], errors="coerce")
    df = df.dropna(subset=["received_dt", "resolved_dt"])

    df["target_minutes"] = (df["resolved_dt"] - df["received_dt"]).dt.total_seconds() / 60
    df = df[
        (df["target_minutes"] > min_target_minutes)
        & (df["target_minutes"] < max_target_minutes)
    ]

    df = df.sort_values("received_dt").set_index("received_dt")
    df["backlog_4h"] = df["msdyn_caserocname"].rolling(window="4h").count() - 1
    df["backlog_24h"] = df["msdyn_caserocname"].rolling(window="24h").count() - 1
    df = df.reset_index()

    df["daily_volume"] = df.groupby(df["received_dt"].dt.date)["msdyn_caserocname"].transform("count")
    df["hour_of_day"] = df["received_dt"].dt.hour.astype(str)
    df["day_of_week"] = df["received_dt"].dt.dayofweek.astype(str)

    upper_limit = df["target_minutes"].quantile(quantile_limit)
    df_clean = df[df["target_minutes"] < upper_limit].copy()
    median_map = df_clean.groupby("msdyn_casereasonidname")["target_minutes"].median()
    df_clean["reason_median_speed"] = df_clean["msdyn_casereasonidname"].map(median_map)
    return df_clean, median_map


def clean_categorical_strings(df, cat_cols):
    for col in cat_cols:
        df[col] = (
            df[col]
            .map(lambda x: str(int(x)) if pd.notnull(x) and isinstance(x, (float, int)) else str(x))
            .replace("nan", "Unknown")
        )
    return df


def select_top_features(df, candidate_features, categorical_cols, target_col, top_n=8):
    X_temp = df[candidate_features]
    y_temp = np.log1p(df[target_col])
    selector_model = CatBoostRegressor(
        iterations=300,
        cat_features=categorical_cols,
        verbose=0,
        train_dir=os.path.join(tempfile.gettempdir(), "catboost_info_select"),
    )
    selector_model.fit(X_temp, y_temp)
    feat_imp = pd.Series(selector_model.get_feature_importance(), index=candidate_features).sort_values(
        ascending=False
    )
    return feat_imp.head(top_n).index.tolist()