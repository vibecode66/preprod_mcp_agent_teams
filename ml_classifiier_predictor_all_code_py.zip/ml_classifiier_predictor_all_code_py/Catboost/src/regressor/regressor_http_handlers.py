import json
import os
import logging
from pathlib import Path

import azure.functions as func
from src.config import project_config as project_config

from src.regressor.regressor_infer import infer_regressor
from src.regressor.regressor_train import train_regressor_model


def register_regressor_routes(app: func.FunctionApp) -> None:
    # -----------------------------------------------------------------------------
    # Shared Configuration — YAML-first, fallback to project defaults
    # -----------------------------------------------------------------------------
    STORAGE_ACCOUNT_URL = project_config.storage_account_url()
    BLOB_CONTAINER_NAME = project_config.blob_container_name()

    # Regression model blob path/name (YAML-first; fallback to project defaults)
    try:
        BLOB_MODEL_NAME = project_config.regressor_blob_name()
    except Exception:
        BLOB_MODEL_NAME = "model/catboost_regressor_model.cbm"

    # Inference output
    OUTPUT_CONTAINER_NAME = project_config.output_container_name() or BLOB_CONTAINER_NAME

    # Keep EXACT deployed reference behavior
    OUTPUT_FOLDER = project_config.output_folder_default()

    DEFAULT_MASTER_FILE = project_config.default_regressor_filename()

    # Local fallback (mainly for local dev; preserved)
    LOCAL_MODEL_PATH = Path(project_config.local_regressor_model_path())

    # =============================================================================
    # HTTP Function 1: Regression Inference
    # =============================================================================
    @app.function_name(name="catboost_regressor_infer")
    @app.route(route="catboost_regressor_infer", methods=["POST"])
    def catboost_regressor_infer(req: func.HttpRequest) -> func.HttpResponse:
        try:
            load_regressor_payload = None
            try:
                load_regressor_payload = req.get_json()
            except ValueError:
                return func.HttpResponse(
                    json.dumps({"success": False, "error": "Invalid JSON"}),
                    status_code=400,
                    mimetype="application/json",
                )

            response_data = infer_regressor(
                payload=load_regressor_payload,
                output_folder=OUTPUT_FOLDER,
                default_master_file=DEFAULT_MASTER_FILE,
                output_container_name=OUTPUT_CONTAINER_NAME,
                storage_account_url=STORAGE_ACCOUNT_URL,
                blob_container_name=BLOB_CONTAINER_NAME,
                blob_model_name=BLOB_MODEL_NAME,
                local_model_path=LOCAL_MODEL_PATH,
            )

            return func.HttpResponse(
                json.dumps(response_data, indent=2, default=str),
                status_code=200,
                mimetype="application/json",
            )

        except Exception as e:
            logging.exception("Unhandled error in catboost_infer.")
            return func.HttpResponse(
                json.dumps({"success": False, "error": str(e)}),
                status_code=500,
                mimetype="application/json",
            )

    # =============================================================================
    # HTTP Function 2: Regression Training
    # =============================================================================
    @app.function_name(name="catboost_regressor_train")
    @app.route(route="catboost_regressor_train", methods=["POST"])
    def catboost_regressor_train(req: func.HttpRequest) -> func.HttpResponse:
        logging.info("Regression ML Pipeline execution started.")

        try:
            response_data = train_regressor_model(
                storage_account_url=STORAGE_ACCOUNT_URL,
                blob_container_name=BLOB_CONTAINER_NAME,
                blob_model_name=BLOB_MODEL_NAME,
            )

            return func.HttpResponse(
                json.dumps(response_data, indent=2),
                status_code=200,
                mimetype="application/json",
            )

        except Exception as e:
            logging.exception("Error during regression training execution")
            return func.HttpResponse(
                json.dumps({"success": False, "error": str(e)}, indent=2),
                status_code=500,
                mimetype="application/json",
            )