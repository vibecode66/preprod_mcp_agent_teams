import json
import logging
import tempfile
from pathlib import Path
from typing import Any, Dict

import numpy as np
import pandas as pd
from catboost import CatBoostRegressor, Pool
from azure.core.exceptions import ResourceNotFoundError

from src.shared import blob_io
from src.config import project_config
from src.regressor.regressor_process_data import (
    adjust_for_weekend,
    ensure_features,
    prepare_final_output,
)

# Global model cache (kept in module to behave like your current code)
MODEL: CatBoostRegressor | None = None


def _load_regressor_from_path(p: Path) -> CatBoostRegressor:
    m = CatBoostRegressor()
    m.load_model(str(p))
    return m


def load_regression_model_if_needed(
    storage_account_url: str | None = None,
    blob_container_name: str | None = None,
    blob_model_name: str | None = None,
    local_model_path: Path | None = None,
) -> None:
    global MODEL

    if MODEL is not None:
        logging.info("Regression MODEL already loaded; skipping reload.")
        return

    # Resolve from project_config (config.yaml + env vars) if not provided
    storage_account_url = storage_account_url or project_config.storage_account_url()
    blob_container_name = blob_container_name or project_config.blob_container_name()
    blob_model_name = blob_model_name or project_config.regressor_blob_name()
    if local_model_path is None:
        local_model_path = Path(project_config.local_regressor_model_path())

    if not storage_account_url or not blob_container_name or not blob_model_name:
        logging.warning(
            "Blob config missing for regression model "
            "(STORAGE_ACCOUNT_URL/BLOB_CONTAINER_NAME/BLOB_MODEL_NAME)."
        )

    blob_attempted = False
    try:
        if not (storage_account_url and blob_container_name and blob_model_name):
            raise ValueError("Missing blob config")

        blob_attempted = True
        temp_path = Path(tempfile.gettempdir()) / Path(blob_model_name).name
        logging.info(
            "Trying to load regression model from Blob: container='%s', blob='%s'",
            blob_container_name,
            blob_model_name,
        )

        blob_client = blob_io.get_blob_client(blob_container_name, blob_model_name)

        if hasattr(blob_client, "exists") and not blob_client.exists():
            raise ResourceNotFoundError("Regression model blob not found")

        with open(temp_path, "wb") as f:
            blob_client.download_blob().readinto(f)

        MODEL = _load_regressor_from_path(temp_path)
        logging.info("CatBoost regression model loaded from Blob successfully.")

        try:
            temp_path.unlink()
        except Exception:
            pass
        return

    except ResourceNotFoundError:
        if blob_attempted:
            logging.warning("Regression model blob not found. Will try local fallback.")
    except Exception as e:
        if blob_attempted:
            logging.warning("Blob regression model load failed (%s). Will try local fallback.", e)

    try:
        logging.info("Trying to load regression model from local path: %s", local_model_path)
        MODEL = _load_regressor_from_path(local_model_path)
        logging.info("CatBoost regression model loaded from local path successfully.")
        return
    except Exception as e:
        logging.error("Local regression model load failed: %s", e)

    raise RuntimeError("Could not load regression model from Blob or local path.")


def infer_regressor(
    payload: Dict[str, Any],
    output_folder: str | None = None,
    default_master_file: str | None = None,
    output_container_name: str | None = None,
    storage_account_url: str | None = None,
    blob_container_name: str | None = None,
    blob_model_name: str | None = None,
    local_model_path: Path | None = None,
) -> Dict[str, Any]:
    # Resolve from project_config (config.yaml + env vars) if not provided
    storage_account_url = storage_account_url or project_config.storage_account_url()
    blob_container_name = blob_container_name or project_config.blob_container_name()
    blob_model_name = blob_model_name or project_config.regressor_blob_name()
    output_folder = output_folder or project_config.output_folder_default()
    default_master_file = default_master_file or project_config.default_regressor_filename()
    output_container_name = output_container_name or project_config.output_container_name() or blob_container_name
    if local_model_path is None:
        local_model_path = Path(project_config.local_regressor_model_path())

    load_regression_model_if_needed(
        storage_account_url=storage_account_url,
        blob_container_name=blob_container_name,
        blob_model_name=blob_model_name,
        local_model_path=local_model_path,
    )

    save_to_blob = payload.get("save_to_blob", True)
    custom_filename = payload.get("filename", default_master_file)
    deduplicate_column = payload.get("deduplicate_column", "TicketNumber")

    if "data" in payload:
        records = payload["data"]
    else:
        control_params = {"save_to_blob", "filename", "deduplicate_column"}
        records = {k: v for k, v in payload.items() if k not in control_params}

    if not isinstance(records, list):
        records = [records]

    df = pd.DataFrame(records)

    if "msdyn_receiveddate" in df.columns:
        df["received_dt"] = pd.to_datetime(df["msdyn_receiveddate"], errors="coerce")
    else:
        df["received_dt"] = pd.NaT

    df["hour_of_day"] = df["received_dt"].dt.hour.fillna(0).astype(int)
    df["day_of_week"] = df["received_dt"].dt.dayofweek.fillna(0).astype(int)
    df["daily_volume"] = 1

    required_features = MODEL.feature_names_
    cat_indices = MODEL.get_cat_feature_indices()
    df_model = ensure_features(df, required_features, cat_indices)

    pool = Pool(data=df_model, cat_features=cat_indices if cat_indices else None)
    preds = MODEL.predict(pool)

    preds_minutes = np.expm1(preds)
    preds_minutes = np.maximum(preds_minutes, 0).round(0)

    if not df["received_dt"].isna().all():
        raw_finish = df["received_dt"] + pd.to_timedelta(preds_minutes, unit="m")
        pred_resolved = raw_finish.apply(adjust_for_weekend)
        pred_resolved_str = pred_resolved.dt.strftime("%Y-%m-%d %H:%M:%S")
    else:
        pred_resolved_str = pd.Series([None] * len(df))

    final_results = prepare_final_output(df, preds_minutes, pred_resolved_str)

    response_data: Dict[str, Any] = {
        "success": True,
        "records_processed": len(df),
        "results": final_results.to_dict(orient="records"),
    }

    if save_to_blob:
        if not custom_filename.endswith(".csv"):
            custom_filename = f"{custom_filename}.csv"
        blob_path = f"{output_folder}/{custom_filename}"

        save_info = blob_io.save_results_to_blob(final_results, blob_path, deduplicate_column)

        if save_info.get("success"):
            response_data.update(
                {
                    "blob_saved": True,
                    "blob_url": save_info["blob_url"],
                    "blob_path": save_info["blob_path"],
                    "operation": save_info["operation"],
                    "new_records": save_info["new_records"],
                    "total_records": save_info["total_records"],
                    "duplicates_removed": save_info.get("duplicates_removed", 0),
                }
            )
        else:
            response_data["blob_saved"] = False
            response_data["blob_error"] = save_info.get("error", "Unknown error")

    return response_data