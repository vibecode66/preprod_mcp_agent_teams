import json
import logging

import azure.functions as func

from src.config import project_config
from src.regressor.regressor_train import train_regressor_model
from src.classifier.classifier_train import train_classifier_model


def register_train_all_routes(app: func.FunctionApp) -> None:
    STORAGE_ACCOUNT_URL = project_config.storage_account_url()
    BLOB_CONTAINER_NAME = project_config.blob_container_name()

    try:
        BLOB_MODEL_NAME = project_config.regressor_blob_name()
    except Exception:
        BLOB_MODEL_NAME = "model/catboost_regressor_model.cbm"

    try:
        BLOB_CLASSIFIER_MODEL_NAME = project_config.classifier_blob_name()
    except Exception:
        BLOB_CLASSIFIER_MODEL_NAME = "model/catboost_classifier_model.cbm"
    BLOB_CLASSIFIER_FEATURE_META = project_config.classifier_feature_metadata_blob_name()
    BLOB_CLASSIFIER_METRICS = project_config.classifier_metrics_blob_name()

    @app.function_name(name="train_all")
    @app.route(route="train_all", methods=["POST"])
    def train_all(req: func.HttpRequest) -> func.HttpResponse:
        try:
            reg = train_regressor_model(
                storage_account_url=STORAGE_ACCOUNT_URL,
                blob_container_name=BLOB_CONTAINER_NAME,
                blob_model_name=BLOB_MODEL_NAME,
            )

            clf = train_classifier_model(
                storage_account_url=STORAGE_ACCOUNT_URL,
                blob_container_name=BLOB_CONTAINER_NAME,
                blob_classifier_model_name=BLOB_CLASSIFIER_MODEL_NAME,
                blob_classifier_feature_meta=BLOB_CLASSIFIER_FEATURE_META,
                blob_classifier_metrics=BLOB_CLASSIFIER_METRICS,
            )

            return func.HttpResponse(
                json.dumps(
                    {"success": True, "regressor": reg, "classifier": clf},
                    indent=2,
                ),
                status_code=200,
                mimetype="application/json",
            )

        except Exception as e:
            logging.exception("Unhandled error in train_all.")
            return func.HttpResponse(
                json.dumps({"success": False, "error": str(e)}),
                status_code=500,
                mimetype="application/json",
            )