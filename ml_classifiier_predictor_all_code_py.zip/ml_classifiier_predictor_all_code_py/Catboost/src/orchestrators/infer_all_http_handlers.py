import json
import logging
from pathlib import Path

import azure.functions as func

from src.config import project_config
from src.regressor.regressor_infer import infer_regressor
from src.classifier.classifier_infer import infer_classifier


def register_infer_all_routes(app: func.FunctionApp) -> None:
    STORAGE_ACCOUNT_URL = project_config.storage_account_url()
    BLOB_CONTAINER_NAME = project_config.blob_container_name()

    try:
        BLOB_MODEL_NAME = project_config.regressor_blob_name()
    except Exception:
        BLOB_MODEL_NAME = "model/catboost_regressor_model.cbm"

    try:
        BLOB_CLASSIFIER_MODEL_NAME = project_config.classifier_blob_name()
    except Exception:
        BLOB_CLASSIFIER_MODEL_NAME = "model/catboost_classifier_model.cbm"
    BLOB_CLASSIFIER_FEATURE_META = project_config.classifier_feature_metadata_blob_name()
    BLOB_CLASSIFIER_METRICS = project_config.classifier_metrics_blob_name()

    OUTPUT_CONTAINER_NAME = project_config.output_container_name() or BLOB_CONTAINER_NAME
    OUTPUT_FOLDER = project_config.output_folder_default()

    DEFAULT_MASTER_FILE = project_config.default_regressor_filename()
    DEFAULT_CLASSIFIER_FILE = project_config.default_classifier_filename()

    LOCAL_MODEL_PATH = Path(project_config.local_regressor_model_path())
    LOCAL_CLASSIFIER_MODEL_PATH = Path(project_config.local_classifier_model_path())
    LOCAL_CLASSIFIER_META_PATH = Path(project_config.local_classifier_meta_path())
    LOCAL_CLASSIFIER_METRICS_PATH = Path(project_config.local_classifier_metrics_path())

    @app.function_name(name="infer_all")
    @app.route(route="infer_all", methods=["POST"])
    def infer_all(req: func.HttpRequest) -> func.HttpResponse:
        try:
            try:
                payload = req.get_json()
            except ValueError:
                return func.HttpResponse(
                    json.dumps({"success": False, "error": "Invalid JSON"}),
                    status_code=400,
                    mimetype="application/json",
                )

            reg = infer_regressor(
                payload=payload,
                output_folder=OUTPUT_FOLDER,
                default_master_file=DEFAULT_MASTER_FILE,
                output_container_name=OUTPUT_CONTAINER_NAME,
                storage_account_url=STORAGE_ACCOUNT_URL,
                blob_container_name=BLOB_CONTAINER_NAME,
                blob_model_name=BLOB_MODEL_NAME,
                local_model_path=LOCAL_MODEL_PATH,
            )

            clf = infer_classifier(
                payload=payload,
                output_folder=OUTPUT_FOLDER,
                default_classifier_file=DEFAULT_CLASSIFIER_FILE,
                output_container_name=OUTPUT_CONTAINER_NAME,
                storage_account_url=STORAGE_ACCOUNT_URL,
                blob_container_name=BLOB_CONTAINER_NAME,
                blob_classifier_model_name=BLOB_CLASSIFIER_MODEL_NAME,
                blob_classifier_feature_meta=BLOB_CLASSIFIER_FEATURE_META,
                blob_classifier_metrics=BLOB_CLASSIFIER_METRICS,
                local_classifier_model_path=LOCAL_CLASSIFIER_MODEL_PATH,
                local_classifier_meta_path=LOCAL_CLASSIFIER_META_PATH,
                local_classifier_metrics_path=LOCAL_CLASSIFIER_METRICS_PATH,
            )

            return func.HttpResponse(
                json.dumps(
                    {"success": True, "regressor": reg, "classifier": clf},
                    indent=2,
                    default=str,
                ),
                status_code=200,
                mimetype="application/json",
            )

        except Exception as e:
            logging.exception("Unhandled error in infer_all.")
            return func.HttpResponse(
                json.dumps({"success": False, "error": str(e)}),
                status_code=500,
                mimetype="application/json",
            )