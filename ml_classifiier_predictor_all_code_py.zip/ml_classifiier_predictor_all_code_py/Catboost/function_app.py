import azure.functions as func

from src.regressor.regressor_http_handlers import register_regressor_routes
from src.classifier.classifier_http_handlers import register_classifier_routes
from src.orchestrators.infer_all_http_handlers import register_infer_all_routes
from src.orchestrators.train_all_http_handlers import register_train_all_routes

# Azure Functions App (Python v2 programming model)
app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)

# 1) and 2) retained as-is (regressor infer/train routes)
register_regressor_routes(app)

# Existing classifier routes retained too
register_classifier_routes(app)

# Optional orchestrators (additional endpoints only)
register_infer_all_routes(app)
register_train_all_routes(app)