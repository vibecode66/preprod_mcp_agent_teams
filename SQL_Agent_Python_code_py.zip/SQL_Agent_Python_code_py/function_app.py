import azure.functions as func
import json
import os
import logging
import struct
import re
from datetime import date, datetime
from decimal import Decimal

import pyodbc
from openai import AzureOpenAI
from azure.identity import ManagedIdentityCredential, get_bearer_token_provider

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

SQL_COPT_SS_ACCESS_TOKEN = 1256


# ===================== OPENAI =====================
def get_openai_client():
    endpoint = os.environ["AZURE_OPENAI_ENDPOINT"]
    api_version = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
    use_mi = os.environ.get("AZURE_OPENAI_USE_MANAGED_IDENTITY", "true").lower() == "true"

    if use_mi:
        client_id = os.environ.get("AZURE_OPENAI_MANAGED_IDENTITY_CLIENT_ID")
        credential = ManagedIdentityCredential(client_id=client_id) if client_id else ManagedIdentityCredential()

        token_provider = get_bearer_token_provider(
            credential,
            "https://cognitiveservices.azure.com/.default"
        )

        return AzureOpenAI(
            azure_endpoint=endpoint,
            api_version=api_version,
            azure_ad_token_provider=token_provider,
        )

    return AzureOpenAI(
        azure_endpoint=endpoint,
        api_version=api_version,
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
    )


# ===================== SQL =====================
def get_sql_connection():
    server = os.environ["SQL_SERVER"]
    database = os.environ["SQL_DATABASE"]
    driver = os.environ.get("SQL_DRIVER", "ODBC Driver 18 for SQL Server")
    client_id = os.environ.get("SQL_MANAGED_IDENTITY_CLIENT_ID")
    timeout = int(os.environ.get("SQL_CONNECTION_TIMEOUT", "30"))

    credential = ManagedIdentityCredential(client_id=client_id) if client_id else ManagedIdentityCredential()
    token = credential.get_token("https://database.windows.net/.default").token

    token_bytes = token.encode("utf-16-le")
    token_struct = struct.pack(f"<I{len(token_bytes)}s", len(token_bytes), token_bytes)

    conn_str = (
        f"Driver={{{driver}}};"
        f"Server=tcp:{server},1433;"
        f"Database={database};"
        "Encrypt=yes;"
        "TrustServerCertificate=no;"
        f"Connection Timeout={timeout};"
    )

    return pyodbc.connect(
        conn_str,
        attrs_before={SQL_COPT_SS_ACCESS_TOKEN: token_struct},
    )


# ===================== HELPERS =====================
def make_json_safe(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="ignore")
    return value


def rows_to_dicts(cursor, rows):
    columns = [col[0] for col in cursor.description]
    result = []

    for row in rows:
        item = {}
        for i, col in enumerate(columns):
            item[col] = make_json_safe(row[i])
        result.append(item)

    return result


def clean_sql_response(sql_text: str) -> str:
    sql_text = sql_text.strip()

    if sql_text.startswith("```"):
        sql_text = re.sub(r"^```sql\s*", "", sql_text, flags=re.IGNORECASE)
        sql_text = re.sub(r"^```\s*", "", sql_text)
        sql_text = re.sub(r"\s*```$", "", sql_text)

    return sql_text.strip().rstrip(";") + ";"


def validate_sql_query(query: str) -> tuple[bool, str]:
    q = query.strip().lower()

    if not q.startswith("select"):
        return False, "Only SELECT queries are allowed."

    blocked_keywords = [
        "insert", "update", "delete", "drop", "alter",
        "truncate", "merge", "exec", "execute", "create"
    ]

    for keyword in blocked_keywords:
        if re.search(rf"\b{keyword}\b", q):
            return False, f"Blocked keyword detected: {keyword}"

    if ";" in q[:-1]:
        return False, "Multiple SQL statements are not allowed."

    return True, "Valid query."


def generate_sql_from_nl(user_prompt: str) -> str:
    client = get_openai_client()
    model = os.environ.get("AZURE_OPENAI_MODEL", "gpt-4o")

    system_prompt = """
You are an expert in generating Microsoft SQL Server queries.

Rules:
1. Return ONLY SQL query text. No explanation.
2. Only generate a SELECT query.
3. Never generate INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, MERGE, CREATE, EXEC.
4. Use SQL Server syntax.
5. Default table for this task is dbo.Cases.
6. If the user asks for top records, use TOP 10 unless another number is specified.
7. If the user asks for all columns, use SELECT TOP 10 * FROM dbo.Cases.
8. Do not wrap the output in markdown.
"""

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0,
        max_completion_tokens=300,
    )

    sql_query = response.choices[0].message.content.strip()
    return clean_sql_response(sql_query)


# ===================== OPENAI CHAT =====================
@app.route(route="chat", methods=["POST"])
def chat(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Chat endpoint triggered.")

    try:
        body = req.get_json()
        message = body.get("message", "").strip()

        if not message:
            return func.HttpResponse(
                json.dumps({"error": "Missing 'message' in request body."}),
                status_code=400,
                mimetype="application/json",
            )

        model = os.environ.get("AZURE_OPENAI_MODEL", "gpt-4o")
        client = get_openai_client()

        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": message},
            ],
            temperature=0.7,
            max_completion_tokens=800,
        )

        answer = response.choices[0].message.content

        return func.HttpResponse(
            json.dumps({
                "reply": answer,
                "model": model,
                "usage": {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                },
            }),
            status_code=200,
            mimetype="application/json",
        )

    except Exception as e:
        logging.exception("Chat error")
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            status_code=500,
            mimetype="application/json",
        )


# ===================== NL2SQL ENDPOINT =====================
@app.route(route="nl2sql", methods=["POST"])
def nl2sql(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("NL2SQL endpoint triggered.")

    try:
        body = req.get_json()
        user_prompt = body.get("message", "").strip()

        if not user_prompt:
            return func.HttpResponse(
                json.dumps({"error": "Missing 'message' in request body."}),
                status_code=400,
                mimetype="application/json",
            )

        sql_query = generate_sql_from_nl(user_prompt)

        is_valid, validation_message = validate_sql_query(sql_query)
        if not is_valid:
            return func.HttpResponse(
                json.dumps({
                    "status": "failed",
                    "error": validation_message,
                    "generated_sql": sql_query,
                }),
                status_code=400,
                mimetype="application/json",
            )

        with get_sql_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql_query)
            rows = cursor.fetchall()
            results = rows_to_dicts(cursor, rows)

        return func.HttpResponse(
            json.dumps({
                "status": "success",
                "user_prompt": user_prompt,
                "generated_sql": sql_query,
                "row_count": len(results),
                "rows": results,
            }),
            status_code=200,
            mimetype="application/json",
        )

    except Exception as e:
        logging.exception("NL2SQL execution failed")
        return func.HttpResponse(
            json.dumps({
                "status": "failed",
                "error": str(e),
            }),
            status_code=500,
            mimetype="application/json",
        )


# ===================== OPENAI HEALTH =====================
@app.route(route="health", methods=["GET"])
def health(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Health check triggered.")

    try:
        client = get_openai_client()
        model = os.environ.get("AZURE_OPENAI_MODEL", "gpt-4o")

        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": "Say OK"}],
            max_completion_tokens=10,
        )

        return func.HttpResponse(
            json.dumps({
                "status": "healthy",
                "openai_connected": True,
                "model": model,
                "test_reply": response.choices[0].message.content,
            }),
            status_code=200,
            mimetype="application/json",
        )

    except Exception as e:
        logging.exception("Health check failed")
        return func.HttpResponse(
            json.dumps({
                "status": "unhealthy",
                "openai_connected": False,
                "error": str(e),
            }),
            status_code=500,
            mimetype="application/json",
        )


# ===================== SQL TEST =====================
@app.route(route="sqltest", methods=["GET"])
def sqltest(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("SQL test triggered")

    query = "SELECT TOP 10 * FROM dbo.Cases;"

    try:
        with get_sql_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query)
            rows = cursor.fetchall()
            results = rows_to_dicts(cursor, rows)

        return func.HttpResponse(
            json.dumps({
                "status": "success",
                "query": query,
                "row_count": len(results),
                "rows": results,
            }),
            status_code=200,
            mimetype="application/json",
        )

    except Exception as e:
        logging.exception("SQL test failed")
        return func.HttpResponse(
            json.dumps({
                "status": "failed",
                "error": str(e),
            }),
            status_code=500,
            mimetype="application/json",
        )


# ===================== SQL HEALTH =====================
@app.route(route="healthsql", methods=["GET"])
def healthsql(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("SQL health check triggered.")

    try:
        with get_sql_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            val = cursor.fetchone()[0]

        return func.HttpResponse(
            json.dumps({"status": "healthy", "sql_connected": True, "value": val}),
            status_code=200,
            mimetype="application/json",
        )

    except Exception as e:
        logging.exception("SQL health check failed")
        return func.HttpResponse(
            json.dumps({"status": "unhealthy", "sql_connected": False, "error": str(e)}),
            status_code=500,
            mimetype="application/json",
        )
    
# import azure.functions as func
# import json
# import os
# import logging
# import struct
# from datetime import date, datetime
# from decimal import Decimal

# import pyodbc
# from openai import AzureOpenAI
# from azure.identity import ManagedIdentityCredential, get_bearer_token_provider

# app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

# SQL_COPT_SS_ACCESS_TOKEN = 1256


# # ===================== OPENAI =====================
# def get_openai_client():
#     endpoint = os.environ["AZURE_OPENAI_ENDPOINT"]
#     api_version = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
#     use_mi = os.environ.get("AZURE_OPENAI_USE_MANAGED_IDENTITY", "true").lower() == "true"

#     if use_mi:
#         client_id = os.environ.get("AZURE_OPENAI_MANAGED_IDENTITY_CLIENT_ID")
#         credential = ManagedIdentityCredential(client_id=client_id) if client_id else ManagedIdentityCredential()

#         token_provider = get_bearer_token_provider(
#             credential,
#             "https://cognitiveservices.azure.com/.default"
#         )

#         return AzureOpenAI(
#             azure_endpoint=endpoint,
#             api_version=api_version,
#             azure_ad_token_provider=token_provider,
#         )

#     return AzureOpenAI(
#         azure_endpoint=endpoint,
#         api_version=api_version,
#         api_key=os.environ["AZURE_OPENAI_API_KEY"],
#     )


# # ===================== SQL =====================
# def get_sql_connection():
#     server = os.environ["SQL_SERVER"]
#     database = os.environ["SQL_DATABASE"]
#     driver = os.environ.get("SQL_DRIVER", "ODBC Driver 18 for SQL Server")
#     client_id = os.environ.get("SQL_MANAGED_IDENTITY_CLIENT_ID")
#     timeout = int(os.environ.get("SQL_CONNECTION_TIMEOUT", "30"))

#     credential = ManagedIdentityCredential(client_id=client_id) if client_id else ManagedIdentityCredential()
#     token = credential.get_token("https://database.windows.net/.default").token

#     token_bytes = token.encode("utf-16-le")
#     token_struct = struct.pack(f"<I{len(token_bytes)}s", len(token_bytes), token_bytes)

#     conn_str = (
#         f"Driver={{{driver}}};"
#         f"Server=tcp:{server},1433;"
#         f"Database={database};"
#         "Encrypt=yes;"
#         "TrustServerCertificate=no;"
#         f"Connection Timeout={timeout};"
#     )

#     return pyodbc.connect(
#         conn_str,
#         attrs_before={SQL_COPT_SS_ACCESS_TOKEN: token_struct},
#     )


# # ===================== HELPERS =====================
# def make_json_safe(value):
#     if isinstance(value, (datetime, date)):
#         return value.isoformat()
#     if isinstance(value, Decimal):
#         return float(value)
#     if isinstance(value, bytes):
#         return value.decode("utf-8", errors="ignore")
#     return value


# def rows_to_dicts(cursor, rows):
#     columns = [col[0] for col in cursor.description]
#     result = []

#     for row in rows:
#         item = {}
#         for i, col in enumerate(columns):
#             item[col] = make_json_safe(row[i])
#         result.append(item)

#     return result


# # ===================== OPENAI ENDPOINT =====================
# @app.route(route="chat", methods=["POST"])
# def chat(req: func.HttpRequest) -> func.HttpResponse:
#     logging.info("Chat endpoint triggered.")

#     try:
#         body = req.get_json()
#         message = body.get("message", "").strip()

#         if not message:
#             return func.HttpResponse(
#                 json.dumps({"error": "Missing 'message' in request body."}),
#                 status_code=400,
#                 mimetype="application/json",
#             )

#         model = os.environ.get("AZURE_OPENAI_MODEL", "gpt-4o")
#         client = get_openai_client()

#         response = client.chat.completions.create(
#             model=model,
#             messages=[
#                 {"role": "system", "content": "You are a helpful assistant."},
#                 {"role": "user", "content": message},
#             ],
#             temperature=0.7,
#             max_completion_tokens=800,
#         )

#         answer = response.choices[0].message.content

#         return func.HttpResponse(
#             json.dumps({
#                 "reply": answer,
#                 "model": model,
#                 "usage": {
#                     "prompt_tokens": response.usage.prompt_tokens,
#                     "completion_tokens": response.usage.completion_tokens,
#                     "total_tokens": response.usage.total_tokens,
#                 },
#             }),
#             status_code=200,
#             mimetype="application/json",
#         )

#     except Exception as e:
#         logging.exception("Chat error")
#         return func.HttpResponse(
#             json.dumps({"error": str(e)}),
#             status_code=500,
#             mimetype="application/json",
#         )


# # ===================== OPENAI HEALTH =====================
# @app.route(route="health", methods=["GET"])
# def health(req: func.HttpRequest) -> func.HttpResponse:
#     logging.info("Health check triggered.")

#     try:
#         client = get_openai_client()
#         model = os.environ.get("AZURE_OPENAI_MODEL", "gpt-4o")

#         response = client.chat.completions.create(
#             model=model,
#             messages=[{"role": "user", "content": "Say OK"}],
#             max_completion_tokens=10,
#         )

#         return func.HttpResponse(
#             json.dumps({
#                 "status": "healthy",
#                 "openai_connected": True,
#                 "model": model,
#                 "test_reply": response.choices[0].message.content,
#             }),
#             status_code=200,
#             mimetype="application/json",
#         )

#     except Exception as e:
#         logging.exception("Health check failed")
#         return func.HttpResponse(
#             json.dumps({
#                 "status": "unhealthy",
#                 "openai_connected": False,
#                 "error": str(e),
#             }),
#             status_code=500,
#             mimetype="application/json",
#         )


# # ===================== SQL TEST =====================
# @app.route(route="sqltest", methods=["GET"])
# def sqltest(req: func.HttpRequest) -> func.HttpResponse:
#     logging.info("SQL test triggered")

#     query = "SELECT TOP 10 * FROM dbo.Cases;"

#     try:
#         with get_sql_connection() as conn:
#             cursor = conn.cursor()
#             cursor.execute(query)
#             rows = cursor.fetchall()
#             results = rows_to_dicts(cursor, rows)

#         return func.HttpResponse(
#             json.dumps({
#                 "status": "success",
#                 "rows": results,
#                 "count": len(results),
#             }),
#             status_code=200,
#             mimetype="application/json",
#         )

#     except Exception as e:
#         logging.exception("SQL test failed")
#         return func.HttpResponse(
#             json.dumps({
#                 "status": "failed",
#                 "error": str(e),
#             }),
#             status_code=500,
#             mimetype="application/json",
#         )


# # ===================== SQL HEALTH =====================
# @app.route(route="healthsql", methods=["GET"])
# def healthsql(req: func.HttpRequest) -> func.HttpResponse:
#     logging.info("SQL health check triggered.")

#     try:
#         with get_sql_connection() as conn:
#             cursor = conn.cursor()
#             cursor.execute("SELECT 1")
#             val = cursor.fetchone()[0]

#         return func.HttpResponse(
#             json.dumps({"status": "healthy", "sql_connected": True, "value": val}),
#             status_code=200,
#             mimetype="application/json",
#         )

#     except Exception as e:
#         logging.exception("SQL health check failed")
#         return func.HttpResponse(
#             json.dumps({"status": "unhealthy", "sql_connected": False, "error": str(e)}),
#             status_code=500,
#             mimetype="application/json",
#         )