import os
import json
import base64
from urllib.parse import urlencode

import pandas as pd
import requests
import streamlit as st
import urllib3

# Suppress SSL warning for verify=False calls used in existing app
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# -----------------------------------------------------------------------------
# Defaults
# -----------------------------------------------------------------------------
DEFAULT_ML_BASE_URL = "https://func-sla-catboost-train-uat-eastus.azurewebsites.net"
DEFAULT_STORAGE_BASE_URL = "https://func-sla-catboost-infer-uat-eastus.azurewebsites.net"

UPLOAD_ROUTE = "catboost_upload_dataset"
STORAGE_STATUS_ROUTE = "catboost_files_in_storage"
DELETE_BLOB_ROUTE = "catboost_delete_blob"
DEFAULT_CONTAINER_TO_BROWSE = "model-2"


# -----------------------------------------------------------------------------
# Page setup
# -----------------------------------------------------------------------------
st.set_page_config(page_title="Cosmic Case SLA Prediction + Storage Browser", layout="wide")
st.markdown("# 🚀 Cosmic Case SLA Prediction + Storage Browser")


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
def safe_json(resp: requests.Response):
    try:
        return resp.json()
    except Exception:
        return {"raw_text": resp.text}



def get_base64_image(image_path: str):
    try:
        if os.path.exists(image_path):
            with open(image_path, "rb") as img_file:
                return base64.b64encode(img_file.read()).decode()
        return None
    except Exception:
        return None



def build_url(base_url: str, route: str, use_api_prefix: bool) -> str:
    base = base_url.rstrip("/")
    return f"{base}/api/{route}" if use_api_prefix else f"{base}/{route}"



def show_request_debug(method: str, url: str, params: dict):
    with st.expander("🔗 Request Details (debug)"):
        qs = urlencode({k: v for k, v in params.items() if v is not None and v != ""})
        st.code(f"{method} {url}?{qs}", language="text")
        st.code(json.dumps(params, indent=2), language="json")



def get_with_auto_prefix(base_url: str, route: str, params: dict, timeout: int = 180):
    url_api = build_url(base_url, route, use_api_prefix=True)
    resp = requests.get(url_api, params=params, timeout=timeout, verify=False)
    if resp.status_code != 404:
        return resp, True

    url_no_api = build_url(base_url, route, use_api_prefix=False)
    resp2 = requests.get(url_no_api, params=params, timeout=timeout, verify=False)
    return resp2, False



def post_with_auto_prefix(base_url: str, route: str, params: dict, files: dict, timeout: int = 180):
    url_api = build_url(base_url, route, use_api_prefix=True)
    resp = requests.post(url_api, params=params, files=files, timeout=timeout, verify=False)
    if resp.status_code != 404:
        return resp, True

    url_no_api = build_url(base_url, route, use_api_prefix=False)
    resp2 = requests.post(url_no_api, params=params, files=files, timeout=timeout, verify=False)
    return resp2, False



def delete_with_auto_prefix(base_url: str, route: str, params: dict, timeout: int = 180):
    url_api = build_url(base_url, route, use_api_prefix=True)
    resp = requests.delete(url_api, params=params, timeout=timeout, verify=False)
    if resp.status_code != 404:
        return resp, True

    url_no_api = build_url(base_url, route, use_api_prefix=False)
    resp2 = requests.delete(url_no_api, params=params, timeout=timeout, verify=False)
    return resp2, False



def call_endpoint(url: str, payload: dict) -> dict:
    resp = requests.post(url, json=payload, verify=False, timeout=600)
    resp.raise_for_status()
    return resp.json()



def get_records(row_num: int) -> list:
    if st.session_state.data is None:
        return []
    if row_num == 0:
        records = st.session_state.data.to_dict(orient="records")
    else:
        row_data = st.session_state.data.iloc[row_num - 1].to_dict()
        records = [row_data]
    return json.loads(pd.DataFrame(records).to_json(orient="records", date_format="iso"))



def highlight_prediction(val):
    if val == "Hold":
        return "background-color: #ffcccc; color: #990000; font-weight: bold"
    if val == "No Hold":
        return "background-color: #ccffcc; color: #006600; font-weight: bold"
    return ""


# -----------------------------------------------------------------------------
# Sidebar config
# -----------------------------------------------------------------------------
with st.sidebar:
    st.header("⚙️ Settings")

    st.subheader("ML Function App")
    ml_base_url = st.text_input(
        "ML Function App Base URL",
        value=os.getenv("ML_FUNCTION_BASE_URL", DEFAULT_ML_BASE_URL),
    )

    st.subheader("Storage Function App")
    storage_function_base_url = st.text_input(
        "Storage Function App Base URL",
        value=os.getenv("STORAGE_FUNCTION_BASE_URL", DEFAULT_STORAGE_BASE_URL),
    )

    st.subheader("Auth (only if required)")
    function_key = st.text_input(
        "Function key (optional)",
        value=os.getenv("FUNCTION_KEY", ""),
        type="password",
        help="Only needed if your functions are not Anonymous.",
    )

    st.subheader("Storage (optional override)")
    storage_account = st.text_input(
        "Storage Account Name (optional)",
        value="",
        placeholder="(uses server default)",
    )

    st.subheader("Browse Settings")
    browse_limit = st.slider("Browse limit (server max 500)", 10, 500, 500, 10)
    browse_prefix = st.text_input("Browse prefix (optional)", value="", placeholder="e.g. model/")

    st.subheader("Delete Settings")
    delete_route = st.text_input("Delete route", value=DELETE_BLOB_ROUTE)

# Endpoint map derived from ML base URL
ENDPOINTS = {
    "regressor_infer": f"{ml_base_url.rstrip('/')}/catboost_regressor_infer",
    "regressor_train": f"{ml_base_url.rstrip('/')}/catboost_regressor_train",
    "classifier_infer": f"{ml_base_url.rstrip('/')}/catboost_classifier_infer",
    "classifier_train": f"{ml_base_url.rstrip('/')}/catboost_classifier_train",
    "infer_all": f"{ml_base_url.rstrip('/')}/infer_all",
    "train_all": f"{ml_base_url.rstrip('/')}/train_all",
}

with st.sidebar:
    st.markdown("---")
    st.markdown("### ℹ️ ML Endpoints")
    st.markdown(
        """
        | Endpoint | Purpose |
        |----------|---------|
        | `regressor_infer` | Predict SLA duration |
        | `regressor_train` | Retrain regressor model |
        | `classifier_infer` | Predict Hold/No-Hold |
        | `classifier_train` | Retrain classifier model |
        | `infer_all` | Run both inferences |
        | `train_all` | Retrain both models |
        """
    )

    with st.expander("ML Endpoint URLs", expanded=False):
        for key, value in ENDPOINTS.items():
            st.text_input(key.replace("_", " ").title(), value=value, key=f"endpoint_{key}")


# -----------------------------------------------------------------------------
# Session state
# -----------------------------------------------------------------------------
for key in [
    "data",
    "reg_built_payload",
    "reg_final_display_df",
    "clf_built_payload",
    "clf_final_display_df",
    "infer_all_reg_df",
    "infer_all_clf_df",
    "last_blob_list",
]:
    if key not in st.session_state:
        st.session_state[key] = None if key != "last_blob_list" else []

if "clf_threshold" not in st.session_state:
    st.session_state.clf_threshold = 0.5


# -----------------------------------------------------------------------------
# Optional logo
# -----------------------------------------------------------------------------
img_path = os.path.join("assets", "microsoft-logo.png")
img_base64 = get_base64_image(img_path)
if img_base64:
    st.markdown(
        f"<img src='data:image/png;base64,{img_base64}' width='160'>",
        unsafe_allow_html=True,
    )


# -----------------------------------------------------------------------------
# Shared upload for inference
# -----------------------------------------------------------------------------
st.markdown("## 📂 Upload Input Data")
st.markdown("This data will be used across **all inference tabs**.")

uploaded_file = st.file_uploader("Upload CSV/Excel", type=["csv", "xlsx"], key="shared_uploader")
if uploaded_file:
    df = pd.read_csv(uploaded_file) if uploaded_file.name.endswith(".csv") else pd.read_excel(uploaded_file)
    st.session_state.data = df

if st.session_state.data is not None:
    st.success(
        f"✅ Data loaded: **{len(st.session_state.data)}** rows, **{len(st.session_state.data.columns)}** columns"
    )
    with st.expander("Preview Data", expanded=False):
        st.dataframe(st.session_state.data.head(10), use_container_width=True)

st.markdown("---")


# -----------------------------------------------------------------------------
# Main tabs
# -----------------------------------------------------------------------------
tab_regression, tab_classifier, tab_infer_all, tab_train, tab_storage = st.tabs(
    [
        "📈 SLA Regression Infer",
        "🏷️ Hold Classifier Infer",
        "⚡ Infer All",
        "🔧 Training",
        "🧭 Storage Browser + Upload",
    ]
)


# -----------------------------------------------------------------------------
# Regression Inference
# -----------------------------------------------------------------------------
with tab_regression:
    st.markdown("## SLA Duration Prediction (Regression)")
    st.markdown(
        "Run inference against the **CatBoost regression** model "
        "to predict case resolution duration and dates."
    )

    if st.session_state.data is None:
        st.warning("⬆️ Please upload data above first.")
    else:
        reg_row = st.number_input(
            "Select Row (0 = all rows)",
            min_value=0,
            max_value=len(st.session_state.data),
            value=1,
            key="reg_row_num",
            help="Select 0 to run inference on ALL rows.",
        )

        col1, col2 = st.columns(2)
        with col1:
            if st.button("Build Payload", key="reg_build"):
                records = get_records(reg_row)
                payload = {"data": records, "save_to_blob": False}
                st.session_state.reg_built_payload = json.dumps(payload, indent=2)

        if st.session_state.reg_built_payload:
            with st.expander("Payload Preview", expanded=False):
                st.code(st.session_state.reg_built_payload, language="json")

        with col2:
            if st.button("🚀 Run Regression Inference", type="primary", key="reg_infer"):
                if not st.session_state.reg_built_payload:
                    st.error("Please build payload first.")
                else:
                    try:
                        with st.spinner("Calling Regression Inference..."):
                            payload = json.loads(st.session_state.reg_built_payload)
                            resp_json = call_endpoint(ENDPOINTS["regressor_infer"], payload)
                            results = resp_json.get("results", [])
                            if results:
                                pred_df = pd.DataFrame(results)
                                st.session_state.reg_final_display_df = pred_df
                                st.success(f"✅ Prediction complete — {len(results)} record(s)")
                            else:
                                st.warning("API returned success but no result data.")
                    except Exception as e:
                        st.error(f"Error: {e}")

        if st.session_state.reg_final_display_df is not None:
            st.subheader("Regression Results")
            st.dataframe(st.session_state.reg_final_display_df, use_container_width=True)
            csv_data = st.session_state.reg_final_display_df.to_csv(index=False)
            st.download_button(
                "📥 Download Results as CSV",
                csv_data,
                file_name="regression_results.csv",
                mime="text/csv",
                key="reg_download",
            )


# -----------------------------------------------------------------------------
# Classifier Inference
# -----------------------------------------------------------------------------
with tab_classifier:
    st.markdown("## Hold / No-Hold Classification")
    st.markdown(
        "Run inference against the **CatBoost classifier** model "
        "to predict whether a case will be placed on hold."
    )

    if st.session_state.data is None:
        st.warning("⬆️ Please upload data above first.")
    else:
        col_opts1, col_opts2 = st.columns(2)
        with col_opts1:
            threshold = st.number_input(
                "Decision Threshold",
                min_value=0.0,
                max_value=1.0,
                value=0.5,
                step=0.01,
                key="clf_threshold_input",
                help="Probability threshold for classifying as Hold.",
            )
        with col_opts2:
            include_input = st.checkbox(
                "Include original input columns in results",
                value=False,
                key="clf_include_input_checkbox",
            )

        clf_row = st.number_input(
            "Select Row (0 = all rows)",
            min_value=0,
            max_value=len(st.session_state.data),
            value=0,
            key="clf_row_num",
        )

        col1, col2 = st.columns(2)
        with col1:
            if st.button("Build Payload", key="clf_build"):
                records = get_records(clf_row)
                payload = {
                    "data": records,
                    "threshold": threshold,
                    "save_to_blob": False,
                    "include_input": include_input,
                }
                st.session_state.clf_built_payload = json.dumps(payload, indent=2)

        if st.session_state.clf_built_payload:
            with st.expander("Payload Preview", expanded=False):
                st.code(st.session_state.clf_built_payload, language="json")

        with col2:
            if st.button("🚀 Run Classification", type="primary", key="clf_infer"):
                if not st.session_state.clf_built_payload:
                    st.error("Please build payload first.")
                else:
                    try:
                        with st.spinner("Calling Classifier Inference..."):
                            payload = json.loads(st.session_state.clf_built_payload)
                            resp_json = call_endpoint(ENDPOINTS["classifier_infer"], payload)
                            results = resp_json.get("results", [])
                            if results:
                                pred_df = pd.DataFrame(results)
                                st.session_state.clf_final_display_df = pred_df
                                hold_count = resp_json.get("hold_count", 0)
                                no_hold_count = resp_json.get("no_hold_count", 0)
                                threshold_used = resp_json.get("threshold_used", threshold)

                                m1, m2, m3, m4 = st.columns(4)
                                m1.metric("Records", resp_json.get("records_processed", len(results)))
                                m2.metric("Hold", hold_count)
                                m3.metric("No Hold", no_hold_count)
                                m4.metric("Threshold", f"{threshold_used:.4f}")
                                st.success("✅ Classification complete.")
                            else:
                                st.warning("API returned success but no result data.")
                    except Exception as e:
                        st.error(f"Error: {e}")

        if st.session_state.clf_final_display_df is not None:
            st.subheader("Classification Results")
            result_df = st.session_state.clf_final_display_df
            if "prediction_label" in result_df.columns:
                styled = result_df.style.applymap(highlight_prediction, subset=["prediction_label"])
                st.dataframe(styled, use_container_width=True)
            else:
                st.dataframe(result_df, use_container_width=True)

            csv_data = result_df.to_csv(index=False)
            st.download_button(
                "📥 Download Results as CSV",
                csv_data,
                file_name="classification_results.csv",
                mime="text/csv",
                key="clf_download",
            )


# -----------------------------------------------------------------------------
# Infer All
# -----------------------------------------------------------------------------
with tab_infer_all:
    st.markdown("## ⚡ Infer All (Regressor + Classifier)")
    st.markdown(
        "Trigger **both** regression and classifier inference in a single call "
        "using the `/infer_all` endpoint."
    )

    if st.session_state.data is None:
        st.warning("⬆️ Please upload data above first.")
    else:
        infer_all_row = st.number_input(
            "Select Row (0 = all rows)",
            min_value=0,
            max_value=len(st.session_state.data),
            value=0,
            key="infer_all_row_num",
        )
        infer_all_threshold = st.number_input(
            "Classifier Threshold",
            min_value=0.0,
            max_value=1.0,
            value=0.5,
            step=0.01,
            key="infer_all_threshold",
        )

        if st.button("🚀 Run Infer All", type="primary", key="infer_all_btn"):
            try:
                records = get_records(infer_all_row)
                payload = {
                    "data": records,
                    "threshold": infer_all_threshold,
                    "save_to_blob": False,
                    "include_input": False,
                }
                with st.spinner("Calling Infer All endpoint..."):
                    resp_json = call_endpoint(ENDPOINTS["infer_all"], payload)

                st.success("✅ Infer All complete.")
                st.json(resp_json)

                reg_results = (
                    resp_json.get("regressor_results")
                    or resp_json.get("regression_results")
                    or resp_json.get("results", [])
                )
                clf_results = resp_json.get("classifier_results") or resp_json.get("classification_results", [])

                if reg_results:
                    st.subheader("Regressor Results")
                    reg_df = pd.DataFrame(reg_results) if isinstance(reg_results, list) else pd.DataFrame(reg_results.get("results", []))
                    st.session_state.infer_all_reg_df = reg_df
                    st.dataframe(reg_df, use_container_width=True)

                if clf_results:
                    st.subheader("Classifier Results")
                    clf_df = pd.DataFrame(clf_results) if isinstance(clf_results, list) else pd.DataFrame(clf_results.get("results", []))
                    st.session_state.infer_all_clf_df = clf_df
                    if "prediction_label" in clf_df.columns:
                        styled = clf_df.style.applymap(highlight_prediction, subset=["prediction_label"])
                        st.dataframe(styled, use_container_width=True)
                    else:
                        st.dataframe(clf_df, use_container_width=True)

            except Exception as e:
                st.error(f"Error: {e}")


# -----------------------------------------------------------------------------
# Training
# -----------------------------------------------------------------------------
with tab_train:
    st.markdown("## 🔧 Model Training")
    st.markdown(
        "Trigger model retraining for the **Regressor**, **Classifier**, or **both** models. "
        "Training runs on Azure — no local data upload is needed."
    )

    st.warning(
        "⚠️ Training will retrain the model(s) on Azure using the configured training data in blob storage. "
        "This may take several minutes."
    )

    col_t1, col_t2, col_t3 = st.columns(3)

    with col_t1:
        st.markdown("### 📈 Regressor")
        st.caption("Retrain the SLA duration prediction model.")
        if st.button("🔄 Train Regressor", key="train_reg_btn"):
            try:
                with st.spinner("Training Regressor model..."):
                    resp_json = call_endpoint(ENDPOINTS["regressor_train"], {})
                if resp_json.get("success", False):
                    st.success("✅ Regressor training complete!")
                else:
                    st.warning("Training returned a response but success=false.")
                st.json(resp_json)
            except requests.exceptions.HTTPError as e:
                st.error(f"HTTP Error: {e.response.status_code} — {e.response.text}")
            except Exception as e:
                st.error(f"Error: {e}")

    with col_t2:
        st.markdown("### 🏷️ Classifier")
        st.caption("Retrain the Hold/No-Hold classification model.")
        if st.button("🔄 Train Classifier", key="train_clf_btn"):
            try:
                with st.spinner("Training Classifier model..."):
                    resp_json = call_endpoint(ENDPOINTS["classifier_train"], {})
                if resp_json.get("success", False):
                    st.success("✅ Classifier training complete!")
                else:
                    st.warning("Training returned a response but success=false.")
                st.json(resp_json)
            except requests.exceptions.HTTPError as e:
                st.error(f"HTTP Error: {e.response.status_code} — {e.response.text}")
            except Exception as e:
                st.error(f"Error: {e}")

    with col_t3:
        st.markdown("### ⚡ Train All")
        st.caption("Retrain **both** models in a single call.")
        if st.button("🔄 Train All", type="primary", key="train_all_btn"):
            try:
                with st.spinner("Training both models..."):
                    resp_json = call_endpoint(ENDPOINTS["train_all"], {})
                if resp_json.get("success", False):
                    st.success("✅ Both models trained successfully!")
                else:
                    st.warning("Training returned a response but success=false.")
                st.json(resp_json)
            except requests.exceptions.HTTPError as e:
                st.error(f"HTTP Error: {e.response.status_code} — {e.response.text}")
            except Exception as e:
                st.error(f"Error: {e}")

    st.markdown("---")
    st.markdown("### 📋 Training Logs")
    st.caption("After triggering training, check Azure Portal → Function App → Monitor for detailed logs.")


# -----------------------------------------------------------------------------
# Storage browser + upload + delete
# -----------------------------------------------------------------------------
with tab_storage:
    st.markdown("## 🧭 Storage Browser + Upload")

    browse_subtab, upload_subtab = st.tabs(["Browse / Delete", "Upload"])

    with browse_subtab:
        st.markdown("### List blobs")
        browse_container = st.text_input("Container name", value=DEFAULT_CONTAINER_TO_BROWSE, key="browse_container")

        if st.button("🗂️ Fetch blobs", type="primary", use_container_width=True, key="fetch_blobs"):
            params = {"container": browse_container.strip(), "limit": str(browse_limit)}
            if browse_prefix.strip():
                params["prefix"] = browse_prefix.strip()
            if storage_account.strip():
                params["storageAccount"] = storage_account.strip()
            if function_key.strip():
                params["code"] = function_key.strip()

            show_request_debug(
                "GET (try /api first)",
                build_url(storage_function_base_url, STORAGE_STATUS_ROUTE, True),
                params,
            )
            with st.spinner("Fetching blobs…"):
                resp, used_api = get_with_auto_prefix(storage_function_base_url, STORAGE_STATUS_ROUTE, params=params)
                data = safe_json(resp)

                if resp.status_code == 200:
                    blobs = data.get("blobs", []) or []
                    st.session_state.last_blob_list = blobs
                    st.success(
                        f"✅ OK (used {'/api' if used_api else 'no /api'}). Returned {len(blobs)} blob(s)."
                    )
                    st.dataframe(blobs, use_container_width=True)
                    st.expander("Raw response").json(data)
                else:
                    st.error(f"❌ Failed (HTTP {resp.status_code}) (used {'/api' if used_api else 'no /api'})")
                    st.json(data)

        blobs = st.session_state.last_blob_list
        if blobs:
            st.markdown("### Delete blob")
            blob_names = []
            for item in blobs:
                if isinstance(item, dict):
                    blob_name = item.get("name") or item.get("blob") or item.get("blobName")
                    if blob_name:
                        blob_names.append(blob_name)
                elif isinstance(item, str):
                    blob_names.append(item)

            blob_names = sorted(set(blob_names))

            selected_blob = st.selectbox(
                "Select blob to delete",
                options=blob_names,
                index=None,
                placeholder="Choose a blob",
                key="selected_blob",
            )
            confirm_delete = st.checkbox(
                "I confirm I want to permanently delete the selected blob",
                key="confirm_delete",
            )

            if st.button(
                "🗑️ Delete selected blob",
                type="secondary",
                use_container_width=True,
                disabled=not selected_blob,
                key="delete_blob_btn",
            ):
                if not selected_blob:
                    st.warning("Please select a blob.")
                elif not confirm_delete:
                    st.warning("Please confirm deletion before proceeding.")
                else:
                    params = {"container": browse_container.strip(), "blob": selected_blob}
                    if storage_account.strip():
                        params["storageAccount"] = storage_account.strip()
                    if function_key.strip():
                        params["code"] = function_key.strip()

                    show_request_debug(
                        "DELETE (try /api first)",
                        build_url(storage_function_base_url, delete_route, True),
                        params,
                    )
                    with st.spinner(f"Deleting '{selected_blob}'…"):
                        resp, used_api = delete_with_auto_prefix(storage_function_base_url, delete_route, params=params)
                        data = safe_json(resp)

                        if resp.status_code in (200, 202, 204):
                            st.success(
                                f"✅ Blob deleted successfully (used {'/api' if used_api else 'no /api'}): {selected_blob}"
                            )
                            st.session_state.last_blob_list = [
                                b
                                for b in blobs
                                if not (
                                    (isinstance(b, dict) and ((b.get('name') or b.get('blob') or b.get('blobName')) == selected_blob))
                                    or (isinstance(b, str) and b == selected_blob)
                                )
                            ]
                            if resp.status_code != 204:
                                st.json(data)
                        else:
                            st.error(
                                f"❌ Delete failed (HTTP {resp.status_code}) (used {'/api' if used_api else 'no /api'})"
                            )
                            st.json(data)

    with upload_subtab:
        st.markdown("### Upload file")
        storage_uploaded_file = st.file_uploader(
            "Choose a CSV or Excel file",
            type=["csv", "xlsx", "xls"],
            key="storage_uploader",
        )
        custom_blob_name = st.text_input("Custom blob name (optional)", value="", key="custom_blob_name")
        overwrite = st.checkbox("Overwrite if exists", value=True, key="overwrite_blob")

        if storage_uploaded_file is not None and st.button(
            "🚀 Upload",
            type="primary",
            use_container_width=True,
            key="upload_blob_btn",
        ):
            params = {"overwrite": str(overwrite).lower()}
            if storage_account.strip():
                params["storageAccount"] = storage_account.strip()
            if custom_blob_name.strip():
                params["blob"] = custom_blob_name.strip()
            if function_key.strip():
                params["code"] = function_key.strip()

            if storage_uploaded_file.name.endswith(".xlsx"):
                mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            elif storage_uploaded_file.name.endswith(".xls"):
                mime_type = "application/vnd.ms-excel"
            else:
                mime_type = "text/csv"

            files = {
                "file": (
                    storage_uploaded_file.name,
                    storage_uploaded_file.getvalue(),
                    mime_type,
                )
            }

            show_request_debug(
                "POST (try /api first)",
                build_url(storage_function_base_url, UPLOAD_ROUTE, True),
                params,
            )
            with st.spinner("Uploading…"):
                resp, used_api = post_with_auto_prefix(storage_function_base_url, UPLOAD_ROUTE, params=params, files=files)
                data = safe_json(resp)

                if resp.status_code == 200:
                    st.success(f"✅ Upload OK (used {'/api' if used_api else 'no /api'})")
                    st.json(data)
                else:
                    st.error(f"❌ Upload failed (HTTP {resp.status_code}) (used {'/api' if used_api else 'no /api'})")
                    st.json(data)
