import os
import json
from urllib.parse import urlencode

import requests
import streamlit as st

DEFAULT_FUNCTION_URL = "https://func-sla-catboost-infer-uat-eastus.azurewebsites.net"

UPLOAD_ROUTE = "catboost_upload_dataset"
STORAGE_STATUS_ROUTE = "catboost_files_in_storage"
DELETE_BLOB_ROUTE = "catboost_delete_blob"  # Change this if your backend delete endpoint uses a different name
DEFAULT_CONTAINER_TO_BROWSE = "model-2"

st.set_page_config(page_title="CatBoost Storage Browser + Uploader", page_icon="📤", layout="wide")
st.title("CatBoost — Upload + Storage Browser")


def safe_json(resp: requests.Response):
    try:
        return resp.json()
    except Exception:
        return {"raw_text": resp.text}


def show_request_debug(method: str, url: str, params: dict):
    with st.expander("🔗 Request Details (debug)"):
        qs = urlencode({k: v for k, v in params.items() if v is not None and v != ""})
        st.code(f"{method} {url}?{qs}", language="text")
        st.code(json.dumps(params, indent=2), language="json")


def build_url(base_url: str, route: str, use_api_prefix: bool) -> str:
    base = base_url.rstrip("/")
    if use_api_prefix:
        return f"{base}/api/{route}"
    return f"{base}/{route}"


def get_with_auto_prefix(base_url: str, route: str, params: dict, timeout: int = 180):
    """
    Try /api/<route> first. If 404, try /<route>.
    Returns (resp, used_api_prefix: bool)
    """
    url_api = build_url(base_url, route, use_api_prefix=True)
    resp = requests.get(url_api, params=params, timeout=timeout)
    if resp.status_code != 404:
        return resp, True

    url_no_api = build_url(base_url, route, use_api_prefix=False)
    resp2 = requests.get(url_no_api, params=params, timeout=timeout)
    return resp2, False



def post_with_auto_prefix(base_url: str, route: str, params: dict, files: dict, timeout: int = 180):
    url_api = build_url(base_url, route, use_api_prefix=True)
    resp = requests.post(url_api, params=params, files=files, timeout=timeout)
    if resp.status_code != 404:
        return resp, True

    url_no_api = build_url(base_url, route, use_api_prefix=False)
    resp2 = requests.post(url_no_api, params=params, files=files, timeout=timeout)
    return resp2, False



def delete_with_auto_prefix(base_url: str, route: str, params: dict, timeout: int = 180):
    """
    Try /api/<route> first. If 404, try /<route>.
    Returns (resp, used_api_prefix: bool)
    """
    url_api = build_url(base_url, route, use_api_prefix=True)
    resp = requests.delete(url_api, params=params, timeout=timeout)
    if resp.status_code != 404:
        return resp, True

    url_no_api = build_url(base_url, route, use_api_prefix=False)
    resp2 = requests.delete(url_no_api, params=params, timeout=timeout)
    return resp2, False


if "last_blob_list" not in st.session_state:
    st.session_state.last_blob_list = []

with st.sidebar:
    st.header("⚙️ Settings")
    function_base_url = st.text_input("Function App Base URL", value=os.getenv("FUNCTION_BASE_URL", DEFAULT_FUNCTION_URL))

    st.subheader("Auth (only if required)")
    function_key = st.text_input(
        "Function key (optional)",
        value=os.getenv("FUNCTION_KEY", ""),
        type="password",
        help="Only needed if your functions are not Anonymous.",
    )

    st.subheader("Storage (optional override)")
    storage_account = st.text_input("Storage Account Name (optional)", value="", placeholder="(uses server default)")

    st.subheader("Browse Settings")
    browse_limit = st.slider("Browse limit (server max 500)", 10, 500, 500, 10)
    browse_prefix = st.text_input("Browse prefix (optional)", value="", placeholder="e.g. model/")

    st.subheader("Delete Settings")
    delete_route = st.text_input("Delete route", value=DELETE_BLOB_ROUTE)


tab_browse, tab_upload = st.tabs(["🧭 Browse Storage", "📤 Upload"])

with tab_browse:
    st.markdown("### List blobs in `model-2`")

    browse_container = st.text_input("Container name", value=DEFAULT_CONTAINER_TO_BROWSE)

    if st.button("🗂️ Fetch blobs", type="primary", use_container_width=True):
        params = {"container": browse_container.strip(), "limit": str(browse_limit)}
        if browse_prefix.strip():
            params["prefix"] = browse_prefix.strip()
        if storage_account.strip():
            params["storageAccount"] = storage_account.strip()
        if function_key.strip():
            params["code"] = function_key.strip()

        show_request_debug("GET (try /api first)", build_url(function_base_url, STORAGE_STATUS_ROUTE, True), params)
        with st.spinner("Fetching blobs…"):
            resp, used_api = get_with_auto_prefix(function_base_url, STORAGE_STATUS_ROUTE, params=params)
            data = safe_json(resp)

            if resp.status_code == 200:
                blobs = data.get("blobs", []) or []
                st.session_state.last_blob_list = blobs
                st.success(f"✅ OK (used {'/api' if used_api else 'no /api'}). Returned {len(blobs)} blob(s).")
                st.dataframe(blobs, use_container_width=True)
                st.expander("Raw response").json(data)
            else:
                st.error(f"❌ Failed (HTTP {resp.status_code}) (used {'/api' if used_api else 'no /api'})")
                st.json(data)

    blobs = st.session_state.last_blob_list
    if blobs:
        st.markdown("### Delete blob")

        blob_names = []
        for item in blobs:
            if isinstance(item, dict):
                blob_name = item.get("name") or item.get("blob") or item.get("blobName")
                if blob_name:
                    blob_names.append(blob_name)
            elif isinstance(item, str):
                blob_names.append(item)

        blob_names = sorted(set(blob_names))

        selected_blob = st.selectbox(
            "Select blob to delete",
            options=blob_names,
            index=None,
            placeholder="Choose a blob",
        )

        confirm_delete = st.checkbox("I confirm I want to permanently delete the selected blob")

        if st.button("🗑️ Delete selected blob", type="secondary", use_container_width=True, disabled=not selected_blob):
            if not selected_blob:
                st.warning("Please select a blob.")
            elif not confirm_delete:
                st.warning("Please confirm deletion before proceeding.")
            else:
                params = {
                    "container": browse_container.strip(),
                    "blob": selected_blob,
                }
                if storage_account.strip():
                    params["storageAccount"] = storage_account.strip()
                if function_key.strip():
                    params["code"] = function_key.strip()

                show_request_debug("DELETE (try /api first)", build_url(function_base_url, delete_route, True), params)
                with st.spinner(f"Deleting '{selected_blob}'…"):
                    resp, used_api = delete_with_auto_prefix(function_base_url, delete_route, params=params)
                    data = safe_json(resp)

                    if resp.status_code in (200, 202, 204):
                        st.success(
                            f"✅ Blob deleted successfully (used {'/api' if used_api else 'no /api'}): {selected_blob}"
                        )
                        st.session_state.last_blob_list = [
                            b for b in blobs
                            if not (
                                (isinstance(b, dict) and ((b.get('name') or b.get('blob') or b.get('blobName')) == selected_blob))
                                or (isinstance(b, str) and b == selected_blob)
                            )
                        ]
                        if resp.status_code != 204:
                            st.json(data)
                    else:
                        st.error(
                            f"❌ Delete failed (HTTP {resp.status_code}) (used {'/api' if used_api else 'no /api'})"
                        )
                        st.json(data)

with tab_upload:
    st.markdown("### Upload file")
    uploaded_file = st.file_uploader("Choose a CSV or Excel file", type=["csv", "xlsx", "xls"])
    custom_blob_name = st.text_input("Custom blob name (optional)", value="")

    overwrite = st.checkbox("Overwrite if exists", value=True)

    if uploaded_file is not None and st.button("🚀 Upload", type="primary", use_container_width=True):
        params = {"overwrite": str(overwrite).lower()}
        if storage_account.strip():
            params["storageAccount"] = storage_account.strip()
        if custom_blob_name.strip():
            params["blob"] = custom_blob_name.strip()
        if function_key.strip():
            params["code"] = function_key.strip()

        if uploaded_file.name.endswith(".xlsx"):
            mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        elif uploaded_file.name.endswith(".xls"):
            mime_type = "application/vnd.ms-excel"
        else:
            mime_type = "text/csv"

        files = {"file": (uploaded_file.name, uploaded_file.getvalue(), mime_type)}

        show_request_debug("POST (try /api first)", build_url(function_base_url, UPLOAD_ROUTE, True), params)
        with st.spinner("Uploading…"):
            resp, used_api = post_with_auto_prefix(function_base_url, UPLOAD_ROUTE, params=params, files=files)
            data = safe_json(resp)

            if resp.status_code == 200:
                st.success(f"✅ Upload OK (used {'/api' if used_api else 'no /api'})")
                st.json(data)
            else:
                st.error(f"❌ Upload failed (HTTP {resp.status_code}) (used {'/api' if used_api else 'no /api'})")
                st.json(data)



# import os
# import json
# from urllib.parse import urlencode

# import requests
# import streamlit as st

# DEFAULT_FUNCTION_URL = "https://func-sla-catboost-infer-uat-eastus.azurewebsites.net"

# UPLOAD_ROUTE = "catboost_upload_dataset"
# STORAGE_STATUS_ROUTE = "catboost_files_in_storage"
# DEFAULT_CONTAINER_TO_BROWSE = "model-2"

# st.set_page_config(page_title="CatBoost Storage Browser + Uploader", page_icon="📤", layout="wide")
# st.title("CatBoost — Upload + Storage Browser")

# def safe_json(resp: requests.Response):
#     try:
#         return resp.json()
#     except Exception:
#         return {"raw_text": resp.text}

# def show_request_debug(method: str, url: str, params: dict):
#     with st.expander("🔗 Request Details (debug)"):
#         qs = urlencode({k: v for k, v in params.items() if v is not None and v != ""})
#         st.code(f"{method} {url}?{qs}", language="text")
#         st.code(json.dumps(params, indent=2), language="json")

# def build_url(base_url: str, route: str, use_api_prefix: bool) -> str:
#     base = base_url.rstrip("/")
#     if use_api_prefix:
#         return f"{base}/api/{route}"
#     return f"{base}/{route}"

# def get_with_auto_prefix(base_url: str, route: str, params: dict, timeout: int = 180):
#     """
#     Try /api/<route> first. If 404, try /<route>.
#     Returns (resp, used_api_prefix: bool)
#     """
#     url_api = build_url(base_url, route, use_api_prefix=True)
#     resp = requests.get(url_api, params=params, timeout=timeout)
#     if resp.status_code != 404:
#         return resp, True

#     url_no_api = build_url(base_url, route, use_api_prefix=False)
#     resp2 = requests.get(url_no_api, params=params, timeout=timeout)
#     return resp2, False

# def post_with_auto_prefix(base_url: str, route: str, params: dict, files: dict, timeout: int = 180):
#     url_api = build_url(base_url, route, use_api_prefix=True)
#     resp = requests.post(url_api, params=params, files=files, timeout=timeout)
#     if resp.status_code != 404:
#         return resp, True

#     url_no_api = build_url(base_url, route, use_api_prefix=False)
#     resp2 = requests.post(url_no_api, params=params, files=files, timeout=timeout)
#     return resp2, False

# with st.sidebar:
#     st.header("⚙️ Settings")
#     function_base_url = st.text_input("Function App Base URL", value=os.getenv("FUNCTION_BASE_URL", DEFAULT_FUNCTION_URL))

#     st.subheader("Auth (only if required)")
#     function_key = st.text_input(
#         "Function key (optional)",
#         value=os.getenv("FUNCTION_KEY", ""),
#         type="password",
#         help="Only needed if your functions are not Anonymous.",
#     )

#     st.subheader("Storage (optional override)")
#     storage_account = st.text_input("Storage Account Name (optional)", value="", placeholder="(uses server default)")

#     st.subheader("Browse Settings")
#     browse_limit = st.slider("Browse limit (server max 500)", 10, 500, 500, 10)
#     browse_prefix = st.text_input("Browse prefix (optional)", value="", placeholder="e.g. model/")

# tab_browse, tab_upload = st.tabs(["🧭 Browse Storage", "📤 Upload"])

# with tab_browse:
#     st.markdown("### List blobs in `model-2`")

#     browse_container = st.text_input("Container name", value=DEFAULT_CONTAINER_TO_BROWSE)

#     if st.button("🗂️ Fetch blobs", type="primary", use_container_width=True):
#         params = {"container": browse_container.strip(), "limit": str(browse_limit)}
#         if browse_prefix.strip():
#             params["prefix"] = browse_prefix.strip()
#         if storage_account.strip():
#             params["storageAccount"] = storage_account.strip()
#         if function_key.strip():
#             params["code"] = function_key.strip()

#         # Show both possible URLs for debugging
#         show_request_debug("GET (try /api first)", build_url(function_base_url, STORAGE_STATUS_ROUTE, True), params)
#         with st.spinner("Fetching blobs…"):
#             resp, used_api = get_with_auto_prefix(function_base_url, STORAGE_STATUS_ROUTE, params=params)
#             data = safe_json(resp)

#             if resp.status_code == 200:
#                 st.success(f"✅ OK (used {'/api' if used_api else 'no /api'}). Returned {len(data.get('blobs', []))} blob(s).")
#                 st.dataframe(data.get("blobs", []), use_container_width=True)
#                 st.expander("Raw response").json(data)
#             else:
#                 st.error(f"❌ Failed (HTTP {resp.status_code}) (used {'/api' if used_api else 'no /api'})")
#                 st.json(data)

# with tab_upload:
#     st.markdown("### Upload file")
#     uploaded_file = st.file_uploader("Choose a CSV or Excel file", type=["csv", "xlsx", "xls"])
#     custom_blob_name = st.text_input("Custom blob name (optional)", value="")

#     overwrite = st.checkbox("Overwrite if exists", value=True)

#     if uploaded_file is not None and st.button("🚀 Upload", type="primary", use_container_width=True):
#         params = {"overwrite": str(overwrite).lower()}
#         if storage_account.strip():
#             params["storageAccount"] = storage_account.strip()
#         if custom_blob_name.strip():
#             params["blob"] = custom_blob_name.strip()
#         if function_key.strip():
#             params["code"] = function_key.strip()

#         if uploaded_file.name.endswith(".xlsx"):
#             mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
#         elif uploaded_file.name.endswith(".xls"):
#             mime_type = "application/vnd.ms-excel"
#         else:
#             mime_type = "text/csv"

#         files = {"file": (uploaded_file.name, uploaded_file.getvalue(), mime_type)}

#         show_request_debug("POST (try /api first)", build_url(function_base_url, UPLOAD_ROUTE, True), params)
#         with st.spinner("Uploading…"):
#             resp, used_api = post_with_auto_prefix(function_base_url, UPLOAD_ROUTE, params=params, files=files)
#             data = safe_json(resp)

#             if resp.status_code == 200:
#                 st.success(f"✅ Upload OK (used {'/api' if used_api else 'no /api'})")
#                 st.json(data)
#             else:
#                 st.error(f"❌ Upload failed (HTTP {resp.status_code}) (used {'/api' if used_api else 'no /api'})")
#                 st.json(data)