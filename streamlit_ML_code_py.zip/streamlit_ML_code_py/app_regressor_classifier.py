import streamlit as st
import pandas as pd
import json
import requests
import urllib3
import base64
import os

# Suppress the "InsecureRequestWarning"
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE_URL = "https://func-sla-catboost-train-uat-eastus.azurewebsites.net"

ENDPOINTS = {
    "regressor_infer": f"{BASE_URL}/catboost_regressor_infer",
    "regressor_train": f"{BASE_URL}/catboost_regressor_train",
    "classifier_infer": f"{BASE_URL}/catboost_classifier_infer",
    "classifier_train": f"{BASE_URL}/catboost_classifier_train",
    "infer_all": f"{BASE_URL}/infer_all",
    "train_all": f"{BASE_URL}/train_all",
}


# --- Helper Function to Encode Local Image ---
def get_base64_image(image_path):
    try:
        if os.path.exists(image_path):
            with open(image_path, "rb") as img_file:
                return base64.b64encode(img_file.read()).decode()
        return None
    except Exception:
        return None


# --- Page Config ---
st.set_page_config(page_title="Cosmic Case SLA Prediction", layout="wide")

# --- Load Logo ---
img_path = os.path.join("assets", "microsoft-logo.png")
img_base64 = get_base64_image(img_path)

# --- Sidebar ---
with st.sidebar:
    st.markdown("### 🔗 Endpoint Configuration")
    st.caption("All endpoints are auto-configured. Override below if needed.")

    with st.expander("Endpoint URLs", expanded=False):
        for key in ENDPOINTS:
            ENDPOINTS[key] = st.text_input(
                key.replace("_", " ").title(),
                value=ENDPOINTS[key],
                key=f"endpoint_{key}",
            )

    st.markdown("---")
    st.markdown("### ℹ️ Endpoints")
    st.markdown(
        """
        | Endpoint | Purpose |
        |----------|---------|
        | `regressor_infer` | Predict SLA duration |
        | `regressor_train` | Retrain regressor model |
        | `classifier_infer` | Predict Hold/No-Hold |
        | `classifier_train` | Retrain classifier model |
        | `infer_all` | Run both inferences |
        | `train_all` | Retrain both models |
        """
    )

# --- Initialize Session State ---
for key in [
    "data", "reg_built_payload", "reg_final_display_df",
    "clf_built_payload", "clf_final_display_df",
    "infer_all_reg_df", "infer_all_clf_df",
]:
    if key not in st.session_state:
        st.session_state[key] = None

if "clf_threshold" not in st.session_state:
    st.session_state.clf_threshold = 0.5

# --- Main UI ---
st.markdown("# 🚀 Cosmic Case SLA Prediction")

# =============================================================================
# SHARED FILE UPLOAD (single source for all infer endpoints)
# =============================================================================
st.markdown("## 📂 Upload Input Data")
st.markdown("This data will be used across **all inference tabs**.")

uploaded_file = st.file_uploader(
    "Upload CSV/Excel", type=["csv", "xlsx"], key="shared_uploader"
)
if uploaded_file:
    df = (
        pd.read_csv(uploaded_file)
        if uploaded_file.name.endswith(".csv")
        else pd.read_excel(uploaded_file)
    )
    st.session_state.data = df

if st.session_state.data is not None:
    st.success(f"✅ Data loaded: **{len(st.session_state.data)}** rows, **{len(st.session_state.data.columns)}** columns")
    with st.expander("Preview Data", expanded=False):
        st.dataframe(st.session_state.data.head(10))

st.markdown("---")

# --- Tabs ---
tab_regression, tab_classifier, tab_infer_all, tab_train = st.tabs(
    ["📈 SLA Regression Infer", "🏷️ Hold Classifier Infer", "⚡ Infer All", "🔧 Training"]
)


# =============================================================================
# HELPER: Build records from uploaded data
# =============================================================================
def get_records(row_num: int) -> list:
    """Return list of record dicts from session data. row_num=0 means all rows."""
    if st.session_state.data is None:
        return []
    if row_num == 0:
        records = st.session_state.data.to_dict(orient="records")
    else:
        row_data = st.session_state.data.iloc[row_num - 1].to_dict()
        records = [row_data]
    # Clean for JSON serialization
    return json.loads(
        pd.DataFrame(records).to_json(orient="records", date_format="iso")
    )


def call_endpoint(url: str, payload: dict) -> dict:
    """POST JSON to endpoint and return parsed response."""
    resp = requests.post(url, json=payload, verify=False, timeout=600)  # 10 minutes
    resp.raise_for_status()
    return resp.json()


def highlight_prediction(val):
    if val == "Hold":
        return "background-color: #ffcccc; color: #990000; font-weight: bold"
    elif val == "No Hold":
        return "background-color: #ccffcc; color: #006600; font-weight: bold"
    return ""


# =============================================================================
# TAB 1: Regression Inference
# =============================================================================
with tab_regression:
    st.markdown("## SLA Duration Prediction (Regression)")
    st.markdown(
        "Run inference against the **CatBoost regression** model "
        "to predict case resolution duration and dates."
    )

    if st.session_state.data is None:
        st.warning("⬆️ Please upload data above first.")
    else:
        reg_row = st.number_input(
            "Select Row (0 = all rows)",
            min_value=0,
            max_value=len(st.session_state.data),
            value=1,
            key="reg_row_num",
            help="Select 0 to run inference on ALL rows.",
        )

        col1, col2 = st.columns(2)
        with col1:
            if st.button("Build Payload", key="reg_build"):
                records = get_records(reg_row)
                payload = {"data": records, "save_to_blob": False}
                st.session_state.reg_built_payload = json.dumps(payload, indent=2)

        if st.session_state.reg_built_payload:
            with st.expander("Payload Preview", expanded=False):
                st.code(st.session_state.reg_built_payload, language="json")

        with col2:
            if st.button("🚀 Run Regression Inference", type="primary", key="reg_infer"):
                if not st.session_state.reg_built_payload:
                    st.error("Please build payload first.")
                else:
                    try:
                        with st.spinner("Calling Regression Inference..."):
                            payload = json.loads(st.session_state.reg_built_payload)
                            resp_json = call_endpoint(ENDPOINTS["regressor_infer"], payload)

                            results = resp_json.get("results", [])
                            if results:
                                pred_df = pd.DataFrame(results)
                                st.session_state.reg_final_display_df = pred_df
                                st.success(f"✅ Prediction complete — {len(results)} record(s)")
                            else:
                                st.warning("API returned success but no result data.")
                    except Exception as e:
                        st.error(f"Error: {e}")

        if st.session_state.reg_final_display_df is not None:
            st.subheader("Regression Results")
            st.dataframe(st.session_state.reg_final_display_df, use_container_width=True)
            csv_data = st.session_state.reg_final_display_df.to_csv(index=False)
            st.download_button(
                "📥 Download Results as CSV", csv_data,
                file_name="regression_results.csv", mime="text/csv", key="reg_download",
            )

# =============================================================================
# TAB 2: Classifier Inference
# =============================================================================
with tab_classifier:
    st.markdown("## Hold / No-Hold Classification")
    st.markdown(
        "Run inference against the **CatBoost classifier** model "
        "to predict whether a case will be placed on hold."
    )

    if st.session_state.data is None:
        st.warning("⬆️ Please upload data above first.")
    else:
        col_opts1, col_opts2 = st.columns(2)
        with col_opts1:
            threshold = st.number_input(
                "Decision Threshold", min_value=0.0, max_value=1.0,
                value=0.5, step=0.01, key="clf_threshold_input",
                help="Probability threshold for classifying as Hold.",
            )
        with col_opts2:
            include_input = st.checkbox(
                "Include original input columns in results",
                value=False, key="clf_include_input_checkbox",
            )

        clf_row = st.number_input(
            "Select Row (0 = all rows)",
            min_value=0,
            max_value=len(st.session_state.data),
            value=0, key="clf_row_num",
        )

        col1, col2 = st.columns(2)
        with col1:
            if st.button("Build Payload", key="clf_build"):
                records = get_records(clf_row)
                payload = {
                    "data": records,
                    "threshold": threshold,
                    "save_to_blob": False,
                    "include_input": include_input,
                }
                st.session_state.clf_built_payload = json.dumps(payload, indent=2)

        if st.session_state.clf_built_payload:
            with st.expander("Payload Preview", expanded=False):
                st.code(st.session_state.clf_built_payload, language="json")

        with col2:
            if st.button("🚀 Run Classification", type="primary", key="clf_infer"):
                if not st.session_state.clf_built_payload:
                    st.error("Please build payload first.")
                else:
                    try:
                        with st.spinner("Calling Classifier Inference..."):
                            payload = json.loads(st.session_state.clf_built_payload)
                            resp_json = call_endpoint(ENDPOINTS["classifier_infer"], payload)

                            results = resp_json.get("results", [])
                            if results:
                                pred_df = pd.DataFrame(results)
                                st.session_state.clf_final_display_df = pred_df

                                hold_count = resp_json.get("hold_count", 0)
                                no_hold_count = resp_json.get("no_hold_count", 0)
                                threshold_used = resp_json.get("threshold_used", threshold)

                                m1, m2, m3, m4 = st.columns(4)
                                m1.metric("Records", resp_json.get("records_processed", len(results)))
                                m2.metric("Hold", hold_count)
                                m3.metric("No Hold", no_hold_count)
                                m4.metric("Threshold", f"{threshold_used:.4f}")
                                st.success("✅ Classification complete.")
                            else:
                                st.warning("API returned success but no result data.")
                    except Exception as e:
                        st.error(f"Error: {e}")

        if st.session_state.clf_final_display_df is not None:
            st.subheader("Classification Results")
            result_df = st.session_state.clf_final_display_df
            if "prediction_label" in result_df.columns:
                styled = result_df.style.applymap(
                    highlight_prediction, subset=["prediction_label"]
                )
                st.dataframe(styled, use_container_width=True)
            else:
                st.dataframe(result_df, use_container_width=True)

            csv_data = result_df.to_csv(index=False)
            st.download_button(
                "📥 Download Results as CSV", csv_data,
                file_name="classification_results.csv", mime="text/csv", key="clf_download",
            )

# =============================================================================
# TAB 3: Infer All (both regressor + classifier in one call)
# =============================================================================
with tab_infer_all:
    st.markdown("## ⚡ Infer All (Regressor + Classifier)")
    st.markdown(
        "Trigger **both** regression and classifier inference in a single call "
        "using the `/infer_all` endpoint."
    )

    if st.session_state.data is None:
        st.warning("⬆️ Please upload data above first.")
    else:
        infer_all_row = st.number_input(
            "Select Row (0 = all rows)",
            min_value=0,
            max_value=len(st.session_state.data),
            value=0, key="infer_all_row_num",
        )
        infer_all_threshold = st.number_input(
            "Classifier Threshold", min_value=0.0, max_value=1.0,
            value=0.5, step=0.01, key="infer_all_threshold",
        )

        if st.button("🚀 Run Infer All", type="primary", key="infer_all_btn"):
            try:
                records = get_records(infer_all_row)
                payload = {
                    "data": records,
                    "threshold": infer_all_threshold,
                    "save_to_blob": False,
                    "include_input": False,
                }
                with st.spinner("Calling Infer All endpoint..."):
                    resp_json = call_endpoint(ENDPOINTS["infer_all"], payload)

                st.success("✅ Infer All complete.")
                st.json(resp_json)

                # Try to parse regressor and classifier results if present
                reg_results = resp_json.get("regressor_results") or resp_json.get("regression_results") or resp_json.get("results", [])
                clf_results = resp_json.get("classifier_results") or resp_json.get("classification_results", [])

                if reg_results:
                    st.subheader("Regressor Results")
                    reg_df = pd.DataFrame(reg_results) if isinstance(reg_results, list) else pd.DataFrame(reg_results.get("results", []))
                    st.session_state.infer_all_reg_df = reg_df
                    st.dataframe(reg_df, use_container_width=True)

                if clf_results:
                    st.subheader("Classifier Results")
                    clf_df = pd.DataFrame(clf_results) if isinstance(clf_results, list) else pd.DataFrame(clf_results.get("results", []))
                    st.session_state.infer_all_clf_df = clf_df
                    if "prediction_label" in clf_df.columns:
                        styled = clf_df.style.applymap(
                            highlight_prediction, subset=["prediction_label"]
                        )
                        st.dataframe(styled, use_container_width=True)
                    else:
                        st.dataframe(clf_df, use_container_width=True)

            except Exception as e:
                st.error(f"Error: {e}")

# =============================================================================
# TAB 4: Training (Regressor, Classifier, Train All)
# =============================================================================
with tab_train:
    st.markdown("## 🔧 Model Training")
    st.markdown(
        "Trigger model retraining for the **Regressor**, **Classifier**, or **both** models. "
        "Training runs on Azure — no local data upload is needed."
    )

    st.warning(
        "⚠️ Training will retrain the model(s) on Azure using the configured training data in blob storage. "
        "This may take several minutes."
    )

    col_t1, col_t2, col_t3 = st.columns(3)

    # --- Train Regressor ---
    with col_t1:
        st.markdown("### 📈 Regressor")
        st.caption("Retrain the SLA duration prediction model.")
        if st.button("🔄 Train Regressor", key="train_reg_btn"):
            try:
                with st.spinner("Training Regressor model..."):
                    resp_json = call_endpoint(ENDPOINTS["regressor_train"], {})
                if resp_json.get("success", False):
                    st.success("✅ Regressor training complete!")
                else:
                    st.warning("Training returned a response but success=false.")
                st.json(resp_json)
            except requests.exceptions.HTTPError as e:
                st.error(f"HTTP Error: {e.response.status_code} — {e.response.text}")
            except Exception as e:
                st.error(f"Error: {e}")

    # --- Train Classifier ---
    with col_t2:
        st.markdown("### 🏷️ Classifier")
        st.caption("Retrain the Hold/No-Hold classification model.")
        if st.button("🔄 Train Classifier", key="train_clf_btn"):
            try:
                with st.spinner("Training Classifier model..."):
                    resp_json = call_endpoint(ENDPOINTS["classifier_train"], {})
                if resp_json.get("success", False):
                    st.success("✅ Classifier training complete!")
                else:
                    st.warning("Training returned a response but success=false.")
                st.json(resp_json)
            except requests.exceptions.HTTPError as e:
                st.error(f"HTTP Error: {e.response.status_code} — {e.response.text}")
            except Exception as e:
                st.error(f"Error: {e}")

    # --- Train All ---
    with col_t3:
        st.markdown("### ⚡ Train All")
        st.caption("Retrain **both** models in a single call.")
        if st.button("🔄 Train All", type="primary", key="train_all_btn"):
            try:
                with st.spinner("Training both models..."):
                    resp_json = call_endpoint(ENDPOINTS["train_all"], {})
                if resp_json.get("success", False):
                    st.success("✅ Both models trained successfully!")
                else:
                    st.warning("Training returned a response but success=false.")
                st.json(resp_json)
            except requests.exceptions.HTTPError as e:
                st.error(f"HTTP Error: {e.response.status_code} — {e.response.text}")
            except Exception as e:
                st.error(f"Error: {e}")

    st.markdown("---")
    st.markdown("### 📋 Training Logs")
    st.caption("After triggering training, check Azure Portal → Function App → Monitor for detailed logs.")