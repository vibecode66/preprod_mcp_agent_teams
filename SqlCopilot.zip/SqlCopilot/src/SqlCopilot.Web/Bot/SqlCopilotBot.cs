// ============================================================================
// SqlCopilotBot.cs — Teams Bot for natural language SQL queries
//
// Purpose:
//   Handles incoming messages from Microsoft Teams / M365 Copilot.
//   Orchestrates the full NL→SQL pipeline:
//     1. Receives user's natural language question
//     2. Discovers database schema (cached)
//     3. Generates SQL via Azure OpenAI (with self-healing retry)
//     4. Executes the query against Azure SQL
//     5. Renders results as rich Adaptive Cards
//
// Special commands:
//   /help or "help" — Shows the welcome card with example questions
//   /refresh         — Forces a refresh of the cached database schema
//
// Error handling:
//   - All exceptions are caught and displayed as user-friendly error cards
//   - The AdapterWithErrorHandler provides a global safety net
// ============================================================================

using System.Diagnostics;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Teams;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Logging;
using SqlCopilot.Core.Interfaces;

namespace SqlCopilot.Web.Bot;

/// <summary>
/// Teams Bot that handles natural language queries, converts them to SQL
/// via Azure OpenAI, executes against Azure SQL Database, and returns
/// results as rich Adaptive Cards (tables, charts, KPIs).
/// </summary>
public class SqlCopilotBot : TeamsActivityHandler
{
    private readonly ISchemaDiscoveryService _schemaService;
    private readonly ISqlGeneratorService _sqlGenerator;
    private readonly IQueryExecutionService _queryExecutor;
    private readonly IAdaptiveCardService _cardService;
    private readonly ILogger<SqlCopilotBot> _logger;

    /// <summary>
    /// Initializes the bot with all required services.
    /// </summary>
    /// <param name="schemaService">Service for discovering and caching database schema.</param>
    /// <param name="sqlGenerator">Service for NL→SQL conversion via Azure OpenAI.</param>
    /// <param name="queryExecutor">Service for executing SQL queries safely.</param>
    /// <param name="cardService">Service for building Adaptive Card responses.</param>
    /// <param name="logger">Logger for request tracking and diagnostics.</param>
    public SqlCopilotBot(
        ISchemaDiscoveryService schemaService,
        ISqlGeneratorService sqlGenerator,
        IQueryExecutionService queryExecutor,
        IAdaptiveCardService cardService,
        ILogger<SqlCopilotBot> logger)
    {
        _schemaService = schemaService ?? throw new ArgumentNullException(nameof(schemaService));
        _sqlGenerator = sqlGenerator ?? throw new ArgumentNullException(nameof(sqlGenerator));
        _queryExecutor = queryExecutor ?? throw new ArgumentNullException(nameof(queryExecutor));
        _cardService = cardService ?? throw new ArgumentNullException(nameof(cardService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Handles incoming text messages from users in Teams.
    /// This is the main entry point for natural language queries.
    /// </summary>
    /// <param name="turnContext">The Bot Framework turn context with message details.</param>
    /// <param name="cancellationToken">Cancellation token for async operations.</param>
    protected override async Task OnMessageActivityAsync(
        ITurnContext<IMessageActivity> turnContext,
        CancellationToken cancellationToken)
    {
        var requestStopwatch = Stopwatch.StartNew();
        var userQuery = turnContext.Activity.Text?.Trim();
        var userId = turnContext.Activity.From?.Id ?? "unknown";
        var conversationId = turnContext.Activity.Conversation?.Id ?? "unknown";

        _logger.LogInformation(
            "Message received from user {UserId} in conversation {ConversationId}: {Query}",
            userId, conversationId,
            userQuery?.Length > 200 ? userQuery[..200] + "..." : userQuery);

        // ---- Handle empty messages ----
        if (string.IsNullOrEmpty(userQuery))
        {
            _logger.LogDebug("Empty message received, prompting user");
            await turnContext.SendActivityAsync(
                MessageFactory.Text("Please enter a question about your data."),
                cancellationToken);
            return;
        }

        // Remove bot @mention if present (in Teams channel conversations)
        userQuery = turnContext.Activity.RemoveRecipientMention()?.Trim() ?? userQuery;

        // ---- Handle special commands ----
        if (userQuery.Equals("/help", StringComparison.OrdinalIgnoreCase) ||
            userQuery.Equals("help", StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogInformation("User requested help card");
            var welcomeCard = _cardService.CreateWelcomeCard();
            await turnContext.SendActivityAsync(
                MessageFactory.Attachment(welcomeCard),
                cancellationToken);
            return;
        }

        if (userQuery.Equals("/refresh", StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogInformation("User requested schema cache refresh");
            try
            {
                await _schemaService.RefreshSchemaAsync(cancellationToken);
                await turnContext.SendActivityAsync(
                    MessageFactory.Text("✅ Database schema cache has been refreshed."),
                    cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to refresh schema cache: {Error}", ex.Message);
                var errorCard = _cardService.CreateErrorCard(
                    $"Failed to refresh schema cache: {ex.Message}");
                await turnContext.SendActivityAsync(
                    MessageFactory.Attachment(errorCard),
                    cancellationToken);
            }
            return;
        }

        // ---- Show typing indicator while processing ----
        await turnContext.SendActivitiesAsync(
            new[] { new Microsoft.Bot.Schema.Activity { Type = ActivityTypes.Typing } },
            cancellationToken);

        try
        {
            // Step 1: Get the database schema (cached after first call)
            _logger.LogDebug("Step 1: Retrieving database schema...");
            var schema = await _schemaService.GetSchemaAsync(cancellationToken);

            if (schema.Tables.Count == 0)
            {
                _logger.LogWarning("No tables found in the database schema");
                var errorCard = _cardService.CreateErrorCard(
                    "No tables found in the database. Please check your connection and permissions.");
                await turnContext.SendActivityAsync(
                    MessageFactory.Attachment(errorCard),
                    cancellationToken);
                return;
            }

            _logger.LogDebug("Schema loaded: {TableCount} tables", schema.Tables.Count);

            // Step 2: Generate SQL with self-healing retry
            // The LLM converts the natural language query to T-SQL.
            // If the first query fails execution, the error is fed back to the LLM
            // for automatic correction (up to 3 attempts).
            _logger.LogDebug("Step 2: Generating SQL with self-healing...");
            var (sqlResponse, queryResult) = await _sqlGenerator.GenerateAndValidateAsync(
                userQuery, schema, _queryExecutor, cancellationToken);

            // Handle SQL generation failure
            if (!sqlResponse.IsSuccess)
            {
                _logger.LogWarning(
                    "SQL generation failed for query '{Query}': {Error}",
                    userQuery, sqlResponse.ErrorMessage);

                var errorCard = _cardService.CreateErrorCard(
                    sqlResponse.ErrorMessage ?? "Failed to generate a SQL query from your question.");
                await turnContext.SendActivityAsync(
                    MessageFactory.Attachment(errorCard),
                    cancellationToken);
                return;
            }

            // Handle non-read-only queries (safety check)
            if (!sqlResponse.IsReadOnly)
            {
                _logger.LogWarning(
                    "Non-read-only query rejected. User: {UserId}, Query: {Query}",
                    userId, userQuery);

                var errorCard = _cardService.CreateErrorCard(
                    "🔒 I can only run read-only (SELECT) queries. Please ask a question that retrieves data rather than modifying it.");
                await turnContext.SendActivityAsync(
                    MessageFactory.Attachment(errorCard),
                    cancellationToken);
                return;
            }

            // Step 3: Execute query if not already done by self-healing loop
            // (GenerateAndValidateAsync usually returns the result, but handle edge cases)
            if (queryResult == null)
            {
                _logger.LogDebug("Step 3: Executing SQL query (not yet executed)...");
                queryResult = await _queryExecutor.ExecuteQueryAsync(
                    sqlResponse.GeneratedSql, cancellationToken);
            }

            // Step 4: Build and send Adaptive Card response
            _logger.LogDebug("Step 4: Building Adaptive Card response...");
            Attachment card;
            if (queryResult.IsSuccess)
            {
                card = _cardService.CreateResultCard(queryResult, sqlResponse);
                _logger.LogInformation(
                    "Query completed successfully. Type: {ResultType}, Rows: {Rows}, " +
                    "Chart: {Chart}, Total time: {TotalMs}ms",
                    queryResult.ResultType, queryResult.TotalRowCount,
                    sqlResponse.SuggestedChart, requestStopwatch.ElapsedMilliseconds);
            }
            else
            {
                card = _cardService.CreateErrorCard(
                    $"Query failed after multiple correction attempts.\n\n" +
                    $"**Error:** {queryResult.ErrorMessage}\n\n" +
                    $"**SQL tried:** {sqlResponse.GeneratedSql}");

                _logger.LogWarning(
                    "Query execution failed after self-healing. Error: {Error}, SQL: {Sql}",
                    queryResult.ErrorMessage, sqlResponse.GeneratedSql);
            }

            await turnContext.SendActivityAsync(
                MessageFactory.Attachment(card),
                cancellationToken);
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning(
                "Request cancelled for user {UserId} after {ElapsedMs}ms",
                userId, requestStopwatch.ElapsedMilliseconds);
            // Don't send a message — the conversation may already be gone
        }
        catch (Exception ex)
        {
            requestStopwatch.Stop();
            _logger.LogError(ex,
                "Unhandled error processing query from user {UserId} " +
                "after {ElapsedMs}ms: {Error}. Query: {Query}",
                userId, requestStopwatch.ElapsedMilliseconds,
                ex.Message, userQuery);

            try
            {
                var errorCard = _cardService.CreateErrorCard(
                    "An unexpected error occurred. Please try again or rephrase your question.");
                await turnContext.SendActivityAsync(
                    MessageFactory.Attachment(errorCard),
                    cancellationToken);
            }
            catch (Exception innerEx)
            {
                // Last resort: send a plain text error if even the error card fails
                _logger.LogCritical(innerEx,
                    "Failed to send error card. Sending plain text fallback.");
                await turnContext.SendActivityAsync(
                    MessageFactory.Text("⚠️ An error occurred. Please try again."),
                    cancellationToken);
            }
        }
        finally
        {
            requestStopwatch.Stop();
            _logger.LogDebug(
                "Request processing completed in {ElapsedMs}ms for user {UserId}",
                requestStopwatch.ElapsedMilliseconds, userId);
        }
    }

    /// <summary>
    /// Handles new members joining the conversation.
    /// Sends a welcome card to introduce the bot's capabilities.
    /// </summary>
    /// <param name="membersAdded">List of newly added members.</param>
    /// <param name="turnContext">The Bot Framework turn context.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    protected override async Task OnMembersAddedAsync(
        IList<ChannelAccount> membersAdded,
        ITurnContext<IConversationUpdateActivity> turnContext,
        CancellationToken cancellationToken)
    {
        foreach (var member in membersAdded)
        {
            // Don't send a welcome card to the bot itself
            if (member.Id != turnContext.Activity.Recipient.Id)
            {
                _logger.LogInformation(
                    "New member added: {MemberId}. Sending welcome card.",
                    member.Id);

                try
                {
                    var welcomeCard = _cardService.CreateWelcomeCard();
                    await turnContext.SendActivityAsync(
                        MessageFactory.Attachment(welcomeCard),
                        cancellationToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex,
                        "Failed to send welcome card to member {MemberId}: {Error}",
                        member.Id, ex.Message);
                }
            }
        }
    }
}
