// ============================================================================
// Program.cs — Application entry point and dependency injection configuration
//
// Purpose:
//   Configures and starts the ASP.NET Core web host for the SQL Copilot
//   application. Registers all services, middleware, and endpoints:
//
//   Services registered:
//     - ISqlConnectionFactory   — Azure SQL connections (MI or SQL auth)
//     - ISchemaDiscoveryService — Database schema discovery with caching
//     - ISqlGeneratorService    — NL→SQL via Azure OpenAI
//     - IQueryExecutionService  — Safe SQL execution with guardrails
//     - IChartService           — Chart image generation via QuickChart.io
//     - IAdaptiveCardService    — Adaptive Card rendering for Teams
//     - Bot Framework services  — Authentication, adapter, bot handler
//
//   Endpoints:
//     GET  /         — Health check
//     POST /api/messages — Bot Framework activity endpoint (Teams)
//     POST /api/query    — REST API for M365 Copilot plugin
//     GET  /swagger      — Swagger UI for API documentation
// ============================================================================

using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Integration.AspNet.Core;
using Microsoft.Bot.Connector.Authentication;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;
using SqlCopilot.Core.Services;
using SqlCopilot.Web.Bot;

var builder = WebApplication.CreateBuilder(args);

// ---- Logging configuration ----
// ASP.NET Core configures console + debug logging by default.
// Azure App Service captures stdout logs automatically.
builder.Logging.AddConsole();

// ---- Bind configuration sections to strongly-typed options ----
builder.Services.Configure<AzureSqlOptions>(
    builder.Configuration.GetSection(AzureSqlOptions.SectionName));
builder.Services.Configure<AzureOpenAIOptions>(
    builder.Configuration.GetSection(AzureOpenAIOptions.SectionName));

// ---- Memory Cache (for schema caching) ----
builder.Services.AddMemoryCache();

// ---- Core Services (singleton — stateless, thread-safe) ----
builder.Services.AddSingleton<ISqlConnectionFactory, SqlConnectionFactory>();
builder.Services.AddSingleton<ISchemaDiscoveryService, SchemaDiscoveryService>();
builder.Services.AddSingleton<ISqlGeneratorService, SqlGeneratorService>();
builder.Services.AddSingleton<IQueryExecutionService, QueryExecutionService>();
builder.Services.AddSingleton<IChartService, ChartService>();
builder.Services.AddSingleton<IAdaptiveCardService, AdaptiveCardService>();

// ---- Bot Framework ----
// ConfigurationBotFrameworkAuthentication reads MicrosoftAppId, MicrosoftAppType, etc.
// from appsettings.json. Supports UserAssignedMSI for passwordless auth.
builder.Services.AddSingleton<BotFrameworkAuthentication, ConfigurationBotFrameworkAuthentication>();
builder.Services.AddSingleton<IBotFrameworkHttpAdapter, AdapterWithErrorHandler>();
// Bot is transient — new instance per turn for clean state
builder.Services.AddTransient<IBot, SqlCopilotBot>();

// ---- Controllers ----
builder.Services.AddControllers();

// ---- Swagger / OpenAPI documentation ----
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "SQL Copilot API",
        Version = "v1",
        Description = "Natural language to SQL query API for M365 Copilot. " +
            "Accepts plain English questions and returns structured query results."
    });
});

var app = builder.Build();

// Log startup information
var logger = app.Services.GetRequiredService<ILogger<Program>>();
logger.LogInformation("SQL Copilot starting up...");
logger.LogInformation("Environment: {Environment}", app.Environment.EnvironmentName);

// ---- Middleware pipeline ----

// Enable Swagger in all environments for API documentation
app.UseSwagger();
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "SQL Copilot API v1");
    options.RoutePrefix = "swagger";
});

app.UseRouting();
app.UseAuthorization();
app.MapControllers();

// Health check endpoint — used by Azure App Service health probes
app.MapGet("/", () => Results.Ok(new
{
    status = "healthy",
    service = "SqlCopilot",
    timestamp = DateTime.UtcNow
}));

logger.LogInformation("SQL Copilot started successfully");

app.Run();
