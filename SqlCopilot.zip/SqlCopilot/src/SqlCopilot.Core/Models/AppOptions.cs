// ============================================================================
// AppOptions.cs — Configuration option classes
//
// Purpose:
//   Strongly-typed configuration classes that map to appsettings.json sections.
//   Used with IOptions<T> for dependency injection of configuration values.
//
// Sections:
//   "AzureSql"    → AzureSqlOptions    (connection string, MI, timeouts)
//   "AzureOpenAI" → AzureOpenAIOptions (endpoint, API key, model settings)
// ============================================================================

namespace SqlCopilot.Core.Models;

/// <summary>
/// Configuration options for Azure SQL Database connectivity.
/// Maps to the "AzureSql" section in appsettings.json.
/// </summary>
public class AzureSqlOptions
{
    /// <summary>The configuration section name in appsettings.json.</summary>
    public const string SectionName = "AzureSql";

    /// <summary>
    /// ADO.NET connection string for Azure SQL Database.
    /// When using Managed Identity, this should NOT contain User ID or Password.
    /// Example: "Server=myserver.database.windows.net;Database=mydb;Encrypt=True;"
    /// </summary>
    public string ConnectionString { get; set; } = string.Empty;

    /// <summary>
    /// When <c>true</c>, uses <see cref="Azure.Identity.DefaultAzureCredential"/>
    /// (Managed Identity) to authenticate to Azure SQL.
    /// The connection string should NOT contain User ID / Password in this mode.
    /// When <c>false</c>, uses the connection string as-is (SQL auth with user/password).
    /// </summary>
    public bool UseManagedIdentity { get; set; } = true;

    /// <summary>
    /// Client ID of the User-Assigned Managed Identity.
    /// Leave empty to use System-Assigned Managed Identity.
    /// Only used when <see cref="UseManagedIdentity"/> is <c>true</c>.
    /// </summary>
    public string ManagedIdentityClientId { get; set; } = string.Empty;

    /// <summary>
    /// Maximum time in seconds to wait for a query to complete.
    /// Queries exceeding this timeout are cancelled.
    /// Default: 30 seconds.
    /// </summary>
    public int QueryTimeoutSeconds { get; set; } = 30;

    /// <summary>
    /// Maximum number of rows to return from a query.
    /// Rows beyond this limit are counted but not stored.
    /// Default: 100 rows.
    /// </summary>
    public int MaxRowsReturned { get; set; } = 100;

    /// <summary>
    /// How long (in minutes) to cache the database schema in memory.
    /// Use /refresh command to force an earlier refresh.
    /// Default: 60 minutes.
    /// </summary>
    public int SchemaCacheMinutes { get; set; } = 60;
}

/// <summary>
/// Configuration options for Azure OpenAI service.
/// Maps to the "AzureOpenAI" section in appsettings.json.
/// </summary>
public class AzureOpenAIOptions
{
    /// <summary>The configuration section name in appsettings.json.</summary>
    public const string SectionName = "AzureOpenAI";

    /// <summary>
    /// The Azure OpenAI resource endpoint URL.
    /// Example: "https://myresource.openai.azure.com/"
    /// </summary>
    public string Endpoint { get; set; } = string.Empty;

    /// <summary>
    /// API key for Azure OpenAI authentication.
    /// Store in Azure Key Vault or App Service Configuration in production.
    /// </summary>
    public string ApiKey { get; set; } = string.Empty;

    /// <summary>
    /// The name of the deployed model (e.g., "gpt-4.1", "gpt-4o").
    /// This must match the deployment name in Azure OpenAI Studio.
    /// </summary>
    public string DeploymentName { get; set; } = "gpt-4o";

    /// <summary>
    /// Controls randomness of the LLM output. Lower values (0.0) produce
    /// more deterministic SQL; higher values allow more creative responses.
    /// Recommended: 0.0 for SQL generation.
    /// </summary>
    public float Temperature { get; set; } = 0.0f;

    /// <summary>
    /// Maximum number of tokens the LLM can generate in its response.
    /// Default: 2048 (sufficient for SQL + JSON wrapper).
    /// </summary>
    public int MaxTokens { get; set; } = 2048;
}
