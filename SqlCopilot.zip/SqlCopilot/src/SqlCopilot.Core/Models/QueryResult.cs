// ============================================================================
// QueryResult.cs — SQL query execution result model
//
// Purpose:
//   Represents the result of executing a SQL query, including column metadata,
//   row data, timing, and an auto-detected result type for Adaptive Card
//   rendering (Table, KPI, KeyValue, SingleRecord, Empty, Error).
// ============================================================================

namespace SqlCopilot.Core.Models;

/// <summary>
/// Represents the result of executing a SQL query, including column metadata,
/// row data, execution timing, and an auto-detected result type.
/// </summary>
public class QueryResult
{
    /// <summary>Whether the query executed successfully.</summary>
    public bool IsSuccess { get; set; }

    /// <summary>Error message if execution failed (null on success).</summary>
    public string? ErrorMessage { get; set; }

    /// <summary>The SQL query that was executed.</summary>
    public string SqlQuery { get; set; } = string.Empty;

    /// <summary>Column definitions (name and SQL data type).</summary>
    public List<QueryColumn> Columns { get; set; } = new();

    /// <summary>
    /// Row data as a list of dictionaries (column name → value).
    /// Values are pre-converted to serializable types (strings for dates,
    /// decimals for precision, etc.).
    /// </summary>
    public List<Dictionary<string, object?>> Rows { get; set; } = new();

    /// <summary>
    /// Total number of rows returned by the query (may exceed <see cref="Rows"/>.Count
    /// if truncated by the row limit).
    /// </summary>
    public int TotalRowCount { get; set; }

    /// <summary>
    /// Whether the result was truncated because it exceeded the configured row limit.
    /// </summary>
    public bool IsTruncated { get; set; }

    /// <summary>How long the query took to execute.</summary>
    public TimeSpan ExecutionTime { get; set; }

    /// <summary>
    /// Auto-detects the result type based on row count, column count, and data types.
    /// Used by the Adaptive Card service to select the best card layout:
    ///   - Kpi: single-value or few-metric aggregation (e.g., COUNT, SUM, AVG)
    ///   - SingleRecord: one row with many columns (detail view)
    ///   - KeyValue: two columns with multiple rows (fact-set layout)
    ///   - Table: multi-row, multi-column data grid
    ///   - Empty: no rows returned
    ///   - Error: query execution failed
    /// </summary>
    public QueryResultType ResultType
    {
        get
        {
            if (!IsSuccess) return QueryResultType.Error;
            if (Rows.Count == 0) return QueryResultType.Empty;

            // Single numeric value = KPI card (e.g., COUNT(*), SUM(), AVG())
            if (Rows.Count == 1 && Columns.Count == 1) return QueryResultType.Kpi;

            // Single row with a few aggregated numeric values = multi-KPI card
            if (Rows.Count == 1 && Columns.Count <= 4 && Columns.All(c => IsNumericType(c.DataType)))
                return QueryResultType.Kpi;

            // Single row with up to 6 columns = detail/single-record card
            if (Rows.Count == 1 && Columns.Count <= 6) return QueryResultType.SingleRecord;

            // Two columns with multiple rows = key-value fact-set card
            if (Columns.Count <= 2 && Rows.Count > 1) return QueryResultType.KeyValue;

            // Default: table card
            return QueryResultType.Table;
        }
    }

    /// <summary>
    /// Checks whether a SQL data type is numeric (int, decimal, float, money, etc.).
    /// Used for KPI result type detection.
    /// </summary>
    private static bool IsNumericType(string dataType)
    {
        var dt = dataType.ToLowerInvariant();
        return dt is "int" or "bigint" or "smallint" or "tinyint"
            or "decimal" or "numeric" or "float" or "real"
            or "money" or "smallmoney";
    }
}

/// <summary>
/// Represents a column in a query result with its name and SQL data type.
/// </summary>
public class QueryColumn
{
    /// <summary>The column name as returned by the database.</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>The SQL data type (e.g., "int", "nvarchar", "datetime2").</summary>
    public string DataType { get; set; } = string.Empty;
}

/// <summary>
/// Identifies the shape of a query result for Adaptive Card rendering.
/// Each type maps to a different card layout.
/// </summary>
public enum QueryResultType
{
    /// <summary>Query execution failed.</summary>
    Error,

    /// <summary>Query succeeded but returned zero rows.</summary>
    Empty,

    /// <summary>Single-value or few-metric aggregation (big number card).</summary>
    Kpi,

    /// <summary>Single row with many columns (detail/fact-set card).</summary>
    SingleRecord,

    /// <summary>Two columns, multiple rows (key-value fact-set card).</summary>
    KeyValue,

    /// <summary>Multi-row, multi-column data grid (table card).</summary>
    Table
}
