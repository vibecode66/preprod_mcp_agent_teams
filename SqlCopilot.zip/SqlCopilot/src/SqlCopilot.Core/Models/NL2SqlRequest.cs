// ============================================================================
// NL2SqlRequest.cs — Request and response models for NL→SQL conversion
// ============================================================================

namespace SqlCopilot.Core.Models;

/// <summary>
/// Request model for natural language to SQL conversion.
/// </summary>
public class NL2SqlRequest
{
    /// <summary>The user's natural language question about the data.</summary>
    public string UserQuery { get; set; } = string.Empty;

    /// <summary>Optional conversation ID for tracking multi-turn sessions.</summary>
    public string? ConversationId { get; set; }
}

/// <summary>
/// Response from the SQL generation service.
/// Contains the generated SQL, explanation, safety flags, and visualization hint.
/// </summary>
public class NL2SqlResponse
{
    /// <summary>Whether the SQL was generated successfully.</summary>
    public bool IsSuccess { get; set; }

    /// <summary>The generated T-SQL query (empty if generation failed).</summary>
    public string GeneratedSql { get; set; } = string.Empty;

    /// <summary>
    /// Human-readable explanation of what the query does and any assumptions made.
    /// </summary>
    public string Explanation { get; set; } = string.Empty;

    /// <summary>Error message if generation failed (null on success).</summary>
    public string? ErrorMessage { get; set; }

    /// <summary>
    /// Whether the generated query is read-only (SELECT).
    /// Non-read-only queries are rejected for safety.
    /// </summary>
    public bool IsReadOnly { get; set; } = true;

    /// <summary>
    /// The LLM's suggestion for the best chart type to visualize these results.
    /// Defaults to <see cref="ChartType.Table"/> for multi-column data.
    /// </summary>
    public ChartType SuggestedChart { get; set; } = ChartType.Table;
}

/// <summary>
/// Visualization types supported for query results.
/// The LLM suggests the best type based on query semantics.
/// </summary>
public enum ChartType
{
    /// <summary>Tabular data grid — default for multi-column results.</summary>
    Table,

    /// <summary>Vertical bar chart — comparing categories with numeric values.</summary>
    Bar,

    /// <summary>Pie chart — showing proportions of a whole (2-8 categories).</summary>
    Pie,

    /// <summary>Line chart — trends over time with date/time x-axis.</summary>
    Line,

    /// <summary>Doughnut chart — like pie but with a hollow center.</summary>
    Doughnut,

    /// <summary>Horizontal bar chart — for long category labels.</summary>
    HorizontalBar
}
