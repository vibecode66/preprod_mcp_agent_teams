// ============================================================================
// SqlGeneratorService.cs — Natural Language to SQL conversion via Azure OpenAI
//
// Purpose:
//   Converts user natural-language prompts into safe T-SQL SELECT queries
//   using Azure OpenAI's GPT models. Includes:
//     - A comprehensive system prompt with T-SQL syntax guidelines and examples
//     - Read-only validation (rejects INSERT/UPDATE/DELETE/DROP/etc.)
//     - Self-healing retry loop: if a generated query fails execution, the
//       error is fed back to the LLM for automatic correction (up to 3 tries)
//     - Chart type suggestion based on query semantics
//
// Dependencies:
//   - Azure.AI.OpenAI for LLM communication
//   - IQueryExecutionService for self-healing validation
//   - Database schema context for accurate query generation
// ============================================================================

using System.ClientModel;
using System.Diagnostics;
using System.Text.Json;
using Azure.AI.OpenAI;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OpenAI.Chat;
using SqlCopilot.Core.Exceptions;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services;

/// <summary>
/// Uses Azure OpenAI to convert natural language queries into T-SQL statements.
/// Includes schema context, T-SQL best practices, safety guardrails,
/// and a self-healing retry loop that feeds execution errors back to the LLM.
/// </summary>
public class SqlGeneratorService : ISqlGeneratorService
{
    /// <summary>Maximum number of LLM attempts for self-healing SQL generation.</summary>
    private const int MaxRetries = 3;

    private readonly AzureOpenAIOptions _options;
    private readonly ChatClient _chatClient;
    private readonly ILogger<SqlGeneratorService> _logger;

    /// <summary>
    /// System prompt that instructs the LLM on T-SQL syntax, safety rules,
    /// query best practices, and expected JSON response format.
    /// The database schema is appended at runtime.
    /// </summary>
    private const string SystemPrompt = @"
You are an expert T-SQL query generator for Microsoft SQL Server (Azure SQL Database).
Convert natural language questions into correct, efficient, production-quality T-SQL queries.

ABSOLUTE RULES (never violate):
1. ONLY generate SELECT statements (or WITH...SELECT for CTEs). NEVER generate INSERT, UPDATE, DELETE, DROP, ALTER, CREATE, EXEC, TRUNCATE, MERGE, or any data-modifying statement.
2. ALWAYS use the EXACT table names, schema names, and column names from the DATABASE SCHEMA below. Do NOT guess or invent column/table names.
3. ALWAYS prefix table names with their schema (e.g., dbo.TableName).
4. Use square brackets [ColumnName] for column names that contain spaces or are reserved words.

T-SQL SYNTAX GUIDELINES:
- Use TOP (not LIMIT). T-SQL does not support LIMIT/OFFSET syntax.
  CORRECT: SELECT TOP 10 * FROM dbo.Orders ORDER BY CreatedDate DESC
  WRONG:   SELECT * FROM dbo.Orders LIMIT 10

- For pagination use OFFSET...FETCH:
  SELECT * FROM dbo.Orders ORDER BY Id OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY

- String matching: WHERE Name LIKE '%search%'

- Date functions use T-SQL syntax:
  CORRECT: WHERE CreatedDate >= DATEADD(DAY, -7, GETUTCDATE())
  CORRECT: WHERE CAST(CreatedDate AS DATE) = CAST(GETUTCDATE() AS DATE)
  CORRECT: WHERE YEAR(CreatedDate) = 2024 AND MONTH(CreatedDate) = 3
  WRONG:   WHERE CreatedDate >= NOW() - INTERVAL 7 DAY  (MySQL syntax)

- For ""today"": WHERE CAST(CreatedDate AS DATE) = CAST(GETUTCDATE() AS DATE)
- For ""this month"": WHERE YEAR(CreatedDate) = YEAR(GETUTCDATE()) AND MONTH(CreatedDate) = MONTH(GETUTCDATE())
- For ""last N days"": WHERE CreatedDate >= DATEADD(DAY, -N, GETUTCDATE())
- For ""last N hours"": WHERE CreatedDate >= DATEADD(HOUR, -N, GETUTCDATE())

- Aggregations MUST include GROUP BY for all non-aggregated columns:
  SELECT Category, COUNT(*) AS Total FROM dbo.Products GROUP BY Category

- NULL handling: ISNULL(Col, 'default') or COALESCE(Col1, Col2, 'default')
- String concat: CONCAT(FirstName, ' ', LastName)
- Count distinct: COUNT(DISTINCT CustomerId)

QUERY BEST PRACTICES:
- Always add ORDER BY for meaningful result ordering.
- Use TOP 50 as default limit when the user does not specify a count.
- Use meaningful column aliases (e.g., AS TotalOrders, AS AverageRevenue).
- Use proper JOIN syntax (INNER JOIN, LEFT JOIN) with ON — never comma-separated joins.
- If the user question is ambiguous, make a reasonable assumption and explain it.

RESPONSE FORMAT:
Respond with valid JSON only. No markdown. No code fences. Exactly this structure:
{
  ""sql"": ""YOUR T-SQL QUERY HERE"",
  ""explanation"": ""Brief explanation of what the query does and any assumptions made"",
  ""isReadOnly"": true,
  ""chartType"": ""table""
}

CHART TYPE — pick the best visualization:
- ""table"" — detail/list queries with many columns (default)
- ""bar"" — comparing categories with numeric values (3-20 categories)
- ""horizontalBar"" — bar chart with long category labels
- ""pie"" — proportions/percentages of a whole (2-8 categories)
- ""doughnut"" — same as pie, for percentage breakdowns
- ""line"" — trends over time (needs a date/time column)

If the request CANNOT be answered with a SELECT:
{
  ""sql"": """",
  ""explanation"": ""Reason why the query cannot be generated"",
  ""isReadOnly"": false,
  ""chartType"": ""table""
}

DATABASE SCHEMA:
";

    /// <summary>
    /// Template for the retry prompt sent to the LLM when a generated query fails.
    /// {0} = error message, {1} = failed SQL query.
    /// </summary>
    private const string RetryPromptTemplate = @"
The SQL query you generated failed with the following error when executed against the database:

ERROR: {0}

FAILED QUERY:
{1}

Please analyze the error carefully and generate a CORRECTED T-SQL query. Common fixes:
- Check that column names match the schema exactly (the name must exist in the schema I gave you)
- Use proper T-SQL syntax (TOP not LIMIT, DATEADD not DATE_SUB, GETUTCDATE() not NOW())
- Ensure GROUP BY includes all non-aggregated columns in SELECT
- Use correct JOIN conditions with ON clause
- Check data types match (don't compare string to int without CAST/CONVERT)
- Use square brackets for column names with spaces: [Column Name]

Respond with the corrected JSON in the same format.
";

    /// <summary>
    /// Initializes the SQL generator service and creates the Azure OpenAI chat client.
    /// </summary>
    /// <param name="options">Azure OpenAI configuration (endpoint, API key, deployment).</param>
    /// <param name="logger">Logger for diagnostics.</param>
    /// <exception cref="ArgumentNullException">If options or logger are null.</exception>
    /// <exception cref="SqlGenerationException">If the OpenAI client cannot be created.</exception>
    public SqlGeneratorService(
        IOptions<AzureOpenAIOptions> options,
        ILogger<SqlGeneratorService> logger)
    {
        _options = options.Value ?? throw new ArgumentNullException(nameof(options));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        try
        {
            // Create the Azure OpenAI client with API key authentication
            var client = new AzureOpenAIClient(
                new Uri(_options.Endpoint),
                new ApiKeyCredential(_options.ApiKey));

            _chatClient = client.GetChatClient(_options.DeploymentName);

            _logger.LogInformation(
                "SqlGeneratorService initialized — Endpoint: {Endpoint}, Deployment: {Deployment}, " +
                "Temperature: {Temperature}, MaxTokens: {MaxTokens}",
                _options.Endpoint, _options.DeploymentName,
                _options.Temperature, _options.MaxTokens);
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex,
                "Failed to initialize Azure OpenAI client. Endpoint: {Endpoint}, Deployment: {Deployment}",
                _options.Endpoint, _options.DeploymentName);
            throw new SqlGenerationException(
                $"Failed to initialize Azure OpenAI client: {ex.Message}", ex);
        }
    }

    /// <summary>
    /// Generates a SQL query from a natural language question (single attempt, no retry).
    /// </summary>
    /// <param name="naturalLanguageQuery">The user's question in plain English.</param>
    /// <param name="schema">The database schema for context.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>An <see cref="NL2SqlResponse"/> with the generated SQL and metadata.</returns>
    public async Task<NL2SqlResponse> GenerateSqlAsync(
        string naturalLanguageQuery,
        DatabaseSchema schema,
        CancellationToken cancellationToken = default)
    {
        _logger.LogInformation(
            "Generating SQL (single attempt) for query: {Query}", naturalLanguageQuery);

        // Build the system prompt with the full database schema appended
        var systemMessage = SystemPrompt + schema.ToSchemaPrompt();

        var chatOptions = new ChatCompletionOptions
        {
            Temperature = _options.Temperature,
            MaxOutputTokenCount = _options.MaxTokens
        };

        var messages = new List<ChatMessage>
        {
            new SystemChatMessage(systemMessage),
            new UserChatMessage(naturalLanguageQuery)
        };

        var stopwatch = Stopwatch.StartNew();

        try
        {
            var response = await _chatClient.CompleteChatAsync(
                messages, chatOptions, cancellationToken);
            var content = response.Value.Content[0].Text;

            stopwatch.Stop();
            _logger.LogInformation(
                "OpenAI responded in {ElapsedMs}ms (single attempt)",
                stopwatch.ElapsedMilliseconds);
            _logger.LogDebug("OpenAI response content: {Response}", content);

            return ParseResponse(content);
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("SQL generation was cancelled for query: {Query}",
                naturalLanguageQuery);
            throw;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex,
                "Failed to generate SQL after {ElapsedMs}ms. Query: {Query}",
                stopwatch.ElapsedMilliseconds, naturalLanguageQuery);

            return new NL2SqlResponse
            {
                IsSuccess = false,
                ErrorMessage = $"Failed to generate SQL: {ex.Message}"
            };
        }
    }

    /// <summary>
    /// Generates SQL with self-healing retry: if the generated query fails execution,
    /// the error is fed back to the LLM to generate a corrected query. Retries up to
    /// <see cref="MaxRetries"/> times.
    /// </summary>
    /// <param name="naturalLanguageQuery">The user's natural language question.</param>
    /// <param name="schema">The database schema for LLM context.</param>
    /// <param name="queryExecutor">Executor to validate the generated SQL against the real database.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>
    /// A tuple of (SQL response, query result). If the query succeeded on any attempt,
    /// both will be populated. If all attempts fail, the last error is returned.
    /// </returns>
    public async Task<(NL2SqlResponse SqlResponse, QueryResult? QueryResult)> GenerateAndValidateAsync(
        string naturalLanguageQuery,
        DatabaseSchema schema,
        IQueryExecutionService queryExecutor,
        CancellationToken cancellationToken = default)
    {
        _logger.LogInformation(
            "Starting self-healing SQL generation (max {MaxRetries} attempts) for: {Query}",
            MaxRetries, naturalLanguageQuery);

        var overallStopwatch = Stopwatch.StartNew();

        // Build the system prompt with full schema context
        var systemMessage = SystemPrompt + schema.ToSchemaPrompt();

        var chatOptions = new ChatCompletionOptions
        {
            Temperature = _options.Temperature,
            MaxOutputTokenCount = _options.MaxTokens
        };

        // Maintain conversation history so the LLM can learn from previous errors
        var messages = new List<ChatMessage>
        {
            new SystemChatMessage(systemMessage),
            new UserChatMessage(naturalLanguageQuery)
        };

        NL2SqlResponse? lastSqlResponse = null;

        for (int attempt = 1; attempt <= MaxRetries; attempt++)
        {
            var attemptStopwatch = Stopwatch.StartNew();

            try
            {
                _logger.LogInformation(
                    "SQL generation attempt {Attempt}/{Max} for: {Query}",
                    attempt, MaxRetries, naturalLanguageQuery);

                // Call Azure OpenAI to generate SQL
                var response = await _chatClient.CompleteChatAsync(
                    messages, chatOptions, cancellationToken);
                var content = response.Value.Content[0].Text;

                attemptStopwatch.Stop();
                _logger.LogInformation(
                    "OpenAI responded in {ElapsedMs}ms (attempt {Attempt})",
                    attemptStopwatch.ElapsedMilliseconds, attempt);
                _logger.LogDebug(
                    "OpenAI response (attempt {Attempt}): {Response}", attempt, content);

                // Parse the JSON response from the LLM
                lastSqlResponse = ParseResponse(content);

                // Add assistant response to conversation history for context in retries
                messages.Add(new AssistantChatMessage(content));

                // Check if the LLM returned a valid SQL response
                if (!lastSqlResponse.IsSuccess || string.IsNullOrWhiteSpace(lastSqlResponse.GeneratedSql))
                {
                    _logger.LogWarning(
                        "LLM returned no SQL on attempt {Attempt}. Explanation: {Explanation}",
                        attempt, lastSqlResponse.Explanation);
                    return (lastSqlResponse, null);
                }

                // Safety: reject non-read-only queries
                if (!lastSqlResponse.IsReadOnly)
                {
                    _logger.LogWarning(
                        "LLM generated a non-read-only query on attempt {Attempt}. SQL: {Sql}",
                        attempt, lastSqlResponse.GeneratedSql);
                    return (lastSqlResponse, null);
                }

                _logger.LogInformation(
                    "Validating generated SQL by executing against database (attempt {Attempt})...",
                    attempt);

                // Execute the query to validate it works
                var queryResult = await queryExecutor.ExecuteQueryAsync(
                    lastSqlResponse.GeneratedSql, cancellationToken);

                if (queryResult.IsSuccess)
                {
                    overallStopwatch.Stop();

                    if (attempt > 1)
                    {
                        _logger.LogInformation(
                            "Query self-healed on attempt {Attempt}/{Max} after {TotalMs}ms total",
                            attempt, MaxRetries, overallStopwatch.ElapsedMilliseconds);
                    }
                    else
                    {
                        _logger.LogInformation(
                            "Query succeeded on first attempt in {TotalMs}ms total",
                            overallStopwatch.ElapsedMilliseconds);
                    }

                    return (lastSqlResponse, queryResult);
                }

                // Query failed — ask LLM to fix it on the next iteration
                if (attempt < MaxRetries)
                {
                    var retryPrompt = string.Format(RetryPromptTemplate,
                        queryResult.ErrorMessage, lastSqlResponse.GeneratedSql);

                    _logger.LogWarning(
                        "Query failed on attempt {Attempt}/{Max}: {Error}. " +
                        "Feeding error back to LLM for self-correction...",
                        attempt, MaxRetries, queryResult.ErrorMessage);

                    messages.Add(new UserChatMessage(retryPrompt));
                }
                else
                {
                    overallStopwatch.Stop();
                    _logger.LogError(
                        "All {Max} SQL generation attempts exhausted after {TotalMs}ms. " +
                        "Last error: {Error}. Last SQL: {Sql}",
                        MaxRetries, overallStopwatch.ElapsedMilliseconds,
                        queryResult.ErrorMessage, lastSqlResponse.GeneratedSql);

                    return (lastSqlResponse, queryResult);
                }
            }
            catch (OperationCanceledException)
            {
                _logger.LogWarning(
                    "SQL generation cancelled on attempt {Attempt}/{Max}",
                    attempt, MaxRetries);
                throw;
            }
            catch (Exception ex)
            {
                attemptStopwatch.Stop();
                _logger.LogError(ex,
                    "Exception on attempt {Attempt}/{Max} after {ElapsedMs}ms: {Error}",
                    attempt, MaxRetries, attemptStopwatch.ElapsedMilliseconds, ex.Message);

                if (attempt == MaxRetries)
                {
                    overallStopwatch.Stop();
                    return (new NL2SqlResponse
                    {
                        IsSuccess = false,
                        ErrorMessage = $"Failed after {MaxRetries} attempts: {ex.Message}"
                    }, null);
                }
            }
        }

        // Fallback — shouldn't normally reach here
        overallStopwatch.Stop();
        _logger.LogError(
            "Self-healing loop exited unexpectedly after {TotalMs}ms",
            overallStopwatch.ElapsedMilliseconds);

        return (lastSqlResponse ?? new NL2SqlResponse
        {
            IsSuccess = false,
            ErrorMessage = "Failed to generate a valid SQL query."
        }, null);
    }

    /// <summary>
    /// Parses the JSON response from the LLM into an <see cref="NL2SqlResponse"/>.
    /// Handles optional markdown code fences that the LLM may include despite instructions.
    /// Also validates the generated SQL is read-only before returning.
    /// </summary>
    /// <param name="content">Raw text response from the LLM.</param>
    /// <returns>Parsed <see cref="NL2SqlResponse"/>.</returns>
    private NL2SqlResponse ParseResponse(string content)
    {
        try
        {
            // Strip markdown code fences if the LLM wrapped the JSON in `json ... `
            content = content.Trim();
            if (content.StartsWith("`"+ ""))
            {
                var firstNewline = content.IndexOf('\n');
                content = content[(firstNewline + 1)..];
                var lastFence = content.LastIndexOf("`" + "");
                if (lastFence >= 0) content = content[..lastFence];
                content = content.Trim();
            }

            var jsonDoc = JsonDocument.Parse(content);
            var root = jsonDoc.RootElement;

            // Extract required fields
            var sql = root.GetProperty("sql").GetString() ?? "";
            var explanation = root.GetProperty("explanation").GetString() ?? "";
            var isReadOnly = root.TryGetProperty("isReadOnly", out var readOnlyProp)
                && readOnlyProp.GetBoolean();

            // Parse the suggested chart type (defaults to Table)
            var chartType = ChartType.Table;
            if (root.TryGetProperty("chartType", out var chartProp))
            {
                var chartStr = chartProp.GetString() ?? "table";
                chartType = chartStr.ToLowerInvariant() switch
                {
                    "bar" => ChartType.Bar,
                    "pie" => ChartType.Pie,
                    "line" => ChartType.Line,
                    "doughnut" => ChartType.Doughnut,
                    "horizontalbar" or "horizontalBar" => ChartType.HorizontalBar,
                    _ => ChartType.Table
                };
            }

            // Final safety validation: ensure the SQL doesn't contain dangerous keywords
            if (!string.IsNullOrWhiteSpace(sql) && !ValidateReadOnly(sql))
            {
                _logger.LogWarning(
                    "Generated SQL failed read-only validation. SQL: {Sql}", sql);

                return new NL2SqlResponse
                {
                    IsSuccess = false,
                    ErrorMessage = "The generated query contains data-modifying statements and was rejected for safety.",
                    IsReadOnly = false
                };
            }

            _logger.LogDebug(
                "Parsed LLM response — SQL length: {SqlLength}, Chart: {ChartType}, ReadOnly: {ReadOnly}",
                sql.Length, chartType, isReadOnly);

            return new NL2SqlResponse
            {
                IsSuccess = !string.IsNullOrWhiteSpace(sql),
                GeneratedSql = sql,
                Explanation = explanation,
                IsReadOnly = isReadOnly,
                SuggestedChart = chartType,
                ErrorMessage = string.IsNullOrWhiteSpace(sql) ? explanation : null
            };
        }
        catch (JsonException ex)
        {
            _logger.LogWarning(ex,
                "Failed to parse OpenAI response as JSON. Content (first 500 chars): {Content}",
                content.Length > 500 ? content[..500] : content);

            return new NL2SqlResponse
            {
                IsSuccess = false,
                ErrorMessage = "Failed to parse AI response. Please try rephrasing your question."
            };
        }
    }

    /// <summary>
    /// Validates that a SQL query is read-only by checking:
    /// 1. It starts with SELECT or WITH (CTE)
    /// 2. It does not contain any dangerous DML/DDL keywords
    /// This is a defense-in-depth check — the LLM is also instructed to only generate SELECTs.
    /// </summary>
    /// <param name="sql">The SQL query to validate.</param>
    /// <returns><c>true</c> if the query appears to be read-only.</returns>
    private static bool ValidateReadOnly(string sql)
    {
        var normalized = sql.Trim().ToUpperInvariant();

        // Comprehensive list of dangerous SQL keywords/prefixes
        var dangerousKeywords = new[]
        {
            "INSERT ", "UPDATE ", "DELETE ", "DROP ", "ALTER ", "CREATE ",
            "TRUNCATE ", "EXEC ", "EXECUTE ", "MERGE ", "GRANT ", "REVOKE ",
            "DENY ", "BACKUP ", "RESTORE ", "DBCC ", "BULK ", "OPENROWSET",
            "OPENDATASOURCE", "xp_", "sp_"
        };

        // Must start with SELECT or WITH (for CTEs)
        if (!normalized.StartsWith("SELECT") && !normalized.StartsWith("WITH"))
        {
            return false;
        }

        // Check for any dangerous keywords anywhere in the query
        return !dangerousKeywords.Any(keyword => normalized.Contains(keyword));
    }
}
