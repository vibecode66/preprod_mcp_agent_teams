// ============================================================================
// SchemaDiscoveryService.cs — Database schema discovery with caching
//
// Purpose:
//   Reads table/column/key metadata from INFORMATION_SCHEMA views in Azure SQL.
//   Also fetches sample rows (TOP 3 per table) so the LLM has real data context
//   for generating accurate WHERE clauses and understanding column values.
//
// Caching:
//   Schema is cached in IMemoryCache with a configurable TTL (default 60 min).
//   Call RefreshSchemaAsync() to force a cache refresh.
//
// Dependencies:
//   - ISqlConnectionFactory for database connections (supports MI)
//   - IMemoryCache for in-memory schema caching
// ============================================================================

using System.Diagnostics;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SqlCopilot.Core.Exceptions;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services;

/// <summary>
/// Discovers Azure SQL Database schema using INFORMATION_SCHEMA views.
/// Caches results in memory with configurable expiration to avoid repeated
/// round-trips to the database.
/// </summary>
public class SchemaDiscoveryService : ISchemaDiscoveryService
{
    /// <summary>Cache key for the discovered database schema.</summary>
    private const string CacheKey = "DatabaseSchema";

    private readonly AzureSqlOptions _options;
    private readonly IMemoryCache _cache;
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<SchemaDiscoveryService> _logger;

    /// <summary>
    /// Initializes the schema discovery service.
    /// </summary>
    /// <param name="options">Azure SQL configuration options.</param>
    /// <param name="cache">In-memory cache for schema data.</param>
    /// <param name="connectionFactory">Factory for creating SQL connections.</param>
    /// <param name="logger">Logger for diagnostics and tracing.</param>
    public SchemaDiscoveryService(
        IOptions<AzureSqlOptions> options,
        IMemoryCache cache,
        ISqlConnectionFactory connectionFactory,
        ILogger<SchemaDiscoveryService> logger)
    {
        _options = options.Value ?? throw new ArgumentNullException(nameof(options));
        _cache = cache ?? throw new ArgumentNullException(nameof(cache));
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Gets the database schema, returning a cached copy if available.
    /// Otherwise discovers the schema from the database and caches it.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The discovered <see cref="DatabaseSchema"/>.</returns>
    /// <exception cref="SchemaDiscoveryException">Thrown when schema discovery fails.</exception>
    public async Task<DatabaseSchema> GetSchemaAsync(CancellationToken cancellationToken = default)
    {
        // Return cached schema if available
        if (_cache.TryGetValue(CacheKey, out DatabaseSchema? cached) && cached is not null)
        {
            _logger.LogDebug("Returning cached database schema ({TableCount} tables)",
                cached.Tables.Count);
            return cached;
        }

        _logger.LogInformation("Schema cache miss — discovering schema from database");

        try
        {
            var schema = await DiscoverSchemaAsync(cancellationToken);

            // Cache with sliding expiration based on configuration
            _cache.Set(CacheKey, schema, TimeSpan.FromMinutes(_options.SchemaCacheMinutes));
            _logger.LogInformation(
                "Schema cached for {CacheMinutes} minutes",
                _options.SchemaCacheMinutes);

            return schema;
        }
        catch (ConnectionFactoryException)
        {
            // Connection errors are already logged in the factory — rethrow as schema error
            throw;
        }
        catch (Exception ex) when (ex is not SchemaDiscoveryException)
        {
            _logger.LogError(ex, "Failed to discover database schema");
            throw new SchemaDiscoveryException(
                $"Failed to discover database schema: {ex.Message}", ex);
        }
    }

    /// <summary>
    /// Forces a refresh of the cached schema by clearing the cache entry
    /// and re-discovering the schema from the database.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token.</param>
    public async Task RefreshSchemaAsync(CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Refreshing database schema cache...");
        _cache.Remove(CacheKey);
        await GetSchemaAsync(cancellationToken);
        _logger.LogInformation("Database schema cache refreshed successfully");
    }

    /// <summary>
    /// Core schema discovery logic — reads tables, columns, PKs, FKs, and sample data
    /// from the database using INFORMATION_SCHEMA and sys views.
    /// </summary>
    private async Task<DatabaseSchema> DiscoverSchemaAsync(CancellationToken cancellationToken)
    {
        var stopwatch = Stopwatch.StartNew();
        _logger.LogInformation("Beginning database schema discovery...");

        var schema = new DatabaseSchema();

        await using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);

        schema.DatabaseName = connection.Database;
        _logger.LogInformation("Connected to database: {DatabaseName}", schema.DatabaseName);

        // Step 1: Discover all tables in the target schema
        var tables = await GetTablesAsync(connection, cancellationToken);
        _logger.LogInformation("Found {TableCount} tables in database", tables.Count);

        // Step 2: For each table, discover columns, keys, and sample data
        foreach (var table in tables)
        {
            _logger.LogDebug("Discovering schema for table {TableName}...", table.FullName);

            try
            {
                // Read column definitions from INFORMATION_SCHEMA.COLUMNS
                table.Columns = await GetColumnsAsync(
                    connection, table.SchemaName, table.TableName, cancellationToken);

                // Read primary key constraints
                table.PrimaryKeys = await GetPrimaryKeysAsync(
                    connection, table.SchemaName, table.TableName, cancellationToken);

                // Read foreign key relationships
                table.ForeignKeys = await GetForeignKeysAsync(
                    connection, table.SchemaName, table.TableName, cancellationToken);

                // Mark PK/FK flags on individual columns for easy access
                foreach (var col in table.Columns)
                {
                    col.IsPrimaryKey = table.PrimaryKeys.Contains(col.ColumnName);
                    col.IsForeignKey = table.ForeignKeys.Any(fk => fk.ColumnName == col.ColumnName);
                }

                // Fetch sample rows so the LLM understands actual data values
                // This is best-effort — failure here won't block schema discovery
                table.SampleRows = await GetSampleRowsAsync(connection, table, cancellationToken);

                _logger.LogDebug(
                    "Table {TableName}: {ColCount} columns, {PkCount} PKs, {FkCount} FKs, {SampleCount} sample rows",
                    table.FullName, table.Columns.Count, table.PrimaryKeys.Count,
                    table.ForeignKeys.Count, table.SampleRows.Count);
            }
            catch (Exception ex)
            {
                // Log but continue — one bad table shouldn't block discovery of the rest
                _logger.LogWarning(ex,
                    "Error discovering schema for table {TableName}, skipping. Error: {Error}",
                    table.FullName, ex.Message);
            }
        }

        schema.Tables = tables;
        stopwatch.Stop();

        _logger.LogInformation(
            "Schema discovery completed in {ElapsedMs}ms — " +
            "{TableCount} tables, {TotalColumns} total columns in database {Database}",
            stopwatch.ElapsedMilliseconds,
            tables.Count,
            tables.Sum(t => t.Columns.Count),
            schema.DatabaseName);

        return schema;
    }

    /// <summary>
    /// Queries INFORMATION_SCHEMA.TABLES to get all base tables.
    /// Filtered to the 'dbo' schema and specific tables for this application.
    /// </summary>
    private static async Task<List<TableSchema>> GetTablesAsync(
        SqlConnection connection, CancellationToken cancellationToken)
    {
        var tables = new List<TableSchema>();

        // Only discover specific tables relevant to this application
        // Modify this filter to include additional tables as needed
        const string sql = @"
            SELECT TABLE_SCHEMA, TABLE_NAME
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA = 'dbo'
            AND TABLE_NAME IN ('Cases','CaseDocument','CaseField')
            ORDER BY TABLE_SCHEMA, TABLE_NAME";

        await using var cmd = new SqlCommand(sql, connection);
        await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);

        while (await reader.ReadAsync(cancellationToken))
        {
            tables.Add(new TableSchema
            {
                SchemaName = reader.GetString(0),
                TableName = reader.GetString(1)
            });
        }

        return tables;
    }

    /// <summary>
    /// Reads column metadata (name, type, length, nullability, defaults) for a table
    /// from INFORMATION_SCHEMA.COLUMNS, ordered by ordinal position.
    /// </summary>
    private static async Task<List<ColumnSchema>> GetColumnsAsync(
        SqlConnection connection, string schemaName, string tableName,
        CancellationToken cancellationToken)
    {
        var columns = new List<ColumnSchema>();

        const string sql = @"
            SELECT
                COLUMN_NAME,
                DATA_TYPE,
                CHARACTER_MAXIMUM_LENGTH,
                IS_NULLABLE,
                COLUMN_DEFAULT
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = @Schema AND TABLE_NAME = @Table
            ORDER BY ORDINAL_POSITION";

        await using var cmd = new SqlCommand(sql, connection);
        cmd.Parameters.AddWithValue("@Schema", schemaName);
        cmd.Parameters.AddWithValue("@Table", tableName);

        await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);

        while (await reader.ReadAsync(cancellationToken))
        {
            columns.Add(new ColumnSchema
            {
                ColumnName = reader.GetString(0),
                DataType = reader.GetString(1),
                MaxLength = reader.IsDBNull(2) ? null : (int?)reader.GetInt32(2),
                IsNullable = reader.GetString(3) == "YES",
                DefaultValue = reader.IsDBNull(4) ? null : reader.GetString(4)
            });
        }

        return columns;
    }

    /// <summary>
    /// Reads primary key column names for a table using INFORMATION_SCHEMA constraint views.
    /// </summary>
    private static async Task<List<string>> GetPrimaryKeysAsync(
        SqlConnection connection, string schemaName, string tableName,
        CancellationToken cancellationToken)
    {
        var keys = new List<string>();

        const string sql = @"
            SELECT ccu.COLUMN_NAME
            FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
            JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu
                ON tc.CONSTRAINT_NAME = ccu.CONSTRAINT_NAME
            WHERE tc.TABLE_SCHEMA = @Schema
              AND tc.TABLE_NAME = @Table
              AND tc.CONSTRAINT_TYPE = 'PRIMARY KEY'";

        await using var cmd = new SqlCommand(sql, connection);
        cmd.Parameters.AddWithValue("@Schema", schemaName);
        cmd.Parameters.AddWithValue("@Table", tableName);

        await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);

        while (await reader.ReadAsync(cancellationToken))
        {
            keys.Add(reader.GetString(0));
        }

        return keys;
    }

    /// <summary>
    /// Reads foreign key relationships for a table using sys.foreign_keys
    /// and sys.foreign_key_columns system views. Returns the FK column,
    /// referenced table, and referenced column.
    /// </summary>
    private static async Task<List<ForeignKeyInfo>> GetForeignKeysAsync(
        SqlConnection connection, string schemaName, string tableName,
        CancellationToken cancellationToken)
    {
        var foreignKeys = new List<ForeignKeyInfo>();

        const string sql = @"
            SELECT
                fk.name AS ConstraintName,
                COL_NAME(fkc.parent_object_id, fkc.parent_column_id) AS ColumnName,
                OBJECT_SCHEMA_NAME(fkc.referenced_object_id) + '.' +
                    OBJECT_NAME(fkc.referenced_object_id) AS ReferencedTable,
                COL_NAME(fkc.referenced_object_id, fkc.referenced_column_id) AS ReferencedColumn
            FROM sys.foreign_keys fk
            JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
            WHERE OBJECT_SCHEMA_NAME(fk.parent_object_id) = @Schema
              AND OBJECT_NAME(fk.parent_object_id) = @Table";

        await using var cmd = new SqlCommand(sql, connection);
        cmd.Parameters.AddWithValue("@Schema", schemaName);
        cmd.Parameters.AddWithValue("@Table", tableName);

        await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);

        while (await reader.ReadAsync(cancellationToken))
        {
            foreignKeys.Add(new ForeignKeyInfo
            {
                ConstraintName = reader.GetString(0),
                ColumnName = reader.GetString(1),
                ReferencedTable = reader.GetString(2),
                ReferencedColumn = reader.GetString(3)
            });
        }

        return foreignKeys;
    }

    /// <summary>
    /// Fetches up to 3 sample rows from a table so the LLM knows actual data values.
    /// Uses TOP 3 with NOLOCK hint for minimal performance impact.
    /// This is a best-effort operation — any errors are caught and logged,
    /// and an empty list is returned instead of propagating the exception.
    /// </summary>
    /// <param name="connection">Open SQL connection.</param>
    /// <param name="table">Table schema to sample from.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>List of sample rows (each row is a dictionary of column→value).</returns>
    private async Task<List<Dictionary<string, string>>> GetSampleRowsAsync(
        SqlConnection connection, TableSchema table, CancellationToken cancellationToken)
    {
        var rows = new List<Dictionary<string, string>>();

        try
        {
            // Select only non-binary, non-image columns to keep sample data compact
            var selectColumns = table.Columns
                .Where(c => !IsBinaryType(c.DataType))
                .Take(10) // Limit columns to keep the LLM prompt concise
                .Select(c => $"[{c.ColumnName}]")
                .ToList();

            if (selectColumns.Count == 0)
            {
                _logger.LogDebug("Table {TableName} has no text-representable columns, skipping sample data",
                    table.FullName);
                return rows;
            }

            // NOLOCK hint allows reading without acquiring shared locks — minimal impact on production
            var sql = $"SELECT TOP 3 {string.Join(", ", selectColumns)} FROM [{table.SchemaName}].[{table.TableName}] WITH (NOLOCK)";

            await using var cmd = new SqlCommand(sql, connection)
            {
                CommandTimeout = 10 // Short timeout — sample data is optional
            };
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);

            while (await reader.ReadAsync(cancellationToken))
            {
                var row = new Dictionary<string, string>();
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    var val = reader.IsDBNull(i) ? "NULL" : reader.GetValue(i)?.ToString() ?? "NULL";
                    // Truncate long values to keep prompt compact
                    if (val.Length > 50) val = val[..50] + "...";
                    row[reader.GetName(i)] = val;
                }
                rows.Add(row);
            }

            _logger.LogDebug("Fetched {RowCount} sample rows from {TableName}",
                rows.Count, table.FullName);
        }
        catch (Exception ex)
        {
            // Sample data is best-effort; don't fail schema discovery if this errors
            _logger.LogWarning(ex,
                "Failed to fetch sample rows from {TableName}: {Error}. Continuing without sample data.",
                table.FullName, ex.Message);
        }

        return rows;
    }

    /// <summary>
    /// Determines whether a SQL data type represents binary data that
    /// shouldn't be included in text-based sample output.
    /// </summary>
    /// <param name="dataType">The SQL data type name (e.g., "varbinary", "image").</param>
    /// <returns><c>true</c> if the type is binary.</returns>
    private static bool IsBinaryType(string dataType)
    {
        var dt = dataType.ToLowerInvariant();
        return dt is "binary" or "varbinary" or "image" or "timestamp" or "rowversion";
    }
}
