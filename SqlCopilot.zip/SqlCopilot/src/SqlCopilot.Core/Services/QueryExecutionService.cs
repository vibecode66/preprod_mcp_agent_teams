// ============================================================================
// QueryExecutionService.cs — Safe SQL query execution against Azure SQL
//
// Purpose:
//   Executes LLM-generated SQL queries against Azure SQL Database with
//   multiple safety guardrails:
//     - Only SELECT / WITH (CTE) statements are allowed
//     - Queries run inside READ UNCOMMITTED transactions for isolation
//     - Configurable timeout prevents long-running queries
//     - Configurable row limit prevents memory issues from large result sets
//     - All values are converted to serializable types for Adaptive Card rendering
//
// Dependencies:
//   - ISqlConnectionFactory for Managed Identity connections
//   - AzureSqlOptions for timeout/row-limit configuration
// ============================================================================

using System.Diagnostics;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SqlCopilot.Core.Exceptions;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services;

/// <summary>
/// Executes SQL queries against Azure SQL Database with safety guardrails.
/// Enforces read-only access, query timeouts, and row limits to protect
/// both the database and the application from runaway queries.
/// </summary>
public class QueryExecutionService : IQueryExecutionService
{
    private readonly AzureSqlOptions _options;
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<QueryExecutionService> _logger;

    /// <summary>
    /// Initializes the query execution service.
    /// </summary>
    /// <param name="options">Azure SQL configuration (timeout, row limit).</param>
    /// <param name="connectionFactory">Factory for creating database connections.</param>
    /// <param name="logger">Logger for diagnostics.</param>
    public QueryExecutionService(
        IOptions<AzureSqlOptions> options,
        ISqlConnectionFactory connectionFactory,
        ILogger<QueryExecutionService> logger)
    {
        _options = options.Value ?? throw new ArgumentNullException(nameof(options));
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Executes a SQL query and returns the results as a <see cref="QueryResult"/>.
    /// The query must be a SELECT statement (or CTE with SELECT). Any data-modifying
    /// statements are rejected before execution.
    /// </summary>
    /// <param name="sqlQuery">The SQL query to execute.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>
    /// A <see cref="QueryResult"/> with column metadata, row data, timing, and status.
    /// If execution fails, <see cref="QueryResult.IsSuccess"/> is <c>false</c>
    /// and <see cref="QueryResult.ErrorMessage"/> describes the problem.
    /// </returns>
    public async Task<QueryResult> ExecuteQueryAsync(
        string sqlQuery, CancellationToken cancellationToken = default)
    {
        var result = new QueryResult { SqlQuery = sqlQuery };

        // ---- Safety check: reject anything that isn't a SELECT / WITH ----
        var normalized = sqlQuery.Trim().ToUpperInvariant();
        if (!normalized.StartsWith("SELECT") && !normalized.StartsWith("WITH"))
        {
            _logger.LogWarning(
                "Rejected non-SELECT query. First 100 chars: {QueryStart}",
                sqlQuery.Length > 100 ? sqlQuery[..100] : sqlQuery);

            result.IsSuccess = false;
            result.ErrorMessage = "Only SELECT queries are allowed.";
            return result;
        }

        _logger.LogInformation(
            "Executing SQL query (timeout: {Timeout}s, maxRows: {MaxRows}). Query: {Query}",
            _options.QueryTimeoutSeconds, _options.MaxRowsReturned, sqlQuery);

        var stopwatch = Stopwatch.StartNew();

        try
        {
            await using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);

            // Wrap in READ UNCOMMITTED transaction for extra safety.
            // This prevents any accidental writes and uses dirty reads
            // for better performance on read-only queries.
            await using var transaction = connection.BeginTransaction(
                System.Data.IsolationLevel.ReadUncommitted);

            await using var cmd = new SqlCommand(sqlQuery, connection, transaction)
            {
                CommandTimeout = _options.QueryTimeoutSeconds
            };

            _logger.LogDebug("Executing SQL command against {Database}...", connection.Database);

            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);

            // ---- Read column metadata ----
            for (int i = 0; i < reader.FieldCount; i++)
            {
                result.Columns.Add(new QueryColumn
                {
                    Name = reader.GetName(i),
                    DataType = reader.GetDataTypeName(i)
                });
            }

            _logger.LogDebug("Query returned {ColumnCount} columns: [{Columns}]",
                result.Columns.Count,
                string.Join(", ", result.Columns.Select(c => $"{c.Name}({c.DataType})")));

            // ---- Read rows up to the configured limit ----
            int rowCount = 0;
            while (await reader.ReadAsync(cancellationToken))
            {
                rowCount++;

                // Once we exceed the limit, keep counting total rows but stop storing data
                if (rowCount > _options.MaxRowsReturned)
                {
                    result.IsTruncated = true;
                    continue;
                }

                var row = new Dictionary<string, object?>();
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    var value = reader.IsDBNull(i) ? null : reader.GetValue(i);

                    // Convert values to types that serialize cleanly to JSON/Adaptive Cards
                    row[reader.GetName(i)] = value switch
                    {
                        DateTime dt => dt.ToString("yyyy-MM-dd HH:mm:ss"),
                        DateTimeOffset dto => dto.ToString("yyyy-MM-dd HH:mm:ss zzz"),
                        decimal d => d,       // Keep decimal precision for formatting
                        byte[] bytes => $"[Binary: {bytes.Length} bytes]",
                        _ => value
                    };
                }
                result.Rows.Add(row);
            }

            result.TotalRowCount = rowCount;
            result.IsSuccess = true;

            stopwatch.Stop();
            result.ExecutionTime = stopwatch.Elapsed;

            _logger.LogInformation(
                "Query executed successfully. Rows returned: {RowCount} " +
                "(showing: {DisplayedRows}), Columns: {ColCount}, " +
                "Truncated: {Truncated}, Time: {ElapsedMs}ms",
                rowCount, result.Rows.Count, result.Columns.Count,
                result.IsTruncated, stopwatch.ElapsedMilliseconds);
        }
        catch (OperationCanceledException)
        {
            stopwatch.Stop();
            result.ExecutionTime = stopwatch.Elapsed;
            result.IsSuccess = false;
            result.ErrorMessage = "Query execution was cancelled.";

            _logger.LogWarning("Query execution cancelled after {ElapsedMs}ms",
                stopwatch.ElapsedMilliseconds);
        }
        catch (SqlException ex) when (ex.Number == -2) // Timeout
        {
            stopwatch.Stop();
            result.ExecutionTime = stopwatch.Elapsed;
            result.IsSuccess = false;
            result.ErrorMessage = $"Query timed out after {_options.QueryTimeoutSeconds} seconds. Try narrowing your query with WHERE clauses or TOP.";

            _logger.LogWarning(
                "SQL query timed out after {ElapsedMs}ms (limit: {TimeoutSeconds}s). Query: {Query}",
                stopwatch.ElapsedMilliseconds, _options.QueryTimeoutSeconds, sqlQuery);
        }
        catch (SqlException ex)
        {
            stopwatch.Stop();
            result.ExecutionTime = stopwatch.Elapsed;
            result.IsSuccess = false;
            result.ErrorMessage = $"SQL Error #{ex.Number}: {ex.Message}";

            _logger.LogError(ex,
                "SQL execution error #{ErrorNumber} after {ElapsedMs}ms. " +
                "State: {State}, Class: {Class}. Query: {Query}",
                ex.Number, stopwatch.ElapsedMilliseconds,
                ex.State, ex.Class, sqlQuery);
        }
        catch (ConnectionFactoryException ex)
        {
            // Connection creation failed — already logged in the factory
            stopwatch.Stop();
            result.ExecutionTime = stopwatch.Elapsed;
            result.IsSuccess = false;
            result.ErrorMessage = $"Database connection failed: {ex.Message}";

            _logger.LogError(ex,
                "Connection factory error during query execution: {Error}", ex.Message);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            result.ExecutionTime = stopwatch.Elapsed;
            result.IsSuccess = false;
            result.ErrorMessage = $"Unexpected error: {ex.Message}";

            _logger.LogError(ex,
                "Unexpected error during query execution after {ElapsedMs}ms: {Error}. Query: {Query}",
                stopwatch.ElapsedMilliseconds, ex.Message, sqlQuery);
        }

        return result;
    }
}
