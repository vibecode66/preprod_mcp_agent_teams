// ============================================================================
// AdaptiveCardService.cs — Rich Adaptive Card rendering for Teams / M365 Copilot
//
// Purpose:
//   Builds Adaptive Card JSON payloads from SQL query results for display
//   in Microsoft Teams and M365 Copilot. Supports multiple card layouts:
//     - Table card: multi-row, multi-column data grid
//     - KPI card: bold big-number display for single-value aggregations
//     - Key-Value card: two-column fact-set for simple lookups
//     - Single-Record card: detail view for a single row
//     - Chart card: chart image + data table toggle
//     - Error card: user-friendly error display
//     - Welcome card: onboarding help
//     - Summary card: fallback when results are too large
//
// Size management:
//   Teams messages have a 28KB size limit. This service enforces a 25KB
//   safety threshold, trimming rows/columns and falling back to summary
//   cards when results are too large.
//
// Dependencies:
//   - IChartService for chart image URLs
//   - Newtonsoft.Json for Bot Framework SDK compatibility
// ============================================================================

using System.Text.Json;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using SqlCopilot.Core.Exceptions;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services;

/// <summary>
/// Builds rich Adaptive Cards from query results for display in Teams / M365 Copilot.
/// Supports table layouts, KPI cards, chart visualizations, key-value pairs,
/// single-record detail views, error cards, and welcome cards.
/// </summary>
public class AdaptiveCardService : IAdaptiveCardService
{
    /// <summary>
    /// Teams message size limit is 28KB; keep card under 25KB for safety margin.
    /// If the rendered card exceeds this, a summary card is returned instead.
    /// </summary>
    private const int MaxCardSizeBytes = 25_000;

    /// <summary>Maximum rows to display in a table card.</summary>
    private const int MaxTableRows = 15;

    /// <summary>Maximum columns to display in a table card.</summary>
    private const int MaxColumnsInTable = 8;

    private readonly ILogger<AdaptiveCardService> _logger;
    private readonly IChartService _chartService;

    /// <summary>
    /// Initializes the Adaptive Card service.
    /// </summary>
    /// <param name="logger">Logger for card rendering diagnostics.</param>
    /// <param name="chartService">Chart service for generating chart image URLs.</param>
    public AdaptiveCardService(ILogger<AdaptiveCardService> logger, IChartService chartService)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _chartService = chartService ?? throw new ArgumentNullException(nameof(chartService));
    }

    /// <summary>
    /// Creates the appropriate Adaptive Card for a query result.
    /// Automatically selects the best card type (table, KPI, chart, key-value, etc.)
    /// based on the result shape and LLM's chart suggestion.
    /// </summary>
    /// <param name="result">The SQL query execution result.</param>
    /// <param name="sqlResponse">The LLM response with explanation and chart suggestion.</param>
    /// <returns>A Bot Framework <see cref="Attachment"/> containing the Adaptive Card.</returns>
    public Attachment CreateResultCard(QueryResult result, NL2SqlResponse sqlResponse)
    {
        _logger.LogInformation(
            "Creating result card — ResultType: {ResultType}, Rows: {Rows}, " +
            "Columns: {Columns}, SuggestedChart: {Chart}",
            result.ResultType, result.Rows.Count,
            result.Columns.Count, sqlResponse.SuggestedChart);

        try
        {
            // Handle error and empty result states first
            if (!result.IsSuccess)
                return CreateErrorCard(result.ErrorMessage ?? "Unknown error");

            if (result.ResultType == QueryResultType.Empty)
                return CreateEmptyResultCard(sqlResponse);

            // Trim result to fit Teams message limits before rendering any card
            var trimmedResult = TrimForTeams(result);

            // Try chart visualization first if the LLM suggested one
            if (sqlResponse.SuggestedChart != ChartType.Table
                && _chartService.CanRenderChart(trimmedResult, sqlResponse.SuggestedChart))
            {
                var chartUrl = _chartService.GenerateChartUrl(trimmedResult, sqlResponse.SuggestedChart);
                if (chartUrl != null)
                {
                    _logger.LogInformation("Rendering {ChartType} chart card", sqlResponse.SuggestedChart);
                    return CreateChartCard(trimmedResult, sqlResponse, chartUrl);
                }

                _logger.LogWarning(
                    "Chart generation failed for {ChartType}, falling back to table/detail view",
                    sqlResponse.SuggestedChart);
            }

            // Select the best card type based on result shape
            var card = trimmedResult.ResultType switch
            {
                QueryResultType.Kpi => CreateKpiCard(trimmedResult, sqlResponse),
                QueryResultType.SingleRecord => CreateSingleRecordCard(trimmedResult, sqlResponse),
                QueryResultType.KeyValue => CreateKeyValueCard(trimmedResult, sqlResponse),
                _ => CreateTableCard(trimmedResult, sqlResponse)
            };

            _logger.LogDebug("Created {CardType} card", trimmedResult.ResultType);

            // Final safety check: if card is still too large, create a summary card
            return EnsureCardFitsLimit(card, trimmedResult, sqlResponse);
        }
        catch (Exception ex)
        {
            // Card rendering should never crash the bot — return an error card instead
            _logger.LogError(ex,
                "Exception while creating result card: {Error}", ex.Message);

            try
            {
                return CreateErrorCard("An error occurred while rendering the results. Please try again.");
            }
            catch (Exception innerEx)
            {
                _logger.LogCritical(innerEx,
                    "Failed to create even an error card. Returning minimal attachment.");

                // Last resort: return a minimal text-only card
                return new Attachment
                {
                    ContentType = "application/vnd.microsoft.card.adaptive",
                    Content = JObject.Parse("{\"type\":\"AdaptiveCard\",\"version\":\"1.5\",\"body\":[{\"type\":\"TextBlock\",\"text\":\"Error rendering results.\"}]}")
                };
            }
        }
    }

    /// <summary>
    /// Creates an error card with a warning icon and the error message.
    /// Used for SQL errors, permission issues, and unexpected failures.
    /// </summary>
    /// <param name="errorMessage">The error description to display.</param>
    /// <returns>A Bot Framework <see cref="Attachment"/> with the error card.</returns>
    public Attachment CreateErrorCard(string errorMessage)
    {
        _logger.LogDebug("Creating error card: {ErrorMessage}",
            errorMessage.Length > 200 ? errorMessage[..200] + "..." : errorMessage);

        var card = new
        {
            type = "AdaptiveCard",
            version = "1.5",
            body = new object[]
            {
                new
                {
                    type = "Container",
                    style = "attention",
                    items = new object[]
                    {
                        new
                        {
                            type = "ColumnSet",
                            columns = new object[]
                            {
                                new
                                {
                                    type = "Column",
                                    width = "auto",
                                    items = new object[]
                                    {
                                        new
                                        {
                                            type = "TextBlock",
                                            text = "\u26a0\ufe0f",
                                            size = "Large"
                                        }
                                    }
                                },
                                new
                                {
                                    type = "Column",
                                    width = "stretch",
                                    items = new object[]
                                    {
                                        new
                                        {
                                            type = "TextBlock",
                                            text = "Query Error",
                                            weight = "Bolder",
                                            size = "Medium",
                                            color = "Attention"
                                        },
                                        new
                                        {
                                            type = "TextBlock",
                                            text = errorMessage,
                                            wrap = true,
                                            size = "Small"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        };

        return CreateAttachment(card);
    }

    /// <summary>
    /// Creates a welcome/onboarding card shown when the user first interacts
    /// with the bot or types /help. Includes example questions and a safety notice.
    /// </summary>
    /// <returns>A Bot Framework <see cref="Attachment"/> with the welcome card.</returns>
    public Attachment CreateWelcomeCard()
    {
        _logger.LogDebug("Creating welcome card");

        var card = new
        {
            type = "AdaptiveCard",
            version = "1.5",
            body = new object[]
            {
                new
                {
                    type = "Container",
                    style = "emphasis",
                    items = new object[]
                    {
                        new
                        {
                            type = "TextBlock",
                            text = "\ud83d\uddc4\ufe0f SQL Copilot",
                            weight = "Bolder",
                            size = "Large"
                        },
                        new
                        {
                            type = "TextBlock",
                            text = "I can help you query your database using natural language. Just ask me a question about your data!",
                            wrap = true,
                            spacing = "Small"
                        }
                    }
                },
                new
                {
                    type = "Container",
                    items = new object[]
                    {
                        new
                        {
                            type = "TextBlock",
                            text = "\ud83d\udca1 Example Questions",
                            weight = "Bolder",
                            spacing = "Medium"
                        },
                        new
                        {
                            type = "TextBlock",
                            text = "\u2022 \"Show me the top 10 customers by revenue\"\n\u2022 \"How many orders were placed last month?\"\n\u2022 \"List all products with low stock\"\n\u2022 \"What is the average order value by region?\"",
                            wrap = true,
                            size = "Small",
                            spacing = "Small"
                        }
                    }
                },
                new
                {
                    type = "Container",
                    style = "warning",
                    items = new object[]
                    {
                        new
                        {
                            type = "TextBlock",
                            text = "\ud83d\udd12 Read-only access \u2014 your data is safe. I can only run SELECT queries.",
                            wrap = true,
                            size = "Small",
                            isSubtle = true
                        }
                    }
                }
            }
        };

        return CreateAttachment(card);
    }

    // ========================================================================
    // Private card creation methods
    // ========================================================================

    /// <summary>
    /// Creates a card for queries that returned zero rows.
    /// Shows the explanation and the SQL that was executed.
    /// </summary>
    private Attachment CreateEmptyResultCard(NL2SqlResponse sqlResponse)
    {
        _logger.LogDebug("Creating empty result card for query: {Sql}", sqlResponse.GeneratedSql);

        var card = new
        {
            type = "AdaptiveCard",
            version = "1.5",
            body = new object[]
            {
                CreateHeaderContainer("\ud83d\udccb Query Result", sqlResponse.Explanation),
                new
                {
                    type = "Container",
                    items = new object[]
                    {
                        new
                        {
                            type = "TextBlock",
                            text = "No results found for your query.",
                            wrap = true,
                            isSubtle = true,
                            horizontalAlignment = "Center",
                            spacing = "Large"
                        }
                    }
                },
                CreateSqlContainer(sqlResponse.GeneratedSql)
            }
        };

        return CreateAttachment(card);
    }

    /// <summary>
    /// Creates a detail card for a single-row result with many columns.
    /// Displays each column as a title/value pair using an Adaptive Card FactSet.
    /// </summary>
    private Attachment CreateSingleRecordCard(QueryResult result, NL2SqlResponse sqlResponse)
    {
        _logger.LogDebug("Creating single-record card with {ColCount} columns", result.Columns.Count);

        var row = result.Rows[0];

        // Build fact pairs from each column in the row
        var facts = row.Select(kvp => new
        {
            title = kvp.Key,
            value = FormatValue(kvp.Value)
        }).ToArray();

        var card = new
        {
            type = "AdaptiveCard",
            version = "1.5",
            body = new object[]
            {
                CreateHeaderContainer("\ud83d\udccb Query Result", sqlResponse.Explanation),
                new
                {
                    type = "FactSet",
                    facts = facts,
                    spacing = "Medium"
                },
                CreateMetadataContainer(result),
                CreateSqlContainer(sqlResponse.GeneratedSql)
            }
        };

        return CreateAttachment(card);
    }

    /// <summary>
    /// Creates a key-value card for two-column results with multiple rows.
    /// The first column is the title, the second is the value.
    /// </summary>
    private Attachment CreateKeyValueCard(QueryResult result, NL2SqlResponse sqlResponse)
    {
        _logger.LogDebug("Creating key-value card with {RowCount} rows", result.Rows.Count);

        var facts = result.Rows.Select(row =>
        {
            var values = row.Values.ToList();
            return new
            {
                title = FormatValue(values.ElementAtOrDefault(0)),
                value = FormatValue(values.ElementAtOrDefault(1))
            };
        }).ToArray();

        var card = new
        {
            type = "AdaptiveCard",
            version = "1.5",
            body = new object[]
            {
                CreateHeaderContainer("\ud83d\udcca Query Result", sqlResponse.Explanation),
                new
                {
                    type = "FactSet",
                    facts = facts,
                    spacing = "Medium"
                },
                CreateMetadataContainer(result),
                CreateSqlContainer(sqlResponse.GeneratedSql)
            }
        };

        return CreateAttachment(card);
    }

    /// <summary>
    /// Creates a bold KPI card for single-value or few-metric aggregation results
    /// (e.g., COUNT(*), SUM(Revenue), AVG(Price)).
    ///
    /// Single-value results show one large accent number centered on the card.
    /// Multi-metric results (2-4 numeric columns) show each metric side-by-side
    /// in a column layout with smart number formatting.
    /// </summary>
    private Attachment CreateKpiCard(QueryResult result, NL2SqlResponse sqlResponse)
    {
        _logger.LogDebug("Creating KPI card with {ColCount} metrics", result.Columns.Count);

        var row = result.Rows[0];
        var bodyItems = new List<object>
        {
            CreateHeaderContainer("\ud83d\udcca " + sqlResponse.Explanation, "")
        };

        if (result.Columns.Count == 1)
        {
            // Single big KPI number (e.g., "Total Orders: 1,247")
            var col = result.Columns[0];
            var value = row.GetValueOrDefault(col.Name);

            bodyItems.Add(new
            {
                type = "Container",
                items = new object[]
                {
                    new
                    {
                        type = "TextBlock",
                        text = SmartFormat(value, col.Name),
                        size = "ExtraLarge",
                        weight = "Bolder",
                        horizontalAlignment = "Center",
                        color = "Accent",
                        spacing = "Large"
                    },
                    new
                    {
                        type = "TextBlock",
                        text = FormatColumnLabel(col.Name),
                        size = "Medium",
                        horizontalAlignment = "Center",
                        isSubtle = true,
                        spacing = "None"
                    }
                }
            });
        }
        else
        {
            // Multi-metric KPI: each value gets its own column in a side-by-side layout
            var kpiColumns = result.Columns.Select(col =>
            {
                var value = row.GetValueOrDefault(col.Name);
                return new
                {
                    type = "Column",
                    width = "stretch",
                    items = new object[]
                    {
                        new
                        {
                            type = "TextBlock",
                            text = SmartFormat(value, col.Name),
                            size = "ExtraLarge",
                            weight = "Bolder",
                            horizontalAlignment = "Center",
                            color = "Accent"
                        },
                        new
                        {
                            type = "TextBlock",
                            text = FormatColumnLabel(col.Name),
                            size = "Small",
                            horizontalAlignment = "Center",
                            isSubtle = true,
                            wrap = true,
                            spacing = "None"
                        }
                    }
                };
            }).ToArray();

            bodyItems.Add(new
            {
                type = "ColumnSet",
                columns = kpiColumns,
                spacing = "Large"
            });
        }

        bodyItems.Add(CreateSqlContainer(sqlResponse.GeneratedSql));

        var card = new
        {
            type = "AdaptiveCard",
            version = "1.5",
            body = bodyItems.ToArray()
        };

        return CreateAttachment(card);
    }

    /// <summary>
    /// Creates a multi-row table card using ColumnSet-based layout.
    /// Includes a header row (emphasized), data rows, metadata, and a SQL toggle.
    /// </summary>
    private Attachment CreateTableCard(QueryResult result, NL2SqlResponse sqlResponse)
    {
        _logger.LogDebug("Creating table card — {RowCount} rows x {ColCount} columns",
            result.Rows.Count, result.Columns.Count);

        // Build table header row with bold column names
        var headerColumns = result.Columns.Select(col => new
        {
            type = "Column",
            width = "stretch",
            items = new object[]
            {
                new
                {
                    type = "TextBlock",
                    text = col.Name,
                    weight = "Bolder",
                    size = "Small",
                    wrap = true
                }
            }
        }).ToArray();

        // Build data rows — each row is a ColumnSet with values
        var dataRows = result.Rows.Select(row =>
        {
            var rowColumns = result.Columns.Select(col => new
            {
                type = "Column",
                width = "stretch",
                items = new object[]
                {
                    new
                    {
                        type = "TextBlock",
                        text = FormatValue(row.GetValueOrDefault(col.Name)),
                        size = "Small",
                        wrap = true
                    }
                }
            }).ToArray();

            return new
            {
                type = "ColumnSet",
                columns = rowColumns,
                separator = true,
                spacing = "Small"
            };
        }).ToArray();

        var bodyItems = new List<object>
        {
            CreateHeaderContainer("\ud83d\udcca Query Results", sqlResponse.Explanation),
            // Table header row with emphasis styling
            new
            {
                type = "ColumnSet",
                columns = headerColumns,
                style = "emphasis",
                spacing = "Medium"
            }
        };

        // Add all data rows
        bodyItems.AddRange(dataRows);

        // Add metadata (row count, execution time) and SQL toggle
        bodyItems.Add(CreateMetadataContainer(result));
        bodyItems.Add(CreateSqlContainer(sqlResponse.GeneratedSql));

        var card = new
        {
            type = "AdaptiveCard",
            version = "1.5",
            body = bodyItems.ToArray()
        };

        return CreateAttachment(card);
    }

    // ========================================================================
    // Chart card methods
    // ========================================================================

    /// <summary>
    /// Creates a chart card containing a chart image from QuickChart.io,
    /// plus toggleable sections for the data table and SQL query.
    /// </summary>
    /// <param name="result">The query result data.</param>
    /// <param name="sqlResponse">The LLM response with chart type and explanation.</param>
    /// <param name="chartUrl">The QuickChart.io URL that renders the chart image.</param>
    /// <returns>A Bot Framework <see cref="Attachment"/> with the chart card.</returns>
    private Attachment CreateChartCard(QueryResult result, NL2SqlResponse sqlResponse, string chartUrl)
    {
        // Select the appropriate emoji for the chart type
        var chartLabel = sqlResponse.SuggestedChart switch
        {
            ChartType.Bar => "\ud83d\udcca Bar Chart",
            ChartType.HorizontalBar => "\ud83d\udcca Bar Chart",
            ChartType.Pie => "\ud83e\udd67 Pie Chart",
            ChartType.Doughnut => "\ud83c\udf69 Doughnut Chart",
            ChartType.Line => "\ud83d\udcc8 Line Chart",
            _ => "\ud83d\udcca Chart"
        };

        var card = new
        {
            type = "AdaptiveCard",
            version = "1.5",
            body = new object[]
            {
                CreateHeaderContainer(chartLabel + " \u2014 Results", sqlResponse.Explanation),
                new
                {
                    type = "Image",
                    url = chartUrl,
                    size = "stretch",
                    altText = sqlResponse.SuggestedChart + " chart of query results",
                    spacing = "Medium"
                },
                CreateMetadataContainer(result),
                CreateChartToggleContainer(result, sqlResponse)
            }
        };

        return CreateAttachment(card);
    }

    /// <summary>
    /// Creates toggle sections for chart cards with "Show Data Table" and "Show SQL"
    /// actions. Uses Action.ShowCard to reveal content inline without navigation.
    /// </summary>
    private static object CreateChartToggleContainer(QueryResult result, NL2SqlResponse sqlResponse)
    {
        // Build a compact data table for the ShowCard toggle
        var headerCols = result.Columns.Select(col => new
        {
            type = "Column",
            width = "stretch",
            items = new object[]
            {
                new { type = "TextBlock", text = col.Name, weight = "Bolder", size = "Small", wrap = true }
            }
        }).ToArray();

        // Show up to 20 rows in the toggle data table
        var dataRows = result.Rows.Take(20).Select(row =>
        {
            var rowCols = result.Columns.Select(col => new
            {
                type = "Column",
                width = "stretch",
                items = new object[]
                {
                    new { type = "TextBlock", text = FormatValue(row.GetValueOrDefault(col.Name)), size = "Small", wrap = true }
                }
            }).ToArray();
            return new { type = "ColumnSet", columns = rowCols, separator = true, spacing = "Small" };
        }).ToArray();

        var tableBody = new List<object>
        {
            new { type = "ColumnSet", columns = headerCols, style = "emphasis" }
        };
        tableBody.AddRange(dataRows);

        return new
        {
            type = "Container",
            items = new object[]
            {
                new
                {
                    type = "ActionSet",
                    actions = new object[]
                    {
                        new
                        {
                            type = "Action.ShowCard",
                            title = "\ud83d\udccb Show Data Table",
                            card = new
                            {
                                type = "AdaptiveCard",
                                body = tableBody.ToArray()
                            }
                        },
                        new
                        {
                            type = "Action.ShowCard",
                            title = "\ud83d\udd0d Show SQL",
                            card = new
                            {
                                type = "AdaptiveCard",
                                body = new object[]
                                {
                                    new
                                    {
                                        type = "TextBlock",
                                        text = "`" + "\n" + sqlResponse.GeneratedSql + "\n`" + "",
                                        wrap = true,
                                        fontType = "Monospace",
                                        size = "Small"
                                    }
                                }
                            }
                        }
                    }
                }
            },
            spacing = "Small"
        };
    }

    // ========================================================================
    // Shared helper methods for building card components
    // ========================================================================

    /// <summary>
    /// Creates a header container with a title and subtitle, used at the top
    /// of most card types. Uses emphasis styling and full-width bleed.
    /// </summary>
    /// <param name="title">Bold title text (e.g., "📊 Query Results").</param>
    /// <param name="subtitle">Subtle explanation text below the title.</param>
    /// <returns>An anonymous object representing an Adaptive Card Container.</returns>
    private static object CreateHeaderContainer(string title, string subtitle)
    {
        return new
        {
            type = "Container",
            style = "emphasis",
            items = new object[]
            {
                new
                {
                    type = "TextBlock",
                    text = title,
                    weight = "Bolder",
                    size = "Medium"
                },
                new
                {
                    type = "TextBlock",
                    text = subtitle,
                    wrap = true,
                    size = "Small",
                    isSubtle = true,
                    spacing = "None"
                }
            },
            bleed = true
        };
    }

    /// <summary>
    /// Creates a metadata container showing row count, truncation status,
    /// and query execution time. Displayed right-aligned in subtle text.
    /// </summary>
    /// <param name="result">Query result for metadata extraction.</param>
    /// <returns>An anonymous object representing an Adaptive Card Container.</returns>
    private static object CreateMetadataContainer(QueryResult result)
    {
        var metaText = result.TotalRowCount + " row(s) returned";
        if (result.IsTruncated)
            metaText += " (showing first " + result.Rows.Count + ")";
        metaText += " \u2022 " + result.ExecutionTime.TotalMilliseconds.ToString("F0") + "ms";

        return new
        {
            type = "Container",
            items = new object[]
            {
                new
                {
                    type = "TextBlock",
                    text = metaText,
                    size = "Small",
                    isSubtle = true,
                    spacing = "Medium",
                    horizontalAlignment = "Right"
                }
            }
        };
    }

    /// <summary>
    /// Creates a toggleable "Show SQL" action that reveals the generated SQL
    /// in monospace font when clicked.
    /// </summary>
    /// <param name="sql">The SQL query to display.</param>
    /// <returns>An anonymous object representing a Container with an ActionSet.</returns>
    private static object CreateSqlContainer(string sql)
    {
        return new
        {
            type = "Container",
            style = "default",
            items = new object[]
            {
                new
                {
                    type = "ActionSet",
                    actions = new object[]
                    {
                        new
                        {
                            type = "Action.ShowCard",
                            title = "Show SQL",
                            card = new
                            {
                                type = "AdaptiveCard",
                                body = new object[]
                                {
                                    new
                                    {
                                        type = "TextBlock",
                                        text = "`" + "\n" + sql + "\n`" + "",
                                        wrap = true,
                                        fontType = "Monospace",
                                        size = "Small"
                                    }
                                }
                            }
                        }
                    }
                }
            },
            spacing = "Small"
        };
    }

    // ========================================================================
    // Value formatting methods
    // ========================================================================

    /// <summary>
    /// Basic value formatting — converts nulls to a dash and formats decimals.
    /// Used for general table cell display.
    /// </summary>
    /// <param name="value">The cell value to format.</param>
    /// <returns>A display-friendly string representation.</returns>
    private static string FormatValue(object? value)
    {
        return value switch
        {
            null => "\u2014",              // em-dash for null
            decimal d => d.ToString("N2"),
            double dbl => dbl.ToString("N2"),
            float f => f.ToString("N2"),
            _ => value.ToString() ?? "\u2014"
        };
    }

    /// <summary>
    /// Smart formatting based on column name heuristics and value type.
    /// Detects currency, percentages, counts, and large numbers for richer KPI display.
    ///
    /// Heuristics:
    ///   - Column names containing "revenue", "amount", "cost", "price" → ,234.56
    ///   - Column names containing "percent", "pct", "rate" → 45.2%
    ///   - Column names containing "count", "qty" or int/long values → 1.2M, 45K, 1,247
    ///   - All other values → default FormatValue()
    /// </summary>
    /// <param name="value">The metric value to format.</param>
    /// <param name="columnName">The column name for heuristic detection.</param>
    /// <returns>A richly formatted string (e.g., ".2M", "45.2%", "1,247").</returns>
    private static string SmartFormat(object? value, string columnName)
    {
        if (value is null) return "\u2014";

        var colLower = columnName.ToLowerInvariant();

        // Currency detection based on column name keywords
        if (IsCurrencyColumn(colLower))
        {
            return value switch
            {
                decimal d => "$" + d.ToString("N2"),
                double dbl => "$" + dbl.ToString("N2"),
                float f => "$" + f.ToString("N2"),
                int i => "$" + i.ToString("N0"),
                long l => "$" + l.ToString("N0"),
                _ => "$" + value
            };
        }

        // Percentage detection based on column name keywords
        if (colLower.Contains("percent") || colLower.Contains("pct")
            || colLower.Contains("ratio") || colLower.Contains("rate"))
        {
            return value switch
            {
                decimal d => d.ToString("N1") + "%",
                double dbl => dbl.ToString("N1") + "%",
                float f => f.ToString("N1") + "%",
                _ => value + "%"
            };
        }

        // Large number abbreviation (1,200,000 → 1.2M, 45,000 → 45.0K)
        if (IsCountColumn(colLower) || value is int or long)
        {
            if (double.TryParse(value.ToString(), out var num))
            {
                if (Math.Abs(num) >= 1_000_000_000) return (num / 1_000_000_000).ToString("N1") + "B";
                if (Math.Abs(num) >= 1_000_000) return (num / 1_000_000).ToString("N1") + "M";
                if (Math.Abs(num) >= 10_000) return (num / 1_000).ToString("N1") + "K";
                return num.ToString("N0");
            }
        }

        return FormatValue(value);
    }

    /// <summary>
    /// Converts SQL column names like "TotalRevenue", "total_revenue", or "TOTAL_REVENUE"
    /// into human-readable "Total Revenue" format for card display.
    /// Handles snake_case, PascalCase, and camelCase conventions.
    /// </summary>
    /// <param name="columnName">The raw SQL column name.</param>
    /// <returns>A human-readable label (e.g., "Total Revenue").</returns>
    private static string FormatColumnLabel(string columnName)
    {
        // Step 1: Replace underscores with spaces (handles snake_case)
        var label = columnName.Replace("_", " ");

        // Step 2: Insert spaces before uppercase letters in PascalCase/camelCase
        var result = new System.Text.StringBuilder();
        for (int i = 0; i < label.Length; i++)
        {
            if (i > 0 && char.IsUpper(label[i]) && !char.IsUpper(label[i - 1]))
                result.Append(' ');
            result.Append(label[i]);
        }

        // Step 3: Title case each word
        var words = result.ToString().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        return string.Join(" ", words.Select(w =>
            char.ToUpper(w[0]) + (w.Length > 1 ? w[1..].ToLower() : "")));
    }

    /// <summary>
    /// Checks if a column name (lowercase) indicates currency values.
    /// </summary>
    private static bool IsCurrencyColumn(string colLower)
    {
        return colLower.Contains("revenue") || colLower.Contains("amount")
            || colLower.Contains("cost") || colLower.Contains("price")
            || colLower.Contains("total") || colLower.Contains("salary")
            || colLower.Contains("budget") || colLower.Contains("money")
            || colLower.Contains("fee") || colLower.Contains("payment")
            || colLower.Contains("balance") || colLower.Contains("income");
    }

    /// <summary>
    /// Checks if a column name (lowercase) indicates count/quantity values.
    /// </summary>
    private static bool IsCountColumn(string colLower)
    {
        return colLower.Contains("count") || colLower.Contains("total")
            || colLower.Contains("num") || colLower.Contains("qty")
            || colLower.Contains("quantity");
    }

    // ========================================================================
    // Size management methods — keep cards under Teams' 28KB limit
    // ========================================================================

    /// <summary>
    /// Trims query results to fit within Teams' message size limits.
    /// Limits both row count and column count to prevent oversized Adaptive Cards.
    /// </summary>
    /// <param name="result">The original query result.</param>
    /// <returns>A trimmed copy if needed, or the original if already within limits.</returns>
    private QueryResult TrimForTeams(QueryResult result)
    {
        var needsTrim = result.Rows.Count > MaxTableRows
            || result.Columns.Count > MaxColumnsInTable;

        if (!needsTrim) return result;

        _logger.LogDebug(
            "Trimming result for Teams: {OrigRows} rows -> {MaxRows}, {OrigCols} cols -> {MaxCols}",
            result.Rows.Count, Math.Min(result.Rows.Count, MaxTableRows),
            result.Columns.Count, Math.Min(result.Columns.Count, MaxColumnsInTable));

        var trimmedColumns = result.Columns.Count > MaxColumnsInTable
            ? result.Columns.Take(MaxColumnsInTable).ToList()
            : result.Columns;

        var columnNames = trimmedColumns.Select(c => c.Name).ToHashSet();

        var trimmedRows = result.Rows
            .Take(MaxTableRows)
            .Select(row => row
                .Where(kvp => columnNames.Contains(kvp.Key))
                .ToDictionary(kvp => kvp.Key, kvp => kvp.Value))
            .ToList();

        return new QueryResult
        {
            IsSuccess = result.IsSuccess,
            SqlQuery = result.SqlQuery,
            Columns = trimmedColumns,
            Rows = trimmedRows,
            TotalRowCount = result.TotalRowCount,
            IsTruncated = true,
            ExecutionTime = result.ExecutionTime
        };
    }

    /// <summary>
    /// Checks if the rendered Adaptive Card exceeds Teams' message size limit (25KB).
    /// If so, falls back to a minimal summary card that shows row/column counts.
    /// </summary>
    /// <param name="card">The rendered card attachment.</param>
    /// <param name="result">The query result (for summary fallback).</param>
    /// <param name="sqlResponse">The SQL response (for summary fallback).</param>
    /// <returns>The original card if within limits, or a summary card.</returns>
    private Attachment EnsureCardFitsLimit(Attachment card, QueryResult result, NL2SqlResponse sqlResponse)
    {
        var json = JsonSerializer.Serialize(card.Content);
        if (json.Length <= MaxCardSizeBytes)
        {
            _logger.LogDebug("Card size: {Size} bytes (within {Limit} byte limit)",
                json.Length, MaxCardSizeBytes);
            return card;
        }

        _logger.LogWarning(
            "Adaptive Card too large ({Size} bytes > {Limit} byte limit). " +
            "Falling back to summary card.",
            json.Length, MaxCardSizeBytes);

        return CreateSummaryCard(result, sqlResponse);
    }

    /// <summary>
    /// Creates a minimal fallback card when the full result is too large for Teams.
    /// Shows row/column counts, column names, execution time, and the SQL used.
    /// Advises the user to narrow their query.
    /// </summary>
    /// <param name="result">The query result.</param>
    /// <param name="sqlResponse">The SQL response with explanation.</param>
    /// <returns>A compact summary card <see cref="Attachment"/>.</returns>
    private static Attachment CreateSummaryCard(QueryResult result, NL2SqlResponse sqlResponse)
    {
        var summaryText = "Query returned **" + result.TotalRowCount + " row(s)** across **" + result.Columns.Count + " column(s)**.";
        if (result.TotalRowCount > MaxTableRows)
            summaryText += "\n\nThe result is too large to display as a card. Consider narrowing your query (e.g. add TOP 10, filter by date, etc.).";

        var columnList = string.Join(", ", result.Columns.Select(c => c.Name));

        var card = new
        {
            type = "AdaptiveCard",
            version = "1.5",
            body = new object[]
            {
                CreateHeaderContainer("\ud83d\udcca Query Results (Summary)", sqlResponse.Explanation),
                new
                {
                    type = "TextBlock",
                    text = summaryText,
                    wrap = true,
                    spacing = "Medium"
                },
                new
                {
                    type = "FactSet",
                    facts = new object[]
                    {
                        new { title = "Columns", value = columnList },
                        new { title = "Total Rows", value = result.TotalRowCount.ToString() },
                        new { title = "Execution Time", value = result.ExecutionTime.TotalMilliseconds.ToString("F0") + "ms" }
                    },
                    spacing = "Medium"
                },
                CreateSqlContainer(sqlResponse.GeneratedSql)
            }
        };

        return CreateAttachment(card);
    }

    // ========================================================================
    // Attachment creation
    // ========================================================================

    /// <summary>
    /// Serializes a card object to JSON and wraps it in a Bot Framework <see cref="Attachment"/>.
    /// Uses System.Text.Json for serialization and Newtonsoft JObject.Parse for the
    /// Content property because Bot Framework SDK internally uses Newtonsoft.Json.
    /// </summary>
    /// <param name="card">The anonymous card object to serialize.</param>
    /// <returns>A Bot Framework <see cref="Attachment"/> with Adaptive Card content.</returns>
    private static Attachment CreateAttachment(object card)
    {
        // Bot Framework SDK uses Newtonsoft.Json internally.
        // Attachment.Content must be a JObject (Newtonsoft) for proper serialization.
        var json = JsonSerializer.Serialize(card);
        return new Attachment
        {
            ContentType = "application/vnd.microsoft.card.adaptive",
            Content = JObject.Parse(json)
        };
    }
}
