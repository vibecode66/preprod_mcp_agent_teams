// ============================================================================
// SqlConnectionFactory.cs — Azure SQL connection factory with Managed Identity
//
// Purpose:
//   Creates SqlConnection instances, handling both Managed Identity (MI) and
//   traditional SQL authentication. When MI is enabled, acquires an Azure AD
//   token using DefaultAzureCredential and attaches it to the connection.
//
// Auth modes:
//   UseManagedIdentity = true  → DefaultAzureCredential (MI, Azure CLI, VS)
//   UseManagedIdentity = false → SQL auth (user/password in connection string)
//
// Dependencies:
//   - Azure.Identity for DefaultAzureCredential
//   - Microsoft.Data.SqlClient for SqlConnection
// ============================================================================

using System.Diagnostics;
using Azure.Core;
using Azure.Identity;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SqlCopilot.Core.Exceptions;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services;

/// <summary>
/// Creates <see cref="SqlConnection"/> instances with support for both Managed Identity
/// (DefaultAzureCredential) and traditional SQL authentication.
/// <para>
/// When <see cref="AzureSqlOptions.UseManagedIdentity"/> is <c>true</c>:
///   Uses <see cref="DefaultAzureCredential"/> to acquire an Azure AD token.
///   Works with System-assigned MI, User-assigned MI, Azure CLI, VS credentials, etc.
///   Connection string should NOT contain User ID / Password.
/// </para>
/// <para>
/// When <see cref="AzureSqlOptions.UseManagedIdentity"/> is <c>false</c>:
///   Uses the connection string as-is (SQL auth with embedded credentials).
/// </para>
/// </summary>
public class SqlConnectionFactory : ISqlConnectionFactory
{
    /// <summary>
    /// The OAuth2 scope required to acquire a token for Azure SQL Database.
    /// This is the standard resource URI for Azure SQL.
    /// </summary>
    private static readonly string[] AzureSqlScopes = new[] { "https://database.windows.net/.default" };

    private readonly AzureSqlOptions _options;
    private readonly ILogger<SqlConnectionFactory> _logger;
    private readonly DefaultAzureCredential? _credential;

    /// <summary>
    /// Initializes the factory, configuring the credential based on app settings.
    /// </summary>
    /// <param name="options">Azure SQL configuration (connection string, MI settings).</param>
    /// <param name="logger">Logger for diagnostics.</param>
    public SqlConnectionFactory(
        IOptions<AzureSqlOptions> options,
        ILogger<SqlConnectionFactory> logger)
    {
        _options = options.Value ?? throw new ArgumentNullException(nameof(options));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        if (_options.UseManagedIdentity)
        {
            // Configure DefaultAzureCredential — it tries MI first, then CLI, then VS, etc.
            var credentialOptions = new DefaultAzureCredentialOptions
            {
                // Browser-based interactive auth is not suitable for server workloads
                ExcludeInteractiveBrowserCredential = true
            };

            // If a specific Client ID is provided, target that User-Assigned Managed Identity
            if (!string.IsNullOrWhiteSpace(_options.ManagedIdentityClientId))
            {
                credentialOptions.ManagedIdentityClientId = _options.ManagedIdentityClientId;
                _logger.LogInformation(
                    "SqlConnectionFactory initialized with User-Assigned Managed Identity (ClientId: {ClientId})",
                    _options.ManagedIdentityClientId);
            }
            else
            {
                _logger.LogInformation(
                    "SqlConnectionFactory initialized with System-Assigned Managed Identity");
            }

            _credential = new DefaultAzureCredential(credentialOptions);
        }
        else
        {
            _logger.LogInformation(
                "SqlConnectionFactory initialized with SQL connection string authentication");
        }
    }

    /// <summary>
    /// Creates and opens a new <see cref="SqlConnection"/>.
    /// If Managed Identity is configured, acquires an Azure AD token first.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>An open <see cref="SqlConnection"/> ready for use.</returns>
    /// <exception cref="ConnectionFactoryException">
    /// Thrown when connection or token acquisition fails.
    /// </exception>
    public async Task<SqlConnection> CreateConnectionAsync(CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        SqlConnection? connection = null;

        try
        {
            _logger.LogDebug("Creating SQL connection to Azure SQL Database...");

            connection = new SqlConnection(_options.ConnectionString);

            // Acquire Azure AD token if using Managed Identity
            if (_options.UseManagedIdentity && _credential is not null)
            {
                _logger.LogDebug("Acquiring Azure AD token for SQL Database...");

                var tokenRequest = new TokenRequestContext(AzureSqlScopes);
                var token = await _credential.GetTokenAsync(tokenRequest, cancellationToken);

                // Attach the bearer token to the connection — SqlClient uses it for auth
                connection.AccessToken = token.Token;

                _logger.LogDebug(
                    "Azure AD token acquired successfully, expires at {ExpiresOn}",
                    token.ExpiresOn);
            }

            // Open the connection to the database
            await connection.OpenAsync(cancellationToken);

            stopwatch.Stop();
            _logger.LogInformation(
                "SQL connection established to {Database} in {ElapsedMs}ms",
                connection.Database, stopwatch.ElapsedMilliseconds);

            return connection;
        }
        catch (OperationCanceledException)
        {
            // Cancellation is not an error — clean up and rethrow
            _logger.LogWarning("SQL connection creation was cancelled");
            connection?.Dispose();
            throw;
        }
        catch (AuthenticationFailedException ex)
        {
            // Managed Identity or Azure AD token acquisition failed
            stopwatch.Stop();
            _logger.LogError(ex,
                "Azure AD authentication failed after {ElapsedMs}ms. " +
                "Ensure the Managed Identity has access to the SQL database. " +
                "Error: {ErrorMessage}",
                stopwatch.ElapsedMilliseconds, ex.Message);

            connection?.Dispose();
            throw new ConnectionFactoryException(
                $"Failed to authenticate with Azure AD: {ex.Message}",
                ex,
                usingMI: true);
        }
        catch (SqlException ex)
        {
            // SQL-level connection error (network, firewall, permissions)
            stopwatch.Stop();
            _logger.LogError(ex,
                "SQL connection failed after {ElapsedMs}ms. " +
                "SqlError #{ErrorNumber}: {ErrorMessage}",
                stopwatch.ElapsedMilliseconds, ex.Number, ex.Message);

            connection?.Dispose();
            throw new ConnectionFactoryException(
                $"SQL connection failed (Error #{ex.Number}): {ex.Message}",
                ex,
                usingMI: _options.UseManagedIdentity);
        }
        catch (Exception ex)
        {
            // Unexpected failure — log full context for troubleshooting
            stopwatch.Stop();
            _logger.LogError(ex,
                "Unexpected error creating SQL connection after {ElapsedMs}ms: {ErrorMessage}",
                stopwatch.ElapsedMilliseconds, ex.Message);

            connection?.Dispose();
            throw new ConnectionFactoryException(
                $"Unexpected error creating SQL connection: {ex.Message}",
                ex,
                usingMI: _options.UseManagedIdentity);
        }
    }
}
