// ============================================================================
// ISqlGeneratorService.cs — Interface for NL→SQL conversion
// ============================================================================

using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Interfaces;

/// <summary>
/// Generates SQL queries from natural language using Azure OpenAI.
/// Supports both single-shot generation and self-healing retry with
/// execution validation.
/// </summary>
public interface ISqlGeneratorService
{
    /// <summary>
    /// Generates a SQL query from a natural language question (single attempt).
    /// </summary>
    /// <param name="naturalLanguageQuery">The user's question in plain English.</param>
    /// <param name="schema">Database schema for LLM context.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>An <see cref="NL2SqlResponse"/> with the generated SQL and metadata.</returns>
    Task<NL2SqlResponse> GenerateSqlAsync(
        string naturalLanguageQuery,
        DatabaseSchema schema,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Generates SQL and validates it by executing against the database.
    /// If execution fails, automatically feeds the error back to the LLM
    /// for self-correction (up to 3 retries).
    /// </summary>
    /// <param name="naturalLanguageQuery">The user's natural language question.</param>
    /// <param name="schema">Database schema for LLM context.</param>
    /// <param name="queryExecutor">Executor to validate the SQL against the real database.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>
    /// A tuple of (SQL response, query result). Both are populated if the query
    /// succeeded on any attempt. On failure, the last error is returned.
    /// </returns>
    Task<(NL2SqlResponse SqlResponse, QueryResult? QueryResult)> GenerateAndValidateAsync(
        string naturalLanguageQuery,
        DatabaseSchema schema,
        IQueryExecutionService queryExecutor,
        CancellationToken cancellationToken = default);
}
