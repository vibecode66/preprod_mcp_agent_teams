// ============================================================================
// IAdaptiveCardService.cs — Interface for Adaptive Card rendering
// ============================================================================

using Microsoft.Bot.Schema;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Interfaces;

/// <summary>
/// Builds Adaptive Card attachments from query results for display in
/// Teams and M365 Copilot. Automatically selects the best card layout
/// (table, KPI, chart, key-value, etc.) based on the result shape.
/// </summary>
public interface IAdaptiveCardService
{
    /// <summary>
    /// Creates the appropriate Adaptive Card for a successful query result.
    /// Selects the best visualization (table, KPI, chart, etc.) based on
    /// result shape and the LLM's chart suggestion.
    /// </summary>
    /// <param name="result">The SQL query execution result.</param>
    /// <param name="sqlResponse">The LLM response with explanation and chart suggestion.</param>
    /// <returns>A Bot Framework <see cref="Attachment"/> containing the Adaptive Card.</returns>
    Attachment CreateResultCard(QueryResult result, NL2SqlResponse sqlResponse);

    /// <summary>
    /// Creates an error card with a warning icon and error description.
    /// </summary>
    /// <param name="errorMessage">The error message to display.</param>
    /// <returns>A Bot Framework <see cref="Attachment"/> with the error card.</returns>
    Attachment CreateErrorCard(string errorMessage);

    /// <summary>
    /// Creates a welcome/onboarding card with example questions and usage tips.
    /// </summary>
    /// <returns>A Bot Framework <see cref="Attachment"/> with the welcome card.</returns>
    Attachment CreateWelcomeCard();
}
