// ============================================================================
// IQueryExecutionService.cs — Interface for safe SQL query execution
// ============================================================================

using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Interfaces;

/// <summary>
/// Executes SQL queries against Azure SQL Database in a safe, read-only manner.
/// Enforces query timeouts, row limits, and statement-type validation.
/// </summary>
public interface IQueryExecutionService
{
    /// <summary>
    /// Executes a SQL query and returns structured results.
    /// Only SELECT/WITH (CTE) statements are allowed; all others are rejected.
    /// </summary>
    /// <param name="sqlQuery">The SQL query to execute (must be a SELECT).</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>
    /// A <see cref="QueryResult"/> with column metadata, row data, and timing.
    /// On failure, <see cref="QueryResult.IsSuccess"/> is false with an error message.
    /// </returns>
    Task<QueryResult> ExecuteQueryAsync(
        string sqlQuery,
        CancellationToken cancellationToken = default);
}
